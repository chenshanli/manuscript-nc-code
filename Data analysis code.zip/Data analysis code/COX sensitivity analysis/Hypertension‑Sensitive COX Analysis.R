# =====================================================================
# 高血压（onlyhyper）与痴呆风险：
# 主 Cox 分析及 6 项敏感性分析（可独立运行）
#
# 数据文件：
# 1. onlyhyper_data_new.dta：主分析、敏感性分析1/2/3/4/5/6
# 2. onlyhyper_data.dta：敏感性分析5（25项认知量表统一痴呆判定算法）
#
# 分析内容：
# 主分析：四国分别 Cox 回归 + 随机效应 Meta 分析
# 敏感性分析1：连续年龄 age 调整
# 敏感性分析2：滞后分析，排除基线后 1/2/3 年内发生痴呆者
# 敏感性分析3：Fine-Gray 死亡竞争风险模型
# 敏感性分析4：逐一排除国家后的随机效应 Meta 分析
# 敏感性分析5：基于25项认知量表统一痴呆判定算法（onlyhyper_data.dta）
# 敏感性分析6：按国家分别进行 MICE 多重插补（m = 20）后 Cox 分析
#
# 纳入标准：
#   动态基线选择最早符合条件的波次；
#   排除基线糖尿病患者；
#   暴露 baseline_onlyhyper：0 = 无高血压且无糖尿病，1 = 高血压且无糖尿病。
#
# 分组统计：
# 各国输出：
# 1. 高血压组人数；
# 2. 高血压组中痴呆发病人数；
# 3. 非高血压组人数；
# 4. 非高血压组中痴呆发病人数。
# =====================================================================

# =====================================================================
# 0. 参数设置
# =====================================================================
working_directory <- "E:/csl/CSL/database"
main_data_file <- "onlyhyper_data_new.dta"
complete_case_data_file <- "onlyhyper_data.dta"

# 多重插补次数，建议设置为 20。
mi_m <- 20L

# MICE 每条插补链的迭代次数。
mi_maxit <- 20L

# 随机种子。
analysis_seed <- 20260317L

setwd(working_directory)
set.seed(analysis_seed)

# =====================================================================
# 1. 安装并加载所需 R 包
# =====================================================================
required_packages <- c(
  "dplyr",
  "tidyr",
  "haven",
  "survival",
  "broom",
  "meta",
  "readr",
  "cmprsk",
  "mice",
  "ggplot2",
  "scales",
  "stringr"
)

missing_packages <- required_packages[
  !vapply(
    required_packages,
    requireNamespace,
    logical(1),
    quietly = TRUE
  )
]

if (length(missing_packages) > 0) {
  install.packages(
    missing_packages,
    dependencies = TRUE
  )
}

suppressPackageStartupMessages({
  library(dplyr)
  library(tidyr)
  library(haven)
  library(survival)
  library(broom)
  library(meta)
  library(readr)
  library(cmprsk)
  library(mice)
  library(ggplot2)
  library(stringr)
})

select <- dplyr::select

# =====================================================================
# 2. 全局变量
# =====================================================================
death_vars <- paste0("r", 1:6, "death")
dementia_vars <- paste0("r", 1:6, "dementia")

country_levels <- c(
  "CHARLS",
  "HRS",
  "SHARE",
  "ELSA"
)

cox_covariates <- c(
  "baseline_onlyhyper",
  "yearsold",
  "ragender",
  "raeduc_c",
  "baseline_phyactivities",
  "baseline_netuse",
  "baseline_mstat",
  "baseline_scocwk",
  "baseline_smoking",
  "baseline_drink",
  "baseline_Non_com_dis"
)

# 样本筛选流程图分类顺序（主分析及敏感性分析5共用）。
flow_order <- c(
  "纳入最终分析",
  "排除：年龄<50岁或年龄缺失",
  "排除：基线高血压或糖尿病状态缺失",
  "排除：基线患糖尿病",
  "排除：基线痴呆或阿尔茨海默病",
  "排除：暴露或协变量数据缺失",
  "排除：后续痴呆随访数据缺失",
  "排除：其他原因",
  "排除：未知数据来源"
)

# =====================================================================
# 3. 基础工具函数
# =====================================================================
safe_numeric <- function(x) {
  suppressWarnings(as.numeric(x))
}

safe_get_value <- function(data, row_idx, variable_name) {
  
  if (!variable_name %in% names(data)) {
    return(NA_real_)
  }
  
  value <- data[[variable_name]][row_idx]
  
  if (length(value) == 0 || is.null(value) || is.na(value)) {
    return(NA_real_)
  }
  
  safe_numeric(value)
}

get_wave_info <- function(data_source) {
  
  data_source <- suppressWarnings(as.integer(data_source))
  
  switch(
    as.character(data_source),
    
    "1" = list(
      country = "CHARLS",
      max_wave = 5L,
      wave_years = c(2011, 2013, 2015, 2018, 2020)
    ),
    
    "2" = list(
      country = "HRS",
      max_wave = 6L,
      wave_years = c(2012, 2014, 2016, 2018, 2020, 2022)
    ),
    
    "3" = list(
      country = "SHARE",
      max_wave = 5L,
      wave_years = c(2013, 2015, 2017, 2020, 2022)
    ),
    
    "4" = list(
      country = "ELSA",
      max_wave = 5L,
      wave_years = c(2015, 2017, 2020, 2022, 2024)
    ),
    
    NULL
  )
}

get_country_name <- function(data_source) {
  
  wave_info <- get_wave_info(data_source)
  
  if (is.null(wave_info)) {
    return("Unknown")
  }
  
  wave_info$country
}

# 检查某一波次所需变量列是否均存在于数据框中。
check_wave_columns <- function(data, wave) {
  
  required_wave_vars <- c(
    paste0("r", wave, "onlyhyper"),
    paste0("r", wave, "diabetes"),
    paste0("r", wave, "phyactivities"),
    paste0("r", wave, "netuse"),
    paste0("r", wave, "dementia"),
    paste0("r", wave, "mstat"),
    paste0("r", wave, "scocwk"),
    paste0("r", wave, "smoking"),
    paste0("r", wave, "Non_com_dis"),
    paste0("r", wave, "drink")
  )
  
  all(required_wave_vars %in% names(data))
}

get_baseline_values <- function(data, i, wave) {
  
  list(
    onlyhyper = safe_get_value(
      data, i, paste0("r", wave, "onlyhyper")
    ),
    
    diabetes = safe_get_value(
      data, i, paste0("r", wave, "diabetes")
    ),
    
    phyactivities = safe_get_value(
      data, i, paste0("r", wave, "phyactivities")
    ),
    
    netuse = safe_get_value(
      data, i, paste0("r", wave, "netuse")
    ),
    
    dementia = safe_get_value(
      data, i, paste0("r", wave, "dementia")
    ),
    
    mstat = safe_get_value(
      data, i, paste0("r", wave, "mstat")
    ),
    
    scocwk = safe_get_value(
      data, i, paste0("r", wave, "scocwk")
    ),
    
    smoking = safe_get_value(
      data, i, paste0("r", wave, "smoking")
    ),
    
    Non_com_dis = safe_get_value(
      data, i, paste0("r", wave, "Non_com_dis")
    ),
    
    drink = safe_get_value(
      data, i, paste0("r", wave, "drink")
    )
  )
}

# =====================================================================
# 4. 原始数据读取与必要变量检查
# =====================================================================
read_and_validate_data <- function(file_name) {
  
  if (!file.exists(file_name)) {
    stop("未找到数据文件：", file_name)
  }
  
  raw_data <- haven::read_dta(file_name) %>%
    mutate(record_id = row_number())
  
  required_basic_vars <- c(
    "ID",
    "data_source",
    "yearsold",
    "age",
    "raeduc_c",
    "ragender"
  )
  
  missing_basic_vars <- setdiff(
    required_basic_vars,
    names(raw_data)
  )
  
  if (length(missing_basic_vars) > 0) {
    stop(
      "数据文件中缺少必要变量：",
      paste(missing_basic_vars, collapse = ", ")
    )
  }
  
  raw_data
}

# =====================================================================
# 5. 判断是否存在后续痴呆随访
# =====================================================================
has_followup_dementia_data <- function(
    data,
    i,
    enrollment_wave,
    max_wave
) {
  
  if (is.na(enrollment_wave) || enrollment_wave >= max_wave) {
    return(FALSE)
  }
  
  future_dementia <- vapply(
    seq.int(enrollment_wave + 1L, max_wave),
    function(wave) {
      safe_get_value(
        data,
        i,
        paste0("r", wave, "dementia")
      )
    },
    numeric(1)
  )
  
  any(!is.na(future_dementia))
}

# =====================================================================
# 6. 动态基线筛选
#
# 筛选顺序与原始高血压主分析代码一致：
#   1. 基线高血压（onlyhyper）和糖尿病（diabetes）状态必须已知且有效；
#   2. 排除基线糖尿病患者（diabetes == 1）；
#   3. 基线痴呆状态必须已知且为 0；
#   4. 完整案例分析要求所有暴露及协变量不缺失；
#   5. 必须至少存在一波后续痴呆随访。
#
# require_complete_case = FALSE：
# 敏感性分析6使用，保留协变量缺失者以进行多重插补；
# 但暴露、糖尿病排除、基线痴呆和随访条件仍然必须满足。
# =====================================================================
select_dynamic_baseline <- function(
    data,
    require_complete_case = TRUE
) {
  
  output_data <- data %>%
    mutate(
      country = vapply(
        data_source,
        get_country_name,
        character(1)
      ),
      enrollment_wave = NA_integer_,
      screening_status = NA_character_
    )
  
  for (i in seq_len(nrow(output_data))) {
    
    source_i <- safe_get_value(output_data, i, "data_source")
    age_i <- safe_get_value(output_data, i, "age")
    
    wave_info <- get_wave_info(source_i)
    
    if (is.null(wave_info)) {
      output_data$screening_status[i] <- "排除：未知数据来源"
      next
    }
    
    if (is.na(age_i) || age_i < 50) {
      output_data$screening_status[i] <- "排除：年龄<50岁或年龄缺失"
      next
    }
    
    has_exposure_diabetes_data <- FALSE
    has_no_diabetes_baseline <- FALSE
    has_non_dementia_baseline <- FALSE
    complete_covariates_available <- FALSE
    has_followup_data <- FALSE
    enrollment_found <- FALSE
    
    # 最后一波不作为基线，因为其后无随访。
    for (wave in seq_len(wave_info$max_wave - 1L)) {
      
      if (!check_wave_columns(output_data, wave)) {
        next
      }
      
      baseline_values <- get_baseline_values(
        output_data,
        i,
        wave
      )
      
      # 高血压暴露和糖尿病状态必须已知。
      if (
        is.na(baseline_values$onlyhyper) ||
        is.na(baseline_values$diabetes)
      ) {
        next
      }
      
      if (
        !baseline_values$onlyhyper %in% c(0, 1) ||
        !baseline_values$diabetes %in% c(0, 1)
      ) {
        next
      }
      
      has_exposure_diabetes_data <- TRUE
      
      # 排除基线糖尿病患者。
      if (baseline_values$diabetes == 1) {
        next
      }
      
      has_no_diabetes_baseline <- TRUE
      
      # 基线痴呆状态必须已知且为 0。
      if (
        is.na(baseline_values$dementia) ||
        baseline_values$dementia != 0
      ) {
        next
      }
      
      has_non_dementia_baseline <- TRUE
      
      analysis_variables <- c(
        baseline_values$onlyhyper,
        baseline_values$phyactivities,
        baseline_values$netuse,
        baseline_values$mstat,
        baseline_values$scocwk,
        baseline_values$smoking,
        baseline_values$Non_com_dis,
        baseline_values$drink,
        safe_get_value(output_data, i, "yearsold"),
        safe_get_value(output_data, i, "raeduc_c"),
        safe_get_value(output_data, i, "ragender")
      )
      
      if (all(!is.na(analysis_variables))) {
        complete_covariates_available <- TRUE
      }
      
      # 完整案例分析要求所有暴露及协变量不缺失。
      if (require_complete_case && any(is.na(analysis_variables))) {
        next
      }
      
      # 必须至少存在一波后续痴呆信息。
      if (!has_followup_dementia_data(
        data = output_data,
        i = i,
        enrollment_wave = wave,
        max_wave = wave_info$max_wave
      )) {
        next
      }
      
      has_followup_data <- TRUE
      
      output_data$enrollment_wave[i] <- wave
      output_data$screening_status[i] <- "纳入最终分析"
      
      enrollment_found <- TRUE
      break
    }
    
    if (!enrollment_found) {
      
      if (!has_exposure_diabetes_data) {
        output_data$screening_status[i] <-
          "排除：基线高血压或糖尿病状态缺失"
        
      } else if (!has_no_diabetes_baseline) {
        output_data$screening_status[i] <-
          "排除：基线患糖尿病"
        
      } else if (!has_non_dementia_baseline) {
        output_data$screening_status[i] <-
          "排除：基线痴呆或阿尔茨海默病"
        
      } else if (require_complete_case &&
                 !complete_covariates_available) {
        output_data$screening_status[i] <-
          "排除：暴露或协变量数据缺失"
        
      } else if (!has_followup_data) {
        output_data$screening_status[i] <-
          "排除：后续痴呆随访数据缺失"
        
      } else {
        output_data$screening_status[i] <-
          "排除：其他原因"
      }
    }
  }
  
  output_data
}

# =====================================================================
# 7. 提取动态基线暴露和协变量
# =====================================================================
extract_dynamic_baseline_variables <- function(data) {
  
  output_data <- data %>%
    mutate(
      baseline_onlyhyper = NA_real_,
      baseline_diabetes = NA_real_,
      baseline_dementia_status = NA_real_,
      baseline_phyactivities = NA_real_,
      baseline_netuse = NA_real_,
      baseline_mstat = NA_real_,
      baseline_scocwk = NA_real_,
      baseline_smoking = NA_real_,
      baseline_drink = NA_real_,
      baseline_Non_com_dis = NA_real_,
      baseline_year = NA_real_
    )
  
  for (i in seq_len(nrow(output_data))) {
    
    source_i <- safe_get_value(output_data, i, "data_source")
    enrollment_wave_i <- safe_get_value(
      output_data,
      i,
      "enrollment_wave"
    )
    
    wave_info <- get_wave_info(source_i)
    
    if (is.null(wave_info) || is.na(enrollment_wave_i)) {
      next
    }
    
    output_data$baseline_onlyhyper[i] <- safe_get_value(
      output_data,
      i,
      paste0("r", enrollment_wave_i, "onlyhyper")
    )
    
    output_data$baseline_diabetes[i] <- safe_get_value(
      output_data,
      i,
      paste0("r", enrollment_wave_i, "diabetes")
    )
    
    output_data$baseline_dementia_status[i] <- safe_get_value(
      output_data,
      i,
      paste0("r", enrollment_wave_i, "dementia")
    )
    
    output_data$baseline_phyactivities[i] <- safe_get_value(
      output_data,
      i,
      paste0("r", enrollment_wave_i, "phyactivities")
    )
    
    output_data$baseline_netuse[i] <- safe_get_value(
      output_data,
      i,
      paste0("r", enrollment_wave_i, "netuse")
    )
    
    output_data$baseline_mstat[i] <- safe_get_value(
      output_data,
      i,
      paste0("r", enrollment_wave_i, "mstat")
    )
    
    output_data$baseline_scocwk[i] <- safe_get_value(
      output_data,
      i,
      paste0("r", enrollment_wave_i, "scocwk")
    )
    
    output_data$baseline_smoking[i] <- safe_get_value(
      output_data,
      i,
      paste0("r", enrollment_wave_i, "smoking")
    )
    
    output_data$baseline_drink[i] <- safe_get_value(
      output_data,
      i,
      paste0("r", enrollment_wave_i, "drink")
    )
    
    output_data$baseline_Non_com_dis[i] <- safe_get_value(
      output_data,
      i,
      paste0("r", enrollment_wave_i, "Non_com_dis")
    )
    
    output_data$baseline_year[i] <- wave_info$wave_years[
      enrollment_wave_i
    ]
  }
  
  output_data
}

# =====================================================================
# 8. 构建 Cox 和 Fine-Gray 分析结局
#
# Cox 事件校正规则：
# 若第一次观察到痴呆 = 1，且下一次有效痴呆观测 = 0，
# 则首次痴呆结果不成立，按最后一次有效痴呆随访删失。
#
# Fine-Gray 结局：
# fg_status = 0：删失
# fg_status = 1：痴呆事件
# fg_status = 2：死亡竞争事件
# =====================================================================
derive_outcomes <- function(data) {
  
  output_data <- data %>%
    mutate(
      last_followup_year = NA_real_,
      time_to_event = NA_real_,
      event_status = NA_integer_,
      fg_time = NA_real_,
      fg_status = NA_integer_
    )
  
  for (i in seq_len(nrow(output_data))) {
    
    source_i <- safe_get_value(output_data, i, "data_source")
    enrollment_wave_i <- safe_get_value(
      output_data,
      i,
      "enrollment_wave"
    )
    
    wave_info <- get_wave_info(source_i)
    
    if (is.null(wave_info) || is.na(enrollment_wave_i)) {
      next
    }
    
    baseline_year_i <- wave_info$wave_years[enrollment_wave_i]
    
    future_waves <- seq.int(
      enrollment_wave_i + 1L,
      wave_info$max_wave
    )
    
    dementia_values <- vapply(
      future_waves,
      function(wave) {
        safe_get_value(
          output_data,
          i,
          paste0("r", wave, "dementia")
        )
      },
      numeric(1)
    )
    
    death_values <- vapply(
      future_waves,
      function(wave) {
        safe_get_value(
          output_data,
          i,
          paste0("r", wave, "death")
        )
      },
      numeric(1)
    )
    
    valid_dementia_index <- which(!is.na(dementia_values))
    
    # 最后一次有效痴呆随访时间。
    if (length(valid_dementia_index) > 0) {
      last_dementia_wave <- tail(
        future_waves[valid_dementia_index],
        1
      )
      
      last_followup_year_i <- wave_info$wave_years[
        last_dementia_wave
      ]
    } else {
      last_followup_year_i <- baseline_year_i
    }
    
    output_data$last_followup_year[i] <- last_followup_year_i
    
    # ---------------------------------------------------------------
    # Cox 痴呆事件判定
    # ---------------------------------------------------------------
    
    dementia_event_year <- NA_real_
    dementia_event_status <- 0L
    
    if (length(valid_dementia_index) > 0) {
      
      valid_dementia_values <- dementia_values[
        valid_dementia_index
      ]
      
      valid_dementia_waves <- future_waves[
        valid_dementia_index
      ]
      
      first_positive_position <- which(
        valid_dementia_values == 1
      )[1]
      
      if (!is.na(first_positive_position)) {
        
        first_positive_wave <- valid_dementia_waves[
          first_positive_position
        ]
        
        first_positive_year <- wave_info$wave_years[
          first_positive_wave
        ]
        
        # 首次痴呆阳性后有下一次有效随访。
        if (first_positive_position <
            length(valid_dementia_values)) {
          
          next_valid_dementia <- valid_dementia_values[
            first_positive_position + 1L
          ]
          
          # 下一次有效随访不为 0 时，认定为痴呆事件。
          if (next_valid_dementia != 0) {
            dementia_event_status <- 1L
            dementia_event_year <- first_positive_year
          }
          
        } else {
          # 首次阳性是最后一次有效观测，认定为痴呆事件。
          dementia_event_status <- 1L
          dementia_event_year <- first_positive_year
        }
      }
    }
    
    output_data$event_status[i] <- dementia_event_status
    
    if (dementia_event_status == 1L) {
      output_data$time_to_event[i] <- dementia_event_year -
        baseline_year_i
    } else {
      output_data$time_to_event[i] <- last_followup_year_i -
        baseline_year_i
    }
    
    # ---------------------------------------------------------------
    # Fine-Gray 死亡竞争风险结局
    # ---------------------------------------------------------------
    
    death_positive_position <- which(death_values == 1)[1]
    
    death_year <- NA_real_
    
    if (!is.na(death_positive_position)) {
      death_wave <- future_waves[death_positive_position]
      death_year <- wave_info$wave_years[death_wave]
    }
    
    # 痴呆和死亡发生在同一波次时，优先记为痴呆事件。
    if (!is.na(dementia_event_year) &&
        (is.na(death_year) ||
         dementia_event_year <= death_year)) {
      
      output_data$fg_status[i] <- 1L
      output_data$fg_time[i] <- dementia_event_year -
        baseline_year_i
      
    } else if (!is.na(death_year)) {
      
      output_data$fg_status[i] <- 2L
      output_data$fg_time[i] <- death_year -
        baseline_year_i
      
    } else {
      
      output_data$fg_status[i] <- 0L
      output_data$fg_time[i] <- last_followup_year_i -
        baseline_year_i
    }
  }
  
  output_data
}

# =====================================================================
# 9. 转换变量类型
# =====================================================================
format_analysis_variables <- function(data) {
  
  data %>%
    mutate(
      country = factor(
        country,
        levels = country_levels
      ),
      
      age = safe_numeric(age),
      
      yearsold = factor(
        safe_numeric(yearsold),
        levels = c(1, 2, 3, 4),
        labels = c(
          "60岁以下",
          "60-69岁",
          "70-79岁",
          "80岁及以上"
        )
      ),
      
      raeduc_c = factor(
        safe_numeric(raeduc_c),
        levels = c(1, 2, 3),
        labels = c(
          "初中及以下",
          "高中",
          "大学及以上"
        )
      ),
      
      ragender = factor(
        safe_numeric(ragender),
        levels = c(1, 2),
        labels = c("男", "女")
      ),
      
      baseline_onlyhyper = factor(
        baseline_onlyhyper,
        levels = c(0, 1),
        labels = c(
          "无高血压且无糖尿病",
          "高血压且无糖尿病"
        )
      ),
      
      baseline_diabetes = safe_numeric(baseline_diabetes),
      
      baseline_phyactivities = factor(
        baseline_phyactivities,
        levels = c(0, 1),
        labels = c("不活跃", "活跃")
      ),
      
      baseline_netuse = factor(
        baseline_netuse,
        levels = c(0, 1),
        labels = c("不使用", "使用")
      ),
      
      baseline_mstat = factor(
        baseline_mstat,
        levels = c(1, 2),
        labels = c("已婚/同居", "单身")
      ),
      
      baseline_scocwk = factor(
        baseline_scocwk,
        levels = c(0, 1),
        labels = c("不活跃", "活跃")
      ),
      
      baseline_smoking = factor(
        baseline_smoking,
        levels = c(0, 1, 2),
        labels = c("戒烟", "吸烟", "从未吸烟")
      ),
      
      baseline_drink = factor(
        baseline_drink,
        levels = c(0, 1),
        labels = c("从未饮酒", "饮过酒")
      ),
      
      baseline_Non_com_dis = factor(
        baseline_Non_com_dis,
        levels = c(0, 1),
        labels = c("无", "有")
      ),
      
      baseline_dementia_status = safe_numeric(
        baseline_dementia_status
      ),
      
      baseline_year = safe_numeric(baseline_year),
      
      time_to_event = safe_numeric(time_to_event),
      
      event_status = as.integer(event_status),
      
      fg_time = safe_numeric(fg_time),
      
      fg_status = as.integer(fg_status)
    )
}

# =====================================================================
# 10. 构建分析数据
# =====================================================================
build_analysis_data <- function(
    raw_data,
    require_complete_case = TRUE
) {
  
  screened_data <- select_dynamic_baseline(
    data = raw_data,
    require_complete_case = require_complete_case
  )
  
  selected_data <- screened_data %>%
    filter(screening_status == "纳入最终分析")
  
  baseline_data <- extract_dynamic_baseline_variables(
    selected_data
  )
  
  outcome_data <- derive_outcomes(baseline_data)
  
  analysis_data <- format_analysis_variables(outcome_data) %>%
    filter(
      baseline_diabetes == 0,
      baseline_dementia_status == 0,
      !is.na(time_to_event),
      time_to_event > 0
    )
  
  # 完整案例分析额外删除暴露或协变量缺失者。
  if (require_complete_case) {
    
    analysis_data <- analysis_data %>%
      filter(
        !is.na(baseline_onlyhyper),
        !is.na(baseline_diabetes),
        !is.na(yearsold),
        !is.na(age),
        !is.na(raeduc_c),
        !is.na(ragender),
        !is.na(baseline_phyactivities),
        !is.na(baseline_netuse),
        !is.na(baseline_mstat),
        !is.na(baseline_scocwk),
        !is.na(baseline_smoking),
        !is.na(baseline_drink),
        !is.na(baseline_Non_com_dis)
      )
  }
  
  list(
    screened_data = screened_data,
    analysis_data = analysis_data
  )
}

# =====================================================================
# 11. Cox 回归与随机效应 Meta 分析函数
# =====================================================================

# 统计高血压组和非高血压组的样本量及痴呆发病人数。
# event_variable 默认为 Cox 结局 event_status；
# Fine-Gray 分析时将传入 fg_status。
summarise_exposure_group_counts <- function(
    data,
    event_variable = "event_status"
) {
  
  if (!"baseline_onlyhyper" %in% names(data) ||
      !event_variable %in% names(data)) {
    return(
      tibble(
        hypertension_N = NA_real_,
        hypertension_dementia_events = NA_real_,
        non_hypertension_N = NA_real_,
        non_hypertension_dementia_events = NA_real_
      )
    )
  }
  
  exposure_value <- as.character(data$baseline_onlyhyper)
  event_value <- safe_numeric(data[[event_variable]])
  
  is_hypertension <- exposure_value %in% c(
    "高血压且无糖尿病", "1"
  )
  is_non_hypertension <- exposure_value %in% c(
    "无高血压且无糖尿病", "0"
  )
  
  tibble(
    hypertension_N = sum(is_hypertension, na.rm = TRUE),
    
    hypertension_dementia_events = sum(
      is_hypertension & event_value == 1,
      na.rm = TRUE
    ),
    
    non_hypertension_N = sum(
      is_non_hypertension,
      na.rm = TRUE
    ),
    
    non_hypertension_dementia_events = sum(
      is_non_hypertension & event_value == 1,
      na.rm = TRUE
    )
  )
}

# 将分组人数和事件数添加至各国模型结果。
append_exposure_group_counts <- function(
    model_result,
    data,
    event_variable = "event_status",
    count_basis = "分析数据中的实际人数和痴呆事件数"
) {
  
  bind_cols(
    model_result,
    summarise_exposure_group_counts(
      data = data,
      event_variable = event_variable
    )
  ) %>%
    mutate(
      exposure_group_count_basis = count_basis
    )
}

# 用每一个完成插补数据集分别统计暴露组人数和痴呆事件数。
summarise_mi_exposure_group_counts <- function(
    mi_object,
    country_name
) {
  
  if (is.null(mi_object)) {
    return(tibble())
  }
  
  mice::complete(
    mi_object,
    action = "long",
    include = FALSE
  ) %>%
    group_by(.imp) %>%
    summarise(
      hypertension_N = sum(
        as.character(baseline_onlyhyper) %in% c(
          "高血压且无糖尿病", "1"
        ),
        na.rm = TRUE
      ),
      
      hypertension_dementia_events = sum(
        as.character(baseline_onlyhyper) %in% c(
          "高血压且无糖尿病", "1"
        ) &
          event_status == 1,
        na.rm = TRUE
      ),
      
      non_hypertension_N = sum(
        as.character(baseline_onlyhyper) %in% c(
          "无高血压且无糖尿病", "0"
        ),
        na.rm = TRUE
      ),
      
      non_hypertension_dementia_events = sum(
        as.character(baseline_onlyhyper) %in% c(
          "无高血压且无糖尿病", "0"
        ) &
          event_status == 1,
        na.rm = TRUE
      ),
      
      .groups = "drop"
    ) %>%
    transmute(
      country = country_name,
      imputation = .imp,
      hypertension_N = hypertension_N,
      hypertension_dementia_events =
        hypertension_dementia_events,
      non_hypertension_N = non_hypertension_N,
      non_hypertension_dementia_events =
        non_hypertension_dementia_events
    )
}

# 将 20 个完成插补数据集的平均分组人数及平均事件数添加至模型结果。
append_mi_exposure_group_counts <- function(
    model_result,
    mi_group_counts
) {
  
  if (nrow(mi_group_counts) == 0) {
    return(
      model_result %>%
        mutate(
          hypertension_N = NA_real_,
          hypertension_dementia_events = NA_real_,
          non_hypertension_N = NA_real_,
          non_hypertension_dementia_events = NA_real_,
          exposure_group_count_basis = NA_character_
        )
    )
  }
  
  mean_counts <- mi_group_counts %>%
    summarise(
      hypertension_N = mean(hypertension_N, na.rm = TRUE),
      hypertension_dementia_events = mean(
        hypertension_dementia_events,
        na.rm = TRUE
      ),
      non_hypertension_N = mean(
        non_hypertension_N,
        na.rm = TRUE
      ),
      non_hypertension_dementia_events = mean(
        non_hypertension_dementia_events,
        na.rm = TRUE
      )
    )
  
  bind_cols(
    model_result,
    mean_counts
  ) %>%
    mutate(
      exposure_group_count_basis =
        "20个完成插补数据集的平均人数和平均痴呆事件数"
    )
}

empty_model_result <- function(
    country_name,
    n_total,
    n_events
) {
  
  tibble(
    country = country_name,
    N = n_total,
    events = n_events,
    HR = NA_real_,
    CI_lower = NA_real_,
    CI_upper = NA_real_,
    p_value = NA_real_,
    logHR = NA_real_,
    se_logHR = NA_real_
  )
}

extract_exposure_result <- function(
    fitted_model,
    country_name,
    n_total,
    n_events
) {
  
  model_result <- broom::tidy(
    fitted_model,
    conf.int = TRUE,
    exponentiate = TRUE
  )
  
  exposure_result <- model_result %>%
    filter(str_detect(term, "^baseline_onlyhyper"))
  
  if (nrow(exposure_result) != 1) {
    return(
      empty_model_result(
        country_name,
        n_total,
        n_events
      )
    )
  }
  
  tibble(
    country = country_name,
    N = n_total,
    events = n_events,
    HR = exposure_result$estimate,
    CI_lower = exposure_result$conf.low,
    CI_upper = exposure_result$conf.high,
    p_value = exposure_result$p.value,
    logHR = log(exposure_result$estimate),
    se_logHR = exposure_result$std.error
  )
}

run_cox_by_country <- function(
    dt,
    country_name,
    use_continuous_age = FALSE
) {
  
  n_total <- nrow(dt)
  
  n_events <- sum(
    dt$event_status == 1,
    na.rm = TRUE
  )
  
  if (n_total == 0 ||
      n_events == 0 ||
      nlevels(droplevels(dt$baseline_onlyhyper)) < 2) {
    return(
      append_exposure_group_counts(
        model_result = empty_model_result(
          country_name,
          n_total,
          n_events
        ),
        data = dt,
        event_variable = "event_status"
      )
    )
  }
  
  age_term <- if (use_continuous_age) {
    "age"
  } else {
    "yearsold"
  }
  
  model_formula <- as.formula(
    paste(
      "Surv(time_to_event, event_status) ~",
      paste(
        c(
          "baseline_onlyhyper",
          age_term,
          "ragender",
          "raeduc_c",
          "baseline_phyactivities",
          "baseline_netuse",
          "baseline_mstat",
          "baseline_scocwk",
          "baseline_smoking",
          "baseline_drink",
          "baseline_Non_com_dis"
        ),
        collapse = " + "
      )
    )
  )
  
  cox_model <- tryCatch(
    coxph(
      formula = model_formula,
      data = dt,
      x = TRUE
    ),
    error = function(e) {
      message(
        country_name,
        " Cox 模型拟合失败：",
        e$message
      )
      
      NULL
    }
  )
  
  if (is.null(cox_model)) {
    return(
      append_exposure_group_counts(
        model_result = empty_model_result(
          country_name,
          n_total,
          n_events
        ),
        data = dt,
        event_variable = "event_status"
      )
    )
  }
  
  append_exposure_group_counts(
    model_result = extract_exposure_result(
      fitted_model = cox_model,
      country_name = country_name,
      n_total = n_total,
      n_events = n_events
    ),
    data = dt,
    event_variable = "event_status"
  )
}

run_country_cox_models <- function(
    data,
    use_continuous_age = FALSE
) {
  
  bind_rows(
    lapply(country_levels, function(country_name) {
      
      run_cox_by_country(
        dt = data %>%
          filter(country == country_name),
        country_name = country_name,
        use_continuous_age = use_continuous_age
      )
    })
  )
}

run_random_effect_meta <- function(
    model_results,
    analysis_name
) {
  
  meta_data <- model_results %>%
    filter(
      !is.na(logHR),
      !is.na(se_logHR),
      is.finite(logHR),
      is.finite(se_logHR),
      se_logHR > 0
    )
  
  if (nrow(meta_data) < 2) {
    return(
      tibble(
        analysis = analysis_name,
        countries_included = nrow(meta_data),
        pooled_HR = NA_real_,
        CI_lower = NA_real_,
        CI_upper = NA_real_,
        p_value = NA_real_,
        Q = NA_real_,
        df_Q = NA_real_,
        p_heterogeneity = NA_real_,
        I2_percent = NA_real_,
        tau2 = NA_real_
      )
    )
  }
  
  meta_model <- meta::metagen(
    TE = logHR,
    seTE = se_logHR,
    studlab = country,
    data = meta_data,
    sm = "HR",
    comb.fixed = FALSE,
    comb.random = TRUE,
    method.tau = "REML",
    hakn = FALSE
  )
  
  tibble(
    analysis = analysis_name,
    countries_included = nrow(meta_data),
    pooled_HR = exp(meta_model$TE.random),
    CI_lower = exp(meta_model$lower.random),
    CI_upper = exp(meta_model$upper.random),
    p_value = meta_model$pval.random,
    Q = meta_model$Q,
    df_Q = meta_model$df.Q,
    p_heterogeneity = meta_model$pval.Q,
    I2_percent = meta_model$I2 * 100,
    tau2 = meta_model$tau^2
  )
}

# =====================================================================
# 12. Fine-Gray 死亡竞争风险模型
# =====================================================================
run_fine_gray_by_country <- function(
    dt,
    country_name
) {
  
  n_total <- nrow(dt)
  
  n_events <- sum(
    dt$fg_status == 1,
    na.rm = TRUE
  )
  
  # 检查样本量、痴呆事件数和暴露变量是否具有两个水平。
  if (n_total == 0 ||
      n_events == 0 ||
      nlevels(droplevels(dt$baseline_onlyhyper)) < 2) {
    return(
      append_exposure_group_counts(
        model_result = empty_model_result(
          country_name = country_name,
          n_total = n_total,
          n_events = n_events
        ),
        data = dt,
        event_variable = "fg_status",
        count_basis =
          "Fine-Gray分析数据中的实际人数和痴呆竞争风险事件数"
      )
    )
  }
  
  fine_gray_formula <- ~
    baseline_onlyhyper +
    yearsold +
    ragender +
    raeduc_c +
    baseline_phyactivities +
    baseline_netuse +
    baseline_mstat +
    baseline_scocwk +
    baseline_smoking +
    baseline_drink +
    baseline_Non_com_dis
  
  # 构建 Fine-Gray 模型所需的数值协变量矩阵。
  covariate_matrix <- model.matrix(
    fine_gray_formula,
    data = dt
  )
  
  # 删除截距列。
  covariate_matrix <- covariate_matrix[
    ,
    colnames(covariate_matrix) != "(Intercept)",
    drop = FALSE
  ]
  
  fg_model <- tryCatch(
    cmprsk::crr(
      ftime = dt$fg_time,
      fstatus = dt$fg_status,
      cov1 = covariate_matrix,
      failcode = 1,
      cencode = 0
    ),
    error = function(e) {
      message(
        country_name,
        " Fine-Gray 模型拟合失败：",
        e$message
      )
      
      NULL
    }
  )
  
  if (is.null(fg_model)) {
    return(
      append_exposure_group_counts(
        model_result = empty_model_result(
          country_name = country_name,
          n_total = n_total,
          n_events = n_events
        ),
        data = dt,
        event_variable = "fg_status",
        count_basis =
          "Fine-Gray分析数据中的实际人数和痴呆竞争风险事件数"
      )
    )
  }
  
  # 在模型系数中定位暴露变量 baseline_onlyhyper 的对应系数。
  exposure_index <- grep(
    "^baseline_onlyhyper",
    names(fg_model$coef)
  )
  
  if (length(exposure_index) != 1) {
    message(
      country_name,
      " Fine-Gray 模型中未能唯一识别 baseline_onlyhyper 系数。"
    )
    
    return(
      append_exposure_group_counts(
        model_result = empty_model_result(
          country_name = country_name,
          n_total = n_total,
          n_events = n_events
        ),
        data = dt,
        event_variable = "fg_status",
        count_basis =
          "Fine-Gray分析数据中的实际人数和痴呆竞争风险事件数"
      )
    )
  }
  
  # crr() 的方差矩阵通常没有列名或行名。
  # 因此必须依据暴露变量在系数向量中的位置提取标准误，
  # 不应使用变量名称进行索引。
  beta <- unname(fg_model$coef[exposure_index])
  
  variance_value <- fg_model$var[
    exposure_index,
    exposure_index
  ]
  
  standard_error <- sqrt(variance_value)
  
  # 方差矩阵异常时返回空结果，避免产生错误置信区间。
  if (is.na(standard_error) ||
      !is.finite(standard_error) ||
      standard_error <= 0) {
    message(
      country_name,
      " Fine-Gray 模型标准误无法计算，请检查协变量共线性或样本分布。"
    )
    
    return(
      append_exposure_group_counts(
        model_result = empty_model_result(
          country_name = country_name,
          n_total = n_total,
          n_events = n_events
        ),
        data = dt,
        event_variable = "fg_status",
        count_basis =
          "Fine-Gray分析数据中的实际人数和痴呆竞争风险事件数"
      )
    )
  }
  
  z_value <- beta / standard_error
  
  append_exposure_group_counts(
    model_result = tibble(
      country = country_name,
      N = n_total,
      events = n_events,
      HR = exp(beta),
      CI_lower = exp(beta - 1.96 * standard_error),
      CI_upper = exp(beta + 1.96 * standard_error),
      p_value = 2 * pnorm(
        abs(z_value),
        lower.tail = FALSE
      ),
      logHR = beta,
      se_logHR = standard_error
    ),
    data = dt,
    event_variable = "fg_status",
    count_basis =
      "Fine-Gray分析数据中的实际人数和痴呆竞争风险事件数"
  )
}

run_fine_gray_models <- function(data) {
  
  bind_rows(
    lapply(country_levels, function(country_name) {
      
      run_fine_gray_by_country(
        dt = data %>%
          filter(country == country_name),
        country_name = country_name
      )
    })
  )
}

# =====================================================================
# 13. 多重插补：缺失比例及缺失模式
# =====================================================================
get_missing_summary <- function(
    data,
    country_name,
    stage
) {
  
  tibble(
    country = country_name,
    stage = stage,
    variable = names(data),
    missing_n = colSums(is.na(data)),
    total_n = nrow(data),
    missing_percent = round(
      colMeans(is.na(data)) * 100,
      2
    )
  ) %>%
    arrange(
      desc(missing_percent),
      variable
    )
}

save_missing_pattern <- function(
    data,
    country_name
) {
  
  output_file <- paste0(
    "敏感性分析6_",
    country_name,
    "_缺失模式.txt"
  )
  
  sink(output_file)
  
  cat("====================================================\n")
  cat("国家：", country_name, "\n")
  cat("多重插补前缺失模式\n")
  cat("====================================================\n\n")
  
  print(mice::md.pattern(data, plot = FALSE))
  
  sink()
}

# =====================================================================
# 14. 多重插补：MAR 假设支持性描述
#
# MAR 无法由统计检验直接证明。
# 以下结果用于描述缺失是否与已观测的年龄、结局和随访时间相关，
# 为 MAR 假设提供可报告的支持性信息。
# =====================================================================
create_mar_support_table <- function(
    data,
    country_name
) {
  
  candidate_variables <- c(
    "age",
    "time_to_event",
    "event_status",
    "baseline_onlyhyper",
    "yearsold",
    "ragender",
    "raeduc_c",
    "baseline_phyactivities",
    "baseline_netuse",
    "baseline_mstat",
    "baseline_scocwk",
    "baseline_smoking",
    "baseline_drink",
    "baseline_Non_com_dis"
  )
  
  candidate_variables <- intersect(
    candidate_variables,
    names(data)
  )
  
  missing_variables <- candidate_variables[
    colSums(is.na(data[candidate_variables])) > 0
  ]
  
  if (length(missing_variables) == 0) {
    return(
      tibble(
        country = country_name,
        variable = NA_character_,
        missing_n = NA_integer_,
        non_missing_n = NA_integer_,
        mean_age_missing = NA_real_,
        mean_age_non_missing = NA_real_,
        event_percent_missing = NA_real_,
        event_percent_non_missing = NA_real_,
        mean_followup_missing = NA_real_,
        mean_followup_non_missing = NA_real_
      )
    )
  }
  
  bind_rows(
    lapply(missing_variables, function(variable_name) {
      
      missing_indicator <- is.na(data[[variable_name]])
      
      missing_group <- data[missing_indicator, , drop = FALSE]
      observed_group <- data[!missing_indicator, , drop = FALSE]
      
      tibble(
        country = country_name,
        variable = variable_name,
        missing_n = nrow(missing_group),
        non_missing_n = nrow(observed_group),
        
        mean_age_missing = if (
          all(is.na(missing_group$age))
        ) {
          NA_real_
        } else {
          mean(missing_group$age, na.rm = TRUE)
        },
        
        mean_age_non_missing = if (
          all(is.na(observed_group$age))
        ) {
          NA_real_
        } else {
          mean(observed_group$age, na.rm = TRUE)
        },
        
        event_percent_missing = if (
          all(is.na(missing_group$event_status))
        ) {
          NA_real_
        } else {
          mean(
            missing_group$event_status == 1,
            na.rm = TRUE
          ) * 100
        },
        
        event_percent_non_missing = if (
          all(is.na(observed_group$event_status))
        ) {
          NA_real_
        } else {
          mean(
            observed_group$event_status == 1,
            na.rm = TRUE
          ) * 100
        },
        
        mean_followup_missing = if (
          all(is.na(missing_group$time_to_event))
        ) {
          NA_real_
        } else {
          mean(
            missing_group$time_to_event,
            na.rm = TRUE
          )
        },
        
        mean_followup_non_missing = if (
          all(is.na(observed_group$time_to_event))
        ) {
          NA_real_
        } else {
          mean(
            observed_group$time_to_event,
            na.rm = TRUE
          )
        }
      )
    })
  )
}

# =====================================================================
# 15. 多重插补：插补前后分布比较
# =====================================================================
summarise_numeric_distribution <- function(
    data,
    variable_name,
    country_name,
    stage
) {
  
  value <- safe_numeric(data[[variable_name]])
  
  tibble(
    country = country_name,
    stage = stage,
    variable = variable_name,
    variable_type = "连续变量",
    N = sum(!is.na(value)),
    mean = mean(value, na.rm = TRUE),
    sd = sd(value, na.rm = TRUE),
    median = median(value, na.rm = TRUE),
    q1 = quantile(value, 0.25, na.rm = TRUE),
    q3 = quantile(value, 0.75, na.rm = TRUE),
    min = min(value, na.rm = TRUE),
    max = max(value, na.rm = TRUE),
    level = NA_character_,
    n_level = NA_integer_,
    percent_level = NA_real_
  )
}

summarise_factor_distribution <- function(
    data,
    variable_name,
    country_name,
    stage
) {
  
  factor_value <- as.factor(data[[variable_name]])
  
  tibble(
    level = as.character(factor_value)
  ) %>%
    filter(!is.na(level)) %>%
    count(level, name = "n_level") %>%
    mutate(
      country = country_name,
      stage = stage,
      variable = variable_name,
      variable_type = "分类变量",
      N = sum(n_level),
      mean = NA_real_,
      sd = NA_real_,
      median = NA_real_,
      q1 = NA_real_,
      q3 = NA_real_,
      min = NA_real_,
      max = NA_real_,
      percent_level = round(
        n_level / N * 100,
        2
      )
    ) %>%
    select(
      country,
      stage,
      variable,
      variable_type,
      N,
      mean,
      sd,
      median,
      q1,
      q3,
      min,
      max,
      level,
      n_level,
      percent_level
    )
}

create_distribution_table <- function(
    original_data,
    completed_data,
    country_name
) {
  
  distribution_variables <- c(
    "age",
    "baseline_onlyhyper",
    "yearsold",
    "ragender",
    "raeduc_c",
    "baseline_phyactivities",
    "baseline_netuse",
    "baseline_mstat",
    "baseline_scocwk",
    "baseline_smoking",
    "baseline_drink",
    "baseline_Non_com_dis"
  )
  
  distribution_variables <- intersect(
    distribution_variables,
    names(original_data)
  )
  
  bind_rows(
    lapply(distribution_variables, function(variable_name) {
      
      is_continuous <- is.numeric(
        original_data[[variable_name]]
      ) &&
        variable_name == "age"
      
      if (is_continuous) {
        bind_rows(
          summarise_numeric_distribution(
            original_data,
            variable_name,
            country_name,
            "插补前观测值"
          ),
          summarise_numeric_distribution(
            completed_data,
            variable_name,
            country_name,
            "插补后数据"
          )
        )
      } else {
        bind_rows(
          summarise_factor_distribution(
            original_data,
            variable_name,
            country_name,
            "插补前观测值"
          ),
          summarise_factor_distribution(
            completed_data,
            variable_name,
            country_name,
            "插补后数据"
          )
        )
      }
    })
  )
}

save_mi_distribution_plots <- function(
    mi_object,
    mi_data,
    country_name
) {
  
  variables_with_missing <- names(mi_data)[
    colSums(is.na(mi_data)) > 0
  ]
  
  # 这些变量是结局或生存分析预测变量，不属于待诊断的插补变量。
  variables_with_missing <- setdiff(
    variables_with_missing,
    c(
      "time_to_event",
      "event_status",
      "nelson_aalen"
    )
  )
  
  if (length(variables_with_missing) == 0) {
    return(invisible(NULL))
  }
  
  # 包含 .imp = 0 的原始数据和全部完成插补数据集。
  long_data <- mice::complete(
    mi_object,
    action = "long",
    include = TRUE
  ) %>%
    mutate(
      imputation_group = if_else(
        .imp == 0,
        "插补前观测数据",
        "插补后完成数据"
      )
    )
  
  output_file <- paste0(
    "敏感性分析6_",
    country_name,
    "_插补前后分布比较图.pdf"
  )
  
  grDevices::pdf(
    file = output_file,
    width = 12,
    height = 8
  )
  
  on.exit(
    grDevices::dev.off(),
    add = TRUE
  )
  
  for (variable_name in variables_with_missing) {
    
    plot_data <- long_data %>%
      transmute(
        imputation_group = imputation_group,
        value = .data[[variable_name]]
      ) %>%
      filter(!is.na(value))
    
    if (nrow(plot_data) == 0) {
      next
    }
    
    # 只有原始变量为数值型时绘制密度图；其余变量绘制类别比例图。
    if (is.numeric(mi_data[[variable_name]])) {
      
      plot_data <- plot_data %>%
        mutate(value = as.numeric(value))
      
      distribution_plot <- ggplot(
        plot_data,
        aes(
          x = value,
          colour = imputation_group,
          fill = imputation_group
        )
      ) +
        geom_density(alpha = 0.20, na.rm = TRUE) +
        labs(
          title = paste0(
            country_name,
            "：",
            variable_name,
            " 插补前后密度分布比较"
          ),
          x = variable_name,
          y = "密度",
          colour = NULL,
          fill = NULL
        ) +
        theme_bw()
      
    } else {
      
      plot_data <- plot_data %>%
        mutate(value = as.factor(value))
      
      distribution_plot <- ggplot(
        plot_data,
        aes(
          x = value,
          fill = imputation_group
        )
      ) +
        geom_bar(
          position = "fill",
          na.rm = TRUE
        ) +
        scale_y_continuous(
          labels = scales::percent_format(accuracy = 1)
        ) +
        labs(
          title = paste0(
            country_name,
            "：",
            variable_name,
            " 插补前后类别比例比较"
          ),
          x = variable_name,
          y = "组内比例",
          fill = NULL
        ) +
        theme_bw()
    }
    
    print(distribution_plot)
  }
  
  invisible(NULL)
}

# =====================================================================
# 16. 多重插补：收敛诊断
# =====================================================================
save_mi_convergence_diagnostics <- function(
    mi_object,
    country_name
) {
  
  if (is.null(mi_object)) {
    return(invisible(NULL))
  }
  
  pdf(
    file = paste0(
      "敏感性分析6_",
      country_name,
      "_MICE收敛诊断图.pdf"
    ),
    width = 12,
    height = 8
  )
  
  # 输出每个插补链均值和标准差的迭代轨迹。
  print(plot(mi_object))
  
  dev.off()
  
  invisible(NULL)
}

# =====================================================================
# 17. 多重插补：按国家运行 MICE 和 Cox
#
# 插补方法：
# 1. 连续变量 age：预测均值匹配 pmm；
# 2. 二分类变量：logreg；
# 3. 无序多分类变量：polyreg；
# 4. time_to_event、event_status、nelson_aalen：
#    仅作为预测变量，不进行插补。
#
# 注意：
#   baseline_onlyhyper（高血压暴露）和 baseline_diabetes
#   是入组条件，在筛选阶段已确保非缺失且糖尿病为 0，
#   因此不参与插补。
# =====================================================================
run_mi_cox_by_country <- function(
    dt,
    country_name,
    m = 20L,
    maxit = 20L,
    seed = 20260317L
) {
  
  mi_variables <- c(
    "time_to_event",
    "event_status",
    "baseline_onlyhyper",
    "yearsold",
    "age",
    "ragender",
    "raeduc_c",
    "baseline_phyactivities",
    "baseline_netuse",
    "baseline_mstat",
    "baseline_scocwk",
    "baseline_smoking",
    "baseline_drink",
    "baseline_Non_com_dis"
  )
  
  mi_variables <- intersect(
    mi_variables,
    names(dt)
  )
  
  mi_data <- dt %>%
    select(any_of(mi_variables)) %>%
    filter(
      !is.na(time_to_event),
      !is.na(event_status),
      time_to_event > 0
    ) %>%
    mutate(
      time_to_event = safe_numeric(time_to_event),
      event_status = as.integer(event_status),
      age = safe_numeric(age),
      
      baseline_onlyhyper = droplevels(
        as.factor(baseline_onlyhyper)
      ),
      
      yearsold = droplevels(
        as.factor(yearsold)
      ),
      
      ragender = droplevels(
        as.factor(ragender)
      ),
      
      raeduc_c = droplevels(
        as.factor(raeduc_c)
      ),
      
      baseline_phyactivities = droplevels(
        as.factor(baseline_phyactivities)
      ),
      
      baseline_netuse = droplevels(
        as.factor(baseline_netuse)
      ),
      
      baseline_mstat = droplevels(
        as.factor(baseline_mstat)
      ),
      
      baseline_scocwk = droplevels(
        as.factor(baseline_scocwk)
      ),
      
      baseline_smoking = droplevels(
        as.factor(baseline_smoking)
      ),
      
      baseline_drink = droplevels(
        as.factor(baseline_drink)
      ),
      
      baseline_Non_com_dis = droplevels(
        as.factor(baseline_Non_com_dis)
      )
    )
  
  required_cox_variables <- c(
    "time_to_event",
    "event_status",
    "baseline_onlyhyper",
    "yearsold",
    "ragender",
    "raeduc_c",
    "baseline_phyactivities",
    "baseline_netuse",
    "baseline_mstat",
    "baseline_scocwk",
    "baseline_smoking",
    "baseline_drink",
    "baseline_Non_com_dis"
  )
  
  missing_cox_variables <- setdiff(
    required_cox_variables,
    names(mi_data)
  )
  
  if (length(missing_cox_variables) > 0) {
    stop(
      country_name,
      " 缺少 Cox 多重插补分析所需变量：",
      paste(missing_cox_variables, collapse = ", ")
    )
  }
  
  # Nelson-Aalen 累积风险估计纳入预测模型。
  mi_data$nelson_aalen <- mice::nelsonaalen(
    data = mi_data,
    timevar = "time_to_event",
    statusvar = "event_status"
  )
  
  n_total <- nrow(mi_data)
  
  n_events <- sum(
    mi_data$event_status == 1,
    na.rm = TRUE
  )
  
  missing_before <- get_missing_summary(
    data = mi_data,
    country_name = country_name,
    stage = "插补前"
  )
  
  mar_support_table <- create_mar_support_table(
    data = mi_data,
    country_name = country_name
  )
  
  save_missing_pattern(
    data = mi_data,
    country_name = country_name
  )
  
  if (n_total == 0 || n_events == 0) {
    return(
      list(
        result = append_mi_exposure_group_counts(
          model_result = empty_model_result(
            country_name,
            n_total,
            n_events
          ),
          mi_group_counts = tibble()
        ),
        group_counts = tibble(),
        missing_before = missing_before,
        missing_after = tibble(),
        mar_support = mar_support_table,
        distribution_comparison = tibble(),
        imputation_methods = tibble(),
        predictor_matrix = tibble(),
        mi_object = NULL
      )
    )
  }
  
  predictor_matrix <- mice::make.predictorMatrix(mi_data)
  
  imputation_method <- mice::make.method(mi_data)
  
  # 连续年龄变量采用预测均值匹配。
  if ("age" %in% names(mi_data)) {
    imputation_method["age"] <- "pmm"
  }
  
  # 二分类变量采用 Logistic 回归插补。
  binary_variables <- c(
    "baseline_onlyhyper",
    "ragender",
    "baseline_phyactivities",
    "baseline_netuse",
    "baseline_mstat",
    "baseline_scocwk",
    "baseline_drink",
    "baseline_Non_com_dis"
  )
  
  binary_variables <- intersect(
    binary_variables,
    names(mi_data)
  )
  
  for (variable_name in binary_variables) {
    if (nlevels(mi_data[[variable_name]]) == 2) {
      imputation_method[variable_name] <- "logreg"
    }
  }
  
  # 无序多分类变量采用多项 Logistic 回归。
  unordered_multicategory_variables <- c(
    "yearsold",
    "raeduc_c",
    "baseline_smoking"
  )
  
  unordered_multicategory_variables <- intersect(
    unordered_multicategory_variables,
    names(mi_data)
  )
  
  for (variable_name in unordered_multicategory_variables) {
    if (nlevels(mi_data[[variable_name]]) > 2) {
      imputation_method[variable_name] <- "polyreg"
    }
  }
  
  # 随访时间、结局及 Nelson-Aalen 估计仅参与预测，不被插补。
  non_imputed_variables <- c(
    "time_to_event",
    "event_status",
    "nelson_aalen"
  )
  
  for (variable_name in non_imputed_variables) {
    predictor_matrix[variable_name, ] <- 0
    imputation_method[variable_name] <- ""
  }
  
  # 删除没有变异的变量，避免插补模型发生奇异拟合。
  for (variable_name in names(mi_data)) {
    
    observed_values <- unique(
      stats::na.omit(mi_data[[variable_name]])
    )
    
    if (length(observed_values) <= 1) {
      predictor_matrix[, variable_name] <- 0
      predictor_matrix[variable_name, ] <- 0
      imputation_method[variable_name] <- ""
    }
  }
  
  # 防止变量使用自身预测自身。
  diag(predictor_matrix) <- 0
  
  mi_object <- tryCatch(
    mice::mice(
      data = mi_data,
      m = m,
      maxit = maxit,
      method = imputation_method,
      predictorMatrix = predictor_matrix,
      seed = seed,
      printFlag = FALSE
    ),
    error = function(e) {
      message(
        country_name,
        " 多重插补失败：",
        e$message
      )
      
      NULL
    }
  )
  
  imputation_methods_table <- tibble(
    country = country_name,
    variable = names(imputation_method),
    imputation_method = unname(imputation_method),
    imputed = if_else(
      imputation_method == "",
      "否",
      "是"
    )
  )
  
  predictor_matrix_table <- as.data.frame(
    predictor_matrix
  ) %>%
    mutate(target_variable = rownames(predictor_matrix)) %>%
    select(target_variable, everything()) %>%
    mutate(country = country_name)
  
  if (is.null(mi_object)) {
    return(
      list(
        result = append_mi_exposure_group_counts(
          model_result = empty_model_result(
            country_name,
            n_total,
            n_events
          ),
          mi_group_counts = tibble()
        ),
        group_counts = tibble(),
        missing_before = missing_before,
        missing_after = tibble(),
        mar_support = mar_support_table,
        distribution_comparison = tibble(),
        imputation_methods = imputation_methods_table,
        predictor_matrix = predictor_matrix_table,
        mi_object = NULL
      )
    )
  }
  
  # 使用第一个完成数据集计算插补后缺失比例和分布表。
  completed_data_first <- mice::complete(
    mi_object,
    action = 1
  )
  
  # 在每一个完成插补数据集中分别计算分组人数及痴呆事件数。
  mi_group_counts <- summarise_mi_exposure_group_counts(
    mi_object = mi_object,
    country_name = country_name
  )
  
  missing_after <- get_missing_summary(
    data = completed_data_first,
    country_name = country_name,
    stage = "插补后"
  )
  
  distribution_comparison <- create_distribution_table(
    original_data = mi_data,
    completed_data = completed_data_first,
    country_name = country_name
  )
  
  save_mi_distribution_plots(
    mi_object = mi_object,
    mi_data = mi_data,
    country_name = country_name
  )
  
  save_mi_convergence_diagnostics(
    mi_object = mi_object,
    country_name = country_name
  )
  
  mi_cox_models <- tryCatch(
    with(
      data = mi_object,
      expr = survival::coxph(
        survival::Surv(
          time_to_event,
          event_status
        ) ~
          baseline_onlyhyper +
          yearsold +
          ragender +
          raeduc_c +
          baseline_phyactivities +
          baseline_netuse +
          baseline_mstat +
          baseline_scocwk +
          baseline_smoking +
          baseline_drink +
          baseline_Non_com_dis,
        x = TRUE,
        model = TRUE
      )
    ),
    error = function(e) {
      message(
        country_name,
        " 插补后 Cox 模型拟合失败：",
        conditionMessage(e)
      )
      
      NULL
    }
  )
  
  if (is.null(mi_cox_models)) {
    return(
      list(
        result = append_mi_exposure_group_counts(
          model_result = empty_model_result(
            country_name,
            n_total,
            n_events
          ),
          mi_group_counts = mi_group_counts
        ),
        group_counts = mi_group_counts,
        missing_before = missing_before,
        missing_after = missing_after,
        mar_support = mar_support_table,
        distribution_comparison = distribution_comparison,
        imputation_methods = imputation_methods_table,
        predictor_matrix = predictor_matrix_table,
        mi_object = mi_object
      )
    )
  }
  
  pooled_model <- mice::pool(mi_cox_models)
  
  pooled_result <- summary(
    pooled_model,
    conf.int = TRUE,
    exponentiate = FALSE
  )
  
  exposure_result <- pooled_result %>%
    filter(str_detect(term, "^baseline_onlyhyper"))
  
  if (nrow(exposure_result) != 1) {
    
    final_result <- empty_model_result(
      country_name,
      n_total,
      n_events
    )
    
  } else {
    
    final_result <- tibble(
      country = country_name,
      N = n_total,
      events = n_events,
      HR = exp(exposure_result$estimate),
      CI_lower = exp(exposure_result$`2.5 %`),
      CI_upper = exp(exposure_result$`97.5 %`),
      p_value = exposure_result$p.value,
      logHR = exposure_result$estimate,
      se_logHR = exposure_result$std.error
    )
  }
  
  # 对存在暴露缺失的个体，组别可能因插补而变化。
  # 因此模型结果报告 20 个完成插补数据集的平均人数和平均事件数。
  final_result <- append_mi_exposure_group_counts(
    model_result = final_result,
    mi_group_counts = mi_group_counts
  )
  
  list(
    result = final_result,
    group_counts = mi_group_counts,
    missing_before = missing_before,
    missing_after = missing_after,
    mar_support = mar_support_table,
    distribution_comparison = distribution_comparison,
    imputation_methods = imputation_methods_table,
    predictor_matrix = predictor_matrix_table,
    mi_object = mi_object
  )
}

# =====================================================================
# 18. 格式化模型结果
# =====================================================================
format_model_result <- function(
    data,
    analysis_name
) {
  
  data %>%
    mutate(
      analysis = analysis_name,
      
      HR_95CI = case_when(
        is.na(HR) ~ NA_character_,
        TRUE ~ sprintf(
          "%.3f (%.3f-%.3f)",
          HR,
          CI_lower,
          CI_upper
        )
      ),
      
      p_display = case_when(
        is.na(p_value) ~ NA_character_,
        p_value < 0.001 ~ "<0.001",
        TRUE ~ sprintf("%.3f", p_value)
      )
    )
}

format_meta_result <- function(data) {
  
  data %>%
    mutate(
      pooled_HR_95CI = case_when(
        is.na(pooled_HR) ~ NA_character_,
        TRUE ~ sprintf(
          "%.3f (%.3f-%.3f)",
          pooled_HR,
          CI_lower,
          CI_upper
        )
      ),
      
      p_display = case_when(
        is.na(p_value) ~ NA_character_,
        p_value < 0.001 ~ "<0.001",
        TRUE ~ sprintf("%.3f", p_value)
      ),
      
      heterogeneity_p_display = case_when(
        is.na(p_heterogeneity) ~ NA_character_,
        p_heterogeneity < 0.001 ~ "<0.001",
        TRUE ~ sprintf("%.3f", p_heterogeneity)
      )
    )
}

# =====================================================================
# 19. 主分析
# =====================================================================
cat("\n====================================================\n")
cat("开始主分析：读取 ", main_data_file, "\n", sep = "")
cat("====================================================\n")

raw_main_data <- read_and_validate_data(main_data_file)

main_analysis_object <- build_analysis_data(
  raw_data = raw_main_data,
  require_complete_case = TRUE
)

screened_main_data <- main_analysis_object$screened_data
cox_data_final <- main_analysis_object$analysis_data

main_country_results <- run_country_cox_models(
  data = cox_data_final,
  use_continuous_age = FALSE
)

main_meta_result <- run_random_effect_meta(
  model_results = main_country_results,
  analysis_name = "主分析"
)

# =====================================================================
# 20. 敏感性分析1：连续年龄 age 调整
# =====================================================================
sensitivity1_country_results <- run_country_cox_models(
  data = cox_data_final,
  use_continuous_age = TRUE
)

sensitivity1_meta_result <- run_random_effect_meta(
  model_results = sensitivity1_country_results,
  analysis_name = "敏感性分析1：连续年龄调整"
)

# =====================================================================
# 21. 敏感性分析2：滞后分析
# =====================================================================
run_lag_analysis <- function(
    data,
    lag_years
) {
  
  # 仅排除指定滞后期内发生痴呆事件的参与者。
  lagged_data <- data %>%
    filter(
      !(event_status == 1 & time_to_event <= lag_years)
    )
  
  country_results <- run_country_cox_models(
    data = lagged_data,
    use_continuous_age = FALSE
  ) %>%
    mutate(lag_years = lag_years)
  
  meta_result <- run_random_effect_meta(
    model_results = country_results,
    analysis_name = paste0(
      "敏感性分析2：排除基线后",
      lag_years,
      "年内痴呆事件"
    )
  ) %>%
    mutate(lag_years = lag_years)
  
  list(
    data = lagged_data,
    country_results = country_results,
    meta_result = meta_result
  )
}

lag_1_year <- run_lag_analysis(
  cox_data_final,
  lag_years = 1
)

lag_2_year <- run_lag_analysis(
  cox_data_final,
  lag_years = 2
)

lag_3_year <- run_lag_analysis(
  cox_data_final,
  lag_years = 3
)

sensitivity2_country_results <- bind_rows(
  lag_1_year$country_results,
  lag_2_year$country_results,
  lag_3_year$country_results
)

sensitivity2_meta_results <- bind_rows(
  lag_1_year$meta_result,
  lag_2_year$meta_result,
  lag_3_year$meta_result
)

# =====================================================================
# 22. 敏感性分析3：Fine-Gray 死亡竞争风险模型
# =====================================================================
sensitivity3_country_results <- run_fine_gray_models(
  cox_data_final
)

sensitivity3_meta_result <- run_random_effect_meta(
  model_results = sensitivity3_country_results,
  analysis_name = "敏感性分析3：Fine-Gray死亡竞争风险模型"
)

# =====================================================================
# 23. 敏感性分析4：逐一排除国家 Meta 分析
# =====================================================================
sensitivity4_meta_results <- bind_rows(
  lapply(country_levels, function(excluded_country) {
    
    remaining_country_results <- main_country_results %>%
      filter(country != excluded_country)
    
    run_random_effect_meta(
      model_results = remaining_country_results,
      analysis_name = paste0(
        "敏感性分析4：排除",
        excluded_country
      )
    ) %>%
      mutate(excluded_country = excluded_country)
  })
)

# 每次逐一排除国家时，保留其余国家在主分析完整案例数据中的
# 暴露组人数与痴呆事件数。
main_country_group_counts <- cox_data_final %>%
  group_by(country) %>%
  group_modify(~ summarise_exposure_group_counts(
    data = .x,
    event_variable = "event_status"
  )) %>%
  ungroup()

sensitivity4_country_group_counts <- bind_rows(
  lapply(country_levels, function(excluded_country) {
    
    main_country_group_counts %>%
      filter(country != excluded_country) %>%
      mutate(
        analysis = paste0(
          "敏感性分析4：排除",
          excluded_country
        ),
        excluded_country = excluded_country,
        exposure_group_count_basis =
          "主分析完整案例数据中的实际人数和痴呆事件数"
      )
  })
)

# =====================================================================
# 24. 敏感性分析5：基于25项认知量表统一痴呆判定算法
#     （onlyhyper_data.dta）
#
# 四个数据库均采用基于25项认知量表的统一痴呆判定算法。
# 仅在主分析基础上将原始数据更换为 onlyhyper_data.dta，
# 其余动态基线筛选（含排除基线糖尿病）、协变量调整、
# Cox 回归和随机效应 Meta 分析流程与主分析完全一致。
# =====================================================================
cat("\n====================================================\n")
cat("开始敏感性分析5：读取 ", complete_case_data_file, "\n", sep = "")
cat("====================================================\n")

raw_sensitivity5_data <- read_and_validate_data(complete_case_data_file)

sensitivity5_analysis_object <- build_analysis_data(
  raw_data = raw_sensitivity5_data,
  require_complete_case = TRUE
)

sensitivity5_screened_data <- sensitivity5_analysis_object$screened_data
sensitivity5_cox_data <- sensitivity5_analysis_object$analysis_data

sensitivity5_country_results <- run_country_cox_models(
  data = sensitivity5_cox_data,
  use_continuous_age = FALSE
)

sensitivity5_meta_result <- run_random_effect_meta(
  model_results = sensitivity5_country_results,
  analysis_name = "敏感性分析5：25项认知量表统一痴呆判定算法"
)

# 敏感性分析5流程图和样本量统计
sensitivity5_flow_table <- sensitivity5_screened_data %>%
  count(screening_status, name = "N") %>%
  mutate(
    screening_status = factor(
      screening_status,
      levels = flow_order
    ),
    percent_of_total = round(
      N / nrow(raw_sensitivity5_data) * 100,
      2
    )
  ) %>%
  arrange(screening_status)

sensitivity5_sample_by_country <- sensitivity5_cox_data %>%
  group_by(country) %>%
  summarise(
    N = n(),
    dementia_events = sum(
      event_status == 1,
      na.rm = TRUE
    ),
    non_events = sum(
      event_status == 0,
      na.rm = TRUE
    ),
    mean_followup_years = mean(
      time_to_event,
      na.rm = TRUE
    ),
    median_followup_years = median(
      time_to_event,
      na.rm = TRUE
    ),
    .groups = "drop"
  )

# =====================================================================
# 25. 敏感性分析6：按国家多重插补（m = 20）
#
# 重新读取原始数据。
# 使用 require_complete_case = FALSE 保留协变量缺失者。
# 暴露（onlyhyper）、糖尿病排除、基线痴呆和随访条件仍然必须满足。
# =====================================================================
cat("\n====================================================\n")
cat(
  "开始敏感性分析6：按国家多重插补，m = ",
  mi_m,
  "\n",
  sep = ""
)
cat("====================================================\n")

raw_mi_data <- read_and_validate_data(main_data_file)

mi_analysis_object <- build_analysis_data(
  raw_data = raw_mi_data,
  require_complete_case = FALSE
)

mi_source_data <- mi_analysis_object$analysis_data

mi_CHARLS <- run_mi_cox_by_country(
  dt = mi_source_data %>%
    filter(country == "CHARLS"),
  country_name = "CHARLS",
  m = mi_m,
  maxit = mi_maxit,
  seed = analysis_seed
)

mi_HRS <- run_mi_cox_by_country(
  dt = mi_source_data %>%
    filter(country == "HRS"),
  country_name = "HRS",
  m = mi_m,
  maxit = mi_maxit,
  seed = analysis_seed + 1L
)

mi_SHARE <- run_mi_cox_by_country(
  dt = mi_source_data %>%
    filter(country == "SHARE"),
  country_name = "SHARE",
  m = mi_m,
  maxit = mi_maxit,
  seed = analysis_seed + 2L
)

mi_ELSA <- run_mi_cox_by_country(
  dt = mi_source_data %>%
    filter(country == "ELSA"),
  country_name = "ELSA",
  m = mi_m,
  maxit = mi_maxit,
  seed = analysis_seed + 3L
)

sensitivity6_country_results <- bind_rows(
  mi_CHARLS$result,
  mi_HRS$result,
  mi_SHARE$result,
  mi_ELSA$result
)

sensitivity6_meta_result <- run_random_effect_meta(
  model_results = sensitivity6_country_results,
  analysis_name = "敏感性分析6：按国家多重插补后Cox分析（m=20）"
)

sensitivity6_missing_before <- bind_rows(
  mi_CHARLS$missing_before,
  mi_HRS$missing_before,
  mi_SHARE$missing_before,
  mi_ELSA$missing_before
)

sensitivity6_missing_after <- bind_rows(
  mi_CHARLS$missing_after,
  mi_HRS$missing_after,
  mi_SHARE$missing_after,
  mi_ELSA$missing_after
)

sensitivity6_mar_support <- bind_rows(
  mi_CHARLS$mar_support,
  mi_HRS$mar_support,
  mi_SHARE$mar_support,
  mi_ELSA$mar_support
)

sensitivity6_distribution_comparison <- bind_rows(
  mi_CHARLS$distribution_comparison,
  mi_HRS$distribution_comparison,
  mi_SHARE$distribution_comparison,
  mi_ELSA$distribution_comparison
)

sensitivity6_imputation_methods <- bind_rows(
  mi_CHARLS$imputation_methods,
  mi_HRS$imputation_methods,
  mi_SHARE$imputation_methods,
  mi_ELSA$imputation_methods
)

sensitivity6_predictor_matrices <- bind_rows(
  mi_CHARLS$predictor_matrix,
  mi_HRS$predictor_matrix,
  mi_SHARE$predictor_matrix,
  mi_ELSA$predictor_matrix
)

# 多重插补后，每一个完成插补数据集均保留实际整数人数与事件数。
sensitivity6_group_counts_by_imputation <- bind_rows(
  mi_CHARLS$group_counts,
  mi_HRS$group_counts,
  mi_SHARE$group_counts,
  mi_ELSA$group_counts
)

# 汇总 20 个插补数据集的均值、最小值和最大值。
sensitivity6_group_counts_summary <- sensitivity6_group_counts_by_imputation %>%
  pivot_longer(
    cols = c(
      hypertension_N,
      hypertension_dementia_events,
      non_hypertension_N,
      non_hypertension_dementia_events
    ),
    names_to = "indicator",
    values_to = "value"
  ) %>%
  group_by(country, indicator) %>%
  summarise(
    mean = mean(value, na.rm = TRUE),
    min = min(value, na.rm = TRUE),
    max = max(value, na.rm = TRUE),
    .groups = "drop"
  )

# =====================================================================
# 26. 主分析流程图和样本量统计
# =====================================================================
flow_table <- screened_main_data %>%
  count(screening_status, name = "N") %>%
  mutate(
    screening_status = factor(
      screening_status,
      levels = flow_order
    ),
    
    percent_of_total = round(
      N / nrow(raw_main_data) * 100,
      2
    )
  ) %>%
  arrange(screening_status)

flow_by_country <- screened_main_data %>%
  mutate(
    screening_status = factor(
      screening_status,
      levels = flow_order
    )
  ) %>%
  count(
    country,
    screening_status,
    name = "N"
  ) %>%
  tidyr::pivot_wider(
    names_from = screening_status,
    values_from = N,
    values_fill = 0
  )

analysis_sample_by_country <- cox_data_final %>%
  group_by(country) %>%
  summarise(
    N = n(),
    dementia_events = sum(
      event_status == 1,
      na.rm = TRUE
    ),
    non_events = sum(
      event_status == 0,
      na.rm = TRUE
    ),
    mean_followup_years = mean(
      time_to_event,
      na.rm = TRUE
    ),
    median_followup_years = median(
      time_to_event,
      na.rm = TRUE
    ),
    .groups = "drop"
  )

overall_analysis_sample <- cox_data_final %>%
  summarise(
    country = "总体（四国合并）",
    N = n(),
    dementia_events = sum(
      event_status == 1,
      na.rm = TRUE
    ),
    non_events = sum(
      event_status == 0,
      na.rm = TRUE
    ),
    mean_followup_years = mean(
      time_to_event,
      na.rm = TRUE
    ),
    median_followup_years = median(
      time_to_event,
      na.rm = TRUE
    )
  )

analysis_sample_summary <- bind_rows(
  analysis_sample_by_country,
  overall_analysis_sample
)

# =====================================================================
# 27. 汇总各国模型结果
# =====================================================================
all_country_model_results <- bind_rows(
  format_model_result(
    main_country_results,
    "主分析：完整案例Cox"
  ),
  
  format_model_result(
    sensitivity1_country_results,
    "敏感性分析1：连续年龄调整"
  ),
  
  format_model_result(
    sensitivity2_country_results %>%
      filter(lag_years == 1),
    "敏感性分析2：排除1年内痴呆事件"
  ),
  
  format_model_result(
    sensitivity2_country_results %>%
      filter(lag_years == 2),
    "敏感性分析2：排除2年内痴呆事件"
  ),
  
  format_model_result(
    sensitivity2_country_results %>%
      filter(lag_years == 3),
    "敏感性分析2：排除3年内痴呆事件"
  ),
  
  format_model_result(
    sensitivity3_country_results,
    "敏感性分析3：Fine-Gray竞争风险模型"
  ),
  
  format_model_result(
    sensitivity5_country_results,
    "敏感性分析5：25项认知量表统一痴呆判定算法"
  ),
  
  format_model_result(
    sensitivity6_country_results,
    "敏感性分析6：多重插补Cox（m=20）"
  )
)

# =====================================================================
# 28. 汇总 Meta 分析结果
# =====================================================================
all_meta_results <- bind_rows(
  main_meta_result,
  sensitivity1_meta_result,
  sensitivity2_meta_results,
  sensitivity3_meta_result,
  
  sensitivity4_meta_results %>%
    select(
      analysis,
      countries_included,
      pooled_HR,
      CI_lower,
      CI_upper,
      p_value,
      Q,
      df_Q,
      p_heterogeneity,
      I2_percent,
      tau2
    ),
  
  sensitivity5_meta_result,
  
  sensitivity6_meta_result
) %>%
  format_meta_result()

# =====================================================================
# 29. 完整案例与多重插补结果并列表
# =====================================================================
complete_case_vs_mi_country <- bind_rows(
  format_model_result(
    main_country_results,
    "完整案例Cox"
  ),
  
  format_model_result(
    sensitivity6_country_results,
    "多重插补Cox（m=20）"
  )
) %>%
  select(
    analysis,
    country,
    N,
    events,
    hypertension_N,
    hypertension_dementia_events,
    non_hypertension_N,
    non_hypertension_dementia_events,
    exposure_group_count_basis,
    HR,
    CI_lower,
    CI_upper,
    HR_95CI,
    p_value,
    p_display,
    logHR,
    se_logHR
  )

complete_case_vs_mi_meta <- bind_rows(
  main_meta_result %>%
    mutate(analysis = "完整案例Cox"),
  
  sensitivity6_meta_result %>%
    mutate(analysis = "多重插补Cox（m=20）")
) %>%
  format_meta_result()

# =====================================================================
# 30. 多重插补方法说明文件
# =====================================================================
mi_report_file <- "敏感性分析6_多重插补方法与MAR说明.txt"

sink(mi_report_file)

cat("====================================================\n")
cat("敏感性分析6：多重插补方法与 MAR 假设说明\n")
cat("====================================================\n\n")

cat("插补次数（m）：", mi_m, "\n")
cat("每条插补链迭代次数（maxit）：", mi_maxit, "\n")
cat("插补方式：按国家分别插补\n")
cat("插补国家：CHARLS、HRS、SHARE、ELSA\n\n")

cat("入组条件（不参与插补，筛选阶段已确定）：\n")
cat("1. 基线高血压暴露（baseline_onlyhyper）非缺失且取值为 0 或 1；\n")
cat("2. 基线糖尿病（baseline_diabetes）非缺失且取值为 0（排除糖尿病患者）；\n")
cat("3. 基线痴呆状态为 0；\n")
cat("4. 基线后至少存在一波痴呆随访。\n\n")

cat("插补模型纳入变量：\n")
cat("暴露变量：baseline_onlyhyper\n")
cat("结局变量：event_status\n")
cat("随访时间：time_to_event\n")
cat("生存风险预测变量：nelson_aalen\n")
cat("协变量：\n")
cat(
  paste(
    cox_covariates[
      cox_covariates != "baseline_onlyhyper"
    ],
    collapse = "\n"
  ),
  "\n\n"
)

cat("插补方法设定：\n")
cat("连续变量 age：预测均值匹配（pmm）\n")
cat("二分类变量：Logistic 回归插补（logreg）\n")
cat("多分类变量：多项 Logistic 回归插补（polyreg）\n")
cat("time_to_event、event_status、nelson_aalen：仅用于预测，不插补\n\n")

cat("MAR 假设说明：\n")
cat(
  "本研究假设数据在给定已观测的年龄、痴呆结局、随访时间、",
  "暴露和其他协变量后满足 MAR（Missing At Random）假设。\n",
  sep = ""
)
cat(
  "MAR 无法通过统计检验直接证明；本脚本输出缺失组与非缺失组的",
  "年龄、事件比例和随访时间比较表，用于提供描述性支持。\n\n",
  sep = ""
)

cat("高血压分组人数及痴呆事件数的报告口径：\n")
cat(
  "完整案例 Cox、连续年龄、滞后分析、Fine-Gray、统一痴呆判定算法",
  "分析：报告对应分析数据中的实际人数和痴呆事件数。\n",
  sep = ""
)
cat(
  "多重插补分析：模型结果中的高血压组和非高血压组人数及痴呆事件数，",
  "报告 20 个完成插补数据集的平均值；",
  "每个插补数据集的实际整数值另行导出。\n\n",
  sep = ""
)

cat("需报告的诊断文件：\n")
cat("1. 每国插补前变量缺失比例；\n")
cat("2. 每国插补后变量缺失比例；\n")
cat("3. 每国缺失模式文件；\n")
cat("4. 每国插补前后变量分布比较表和图；\n")
cat("5. 每国 MICE 收敛诊断图；\n")
cat("6. 每国实际插补方法和预测矩阵；\n")
cat("7. 每个完成插补数据集的高血压分组人数和痴呆事件数；\n")
cat("8. 20 个完成插补数据集的高血压分组统计汇总。\n")

sink()

# =====================================================================
# 31. 导出结果
# =====================================================================
readr::write_excel_csv(
  flow_table,
  "高血压-表1_主分析总体流程图样本量.csv"
)

readr::write_excel_csv(
  flow_by_country,
  "高血压-表2_主分析各国流程图样本量.csv"
)

readr::write_excel_csv(
  analysis_sample_summary,
  "高血压-表3_主分析最终样本量事件数及随访时间.csv"
)

readr::write_excel_csv(
  cox_data_final,
  "高血压-主分析_最终完整案例Cox分析数据.csv"
)

readr::write_excel_csv(
  main_country_results,
  "高血压-表4_主分析四国Cox回归结果.csv"
)

readr::write_excel_csv(
  main_meta_result,
  "高血压-表5_主分析随机效应Meta分析结果.csv"
)

readr::write_excel_csv(
  sensitivity1_country_results,
  "高血压-敏感性分析1_连续年龄调整_各国Cox结果.csv"
)

readr::write_excel_csv(
  sensitivity1_meta_result,
  "高血压-敏感性分析1_连续年龄调整_Meta结果.csv"
)

readr::write_excel_csv(
  sensitivity2_country_results,
  "高血压-敏感性分析2_滞后分析_各国Cox结果.csv"
)

readr::write_excel_csv(
  sensitivity2_meta_results,
  "高血压-敏感性分析2_滞后分析_Meta结果.csv"
)

readr::write_excel_csv(
  sensitivity3_country_results,
  "高血压-敏感性分析3_FineGray死亡竞争风险_各国结果.csv"
)

readr::write_excel_csv(
  sensitivity3_meta_result,
  "高血压-敏感性分析3_FineGray死亡竞争风险_Meta结果.csv"
)

readr::write_excel_csv(
  sensitivity4_meta_results,
  "高血压-敏感性分析4_逐一排除国家_Meta结果.csv"
)

readr::write_excel_csv(
  sensitivity4_country_group_counts,
  "高血压-敏感性分析4_逐一排除国家_各国暴露分组人数及痴呆事件数.csv"
)

readr::write_excel_csv(
  sensitivity5_flow_table,
  "高血压-敏感性分析5_统一痴呆判定_总体流程图样本量.csv"
)

readr::write_excel_csv(
  sensitivity5_sample_by_country,
  "高血压-敏感性分析5_统一痴呆判定_最终样本量事件数及随访时间.csv"
)

readr::write_excel_csv(
  sensitivity5_cox_data,
  "高血压-敏感性分析5_统一痴呆判定_最终完整案例Cox分析数据.csv"
)

readr::write_excel_csv(
  sensitivity5_country_results,
  "高血压-敏感性分析5_统一痴呆判定_各国Cox结果.csv"
)

readr::write_excel_csv(
  sensitivity5_meta_result,
  "高血压-敏感性分析5_统一痴呆判定_Meta结果.csv"
)

readr::write_excel_csv(
  mi_source_data,
  "高血压-敏感性分析6_插补前分析数据.csv"
)

readr::write_excel_csv(
  sensitivity6_country_results,
  "高血压-敏感性分析6_多重插补_各国Cox结果.csv"
)

readr::write_excel_csv(
  sensitivity6_meta_result,
  "高血压-敏感性分析6_多重插补_Meta结果.csv"
)

readr::write_excel_csv(
  sensitivity6_missing_before,
  "高血压-敏感性分析6_插补前变量缺失比例.csv"
)

readr::write_excel_csv(
  sensitivity6_missing_after,
  "高血压-敏感性分析6_插补后变量缺失比例.csv"
)

readr::write_excel_csv(
  sensitivity6_mar_support,
  "高血压-敏感性分析6_MAR假设支持性描述.csv"
)

readr::write_excel_csv(
  sensitivity6_distribution_comparison,
  "高血压-敏感性分析6_插补前后变量分布比较.csv"
)

readr::write_excel_csv(
  sensitivity6_imputation_methods,
  "高血压-敏感性分析6_实际插补方法.csv"
)

readr::write_excel_csv(
  sensitivity6_predictor_matrices,
  "高血压-敏感性分析6_插补预测矩阵.csv"
)

readr::write_excel_csv(
  sensitivity6_group_counts_by_imputation,
  "高血压-敏感性分析6_多重插补_各插补数据集暴露分组人数及痴呆事件数.csv"
)

readr::write_excel_csv(
  sensitivity6_group_counts_summary,
  "高血压-敏感性分析6_多重插补_暴露分组人数及痴呆事件数汇总.csv"
)

readr::write_excel_csv(
  all_country_model_results,
  "高血压-汇总_主分析及敏感性分析_各国模型结果.csv"
)

readr::write_excel_csv(
  all_meta_results,
  "高血压-汇总_主分析及敏感性分析_Meta结果.csv"
)

readr::write_excel_csv(
  complete_case_vs_mi_country,
  "高血压-表6_完整案例与多重插补_各国Cox结果并列.csv"
)

readr::write_excel_csv(
  complete_case_vs_mi_meta,
  "高血压-表7_完整案例与多重插补_Meta结果并列.csv"
)

# =====================================================================
# 32. 控制台输出
# =====================================================================
cat("\n====================================================\n")
cat("主分析及全部敏感性分析已完成。\n")
cat("====================================================\n")

cat("\n主分析完整案例样本量：", nrow(cox_data_final), "\n")
cat("\n敏感性分析5（统一痴呆判定算法）完整案例样本量：", nrow(sensitivity5_cox_data), "\n")
cat("\n敏感性分析6插补前样本量：", nrow(mi_source_data), "\n")

cat("\n----------------------------------------------------\n")
cat("主分析随机效应 Meta 分析结果\n")
cat("----------------------------------------------------\n")
print(main_meta_result, digits = 4)

cat("\n----------------------------------------------------\n")
cat("敏感性分析5（25项认知量表统一痴呆判定算法）Meta 分析结果\n")
cat("----------------------------------------------------\n")
print(sensitivity5_meta_result, digits = 4)

cat("\n----------------------------------------------------\n")
cat("全部敏感性分析 Meta 分析结果\n")
cat("----------------------------------------------------\n")
print(all_meta_results, digits = 4)

cat("\n====================================================\n")
cat("代码逻辑结构\n")
cat("====================================================\n")
cat(
  "1. 读取并检查 onlyhyper_data_new.dta；\n",
  "2. 根据国家波次信息动态选择基线波次；\n",
  "3. 排除基线糖尿病患者，提取动态基线暴露及协变量；\n",
  "4. 构建痴呆 Cox 结局、随访时间和死亡竞争风险结局；\n",
  "5. 进行完整案例 Cox 回归和随机效应 Meta 分析；\n",
  "6. 进行连续年龄、滞后、Fine-Gray 及逐国排除分析；\n",
  "7. 敏感性分析5：读取 onlyhyper_data.dta（25项认知量表统一痴呆判定算法），\n",
  "   重复与主分析完全一致的完整案例 Cox 回归和随机效应 Meta 分析；\n",
  "8. 为各国模型输出高血压组和非高血压组的人数及痴呆事件数；\n",
  "9. 敏感性分析6：重新读取原始数据，保留缺失个体，按国家进行 20 次 MICE 插补；\n",
  "10. 插补模型纳入暴露、结局、随访时间、Nelson-Aalen 风险值和全部协变量；\n",
  "11. 对多重插补结果报告 20 个完成数据集的平均分组人数及事件数，\n",
  "    并导出每个插补数据集的实际整数统计值；\n",
  "12. 导出缺失比例、缺失模式、MAR 支持性描述、插补方法、预测矩阵、\n",
  "    插补前后分布比较、收敛诊断、完整案例与插补结果并列表。\n",
  sep = ""
)
