# =====================================================================
# 中国CHARLS共病人群基础信息及痴呆发病率分析
#
# 分析定义：
# 1. 仅纳入 data_source == 1（CHARLS，中国）；
# 2. 动态基线 rXboth =0：无共病组；rXboth =1：共病组（高血压合并糖尿病）；
# 3. rXboth缺失/非0/1直接排除；
# 4. 动态基线痴呆为1者排除；
# 5. 其他动态基线筛选逻辑与Cox主分析代码保持一致；
# 6. 痴呆事件校正逻辑与Cox主分析代码保持一致。
#
# 统计方法：
# 1. 分类变量：n（%），组间比较使用Pearson卡方检验；
# 2. 年龄：中位数（IQR）；
# 3. 年龄组间比较：Welch t检验；
# 4. 发病率：痴呆事件数 / 总随访人年 × 100；
# 5. 发病率95% CI：Poisson精确置信区间。
#
# 本代码不加入BMI。
# =====================================================================
# =====================================================================
# 0. 环境设置与加载包
# =====================================================================
setwd("E:/csl/CSL/database")
library(dplyr)
library(tidyr)
library(haven)
library(readr)
select <- dplyr::select

# =====================================================================
# 1. 读取数据（仅保留 CHARLS）
# =====================================================================
total_data <- read_dta("both_data_new.dta") %>%
  filter(data_source == 1) %>%          # 仅保留 CHARLS（中国）
  mutate(record_id = row_number())

# =====================================================================
# 2. 基础变量检查
# =====================================================================
required_basic_vars <- c(
  "ID",
  "data_source",
  "yearsold",
  "age",
  "raeduc_c",
  "ragender"
)
missing_basic_vars <- setdiff(
  required_basic_vars,
  names(total_data)
)
if (length(missing_basic_vars) > 0) {
  stop(
    "数据中缺少以下必要变量：",
    paste(missing_basic_vars, collapse = ", ")
  )
}

# =====================================================================
# 3. 安全读取变量值（与Cox原版完全一致）
# =====================================================================
safe_get_value <- function(data, row_idx, var_name) {
  
  if (!var_name %in% names(data)) {
    return(NA_real_)
  }
  
  value <- data[[var_name]][row_idx]
  
  if (length(value) == 0 || is.null(value) || is.na(value)) {
    return(NA_real_)
  }
  
  suppressWarnings(as.numeric(value))
}

# =====================================================================
# 4. 定义各队列波次及调查年份
# =====================================================================
get_wave_info <- function(data_source) {
  
  data_source <- suppressWarnings(as.integer(data_source))
  
  switch(
    as.character(data_source),
    "1" = list(
      country = "CHARLS",
      max_wave = 5L,
      wave_years = c(2011, 2013, 2015, 2018, 2020)
    ),
    "2" = list(
      country = "HRS",
      max_wave = 6L,
      wave_years = c(2012, 2014, 2016, 2018, 2020, 2022)
    ),
    "3" = list(
      country = "SHARE",
      max_wave = 5L,
      wave_years = c(2013, 2015, 2017, 2020, 2022)
    ),
    "4" = list(
      country = "ELSA",
      max_wave = 5L,
      wave_years = c(2015, 2017, 2020, 2022, 2024)
    ),
    NULL
  )
}

# =====================================================================
# 5. 检查指定波次变量
# =====================================================================
check_wave_columns <- function(data, wave) {
  
  required_wave_vars <- c(
    paste0("r", wave, "both"),
    paste0("r", wave, "phyactivities"),
    paste0("r", wave, "netuse"),
    paste0("r", wave, "dementia"),
    paste0("r", wave, "mstat"),
    paste0("r", wave, "scocwk"),
    paste0("r", wave, "smoking"),
    paste0("r", wave, "Non_com_dis"),
    paste0("r", wave, "drink")
  )
  
  all(required_wave_vars %in% names(data))
}

# =====================================================================
# 6. 提取指定波次的基线变量
# =====================================================================
get_baseline_variables <- function(data, i, wave) {
  
  list(
    both = safe_get_value(
      data, i, paste0("r", wave, "both")
    ),
    phyactivities = safe_get_value(
      data, i, paste0("r", wave, "phyactivities")
    ),
    netuse = safe_get_value(
      data, i, paste0("r", wave, "netuse")
    ),
    dementia = safe_get_value(
      data, i, paste0("r", wave, "dementia")
    ),
    mstat = safe_get_value(
      data, i, paste0("r", wave, "mstat")
    ),
    scocwk = safe_get_value(
      data, i, paste0("r", wave, "scocwk")
    ),
    smoking = safe_get_value(
      data, i, paste0("r", wave, "smoking")
    ),
    Non_com_dis = safe_get_value(
      data, i, paste0("r", wave, "Non_com_dis")
    ),
    drink = safe_get_value(
      data, i, paste0("r", wave, "drink")
    )
  )
}

# =====================================================================
# 7. 判断基线后是否存在有效痴呆随访
# =====================================================================
has_followup_dementia_data <- function(
    data,
    i,
    enrollment_wave,
    max_wave
) {
  
  if (
    is.na(enrollment_wave) ||
    enrollment_wave >= max_wave
  ) {
    return(FALSE)
  }
  
  future_waves <- seq.int(
    enrollment_wave + 1L,
    max_wave
  )
  
  future_dementia <- vapply(
    future_waves,
    function(wave) {
      safe_get_value(
        data,
        i,
        paste0("r", wave, "dementia")
      )
    },
    numeric(1)
  )
  
  any(!is.na(future_dementia))
}

# =====================================================================
# 8. 动态基线筛选（对齐Cox主分析逻辑）
# =====================================================================
filter_sensitivity_analysis_data <- function(data) {
  
  data <- data %>%
    mutate(
      enrollment_wave = NA_integer_,
      screening_status = NA_character_,
      country = case_when(
        data_source == 1 ~ "CHARLS",
        data_source == 2 ~ "HRS",
        data_source == 3 ~ "SHARE",
        data_source == 4 ~ "ELSA",
        TRUE ~ "Unknown"
      )
    )
  
  for (i in seq_len(nrow(data))) {
    
    source_i <- safe_get_value(
      data,
      i,
      "data_source"
    )
    
    wave_info <- get_wave_info(source_i)
    
    if (is.null(wave_info)) {
      data$screening_status[i] <-
        "排除：未知数据来源"
      next
    }
    
    if (
      is.na(data$age[i]) ||
      data$age[i] < 50
    ) {
      data$screening_status[i] <-
        "排除：年龄<50岁或年龄缺失"
      next
    }
    
    max_wave_i <- wave_info$max_wave
    
    has_any_core_baseline <- FALSE
    has_non_dementia_baseline <- FALSE
    has_complete_covariate_baseline <- FALSE
    has_followup_data <- FALSE
    enrollment_found <- FALSE
    
    # 最后一波没有后续随访，不能作为动态基线
    for (wave in seq_len(max_wave_i - 1L)) {
      
      if (!check_wave_columns(data, wave)) {
        next
      }
      
      baseline_var <- get_baseline_variables(
        data,
        i,
        wave
      )
      
      # 核心暴露：both、phyactivities、netuse必须非缺失
      core_exposure_vars <- c(
        baseline_var$both,
        baseline_var$phyactivities,
        baseline_var$netuse
      )
      if (any(is.na(core_exposure_vars))) {
        next
      }
      # both必须为0或1
      if (!baseline_var$both %in% c(0,1)) {
        next
      }
      has_any_core_baseline <- TRUE
      
      # 基线必须无痴呆
      if (
        is.na(baseline_var$dementia) ||
        baseline_var$dementia != 0
      ) {
        next
      }
      has_non_dementia_baseline <- TRUE
      
      all_baseline_vars <- c(
        baseline_var$both,
        baseline_var$phyactivities,
        baseline_var$netuse,
        baseline_var$dementia,
        baseline_var$mstat,
        baseline_var$scocwk,
        baseline_var$smoking,
        baseline_var$Non_com_dis,
        baseline_var$drink,
        data$yearsold[i],
        data$raeduc_c[i],
        data$ragender[i]
      )
      
      if (any(is.na(all_baseline_vars))) {
        next
      }
      has_complete_covariate_baseline <- TRUE
      
      if (
        !has_followup_dementia_data(
          data,
          i,
          wave,
          max_wave_i
        )
      ) {
        next
      }
      has_followup_data <- TRUE
      
      # 采用最早满足所有条件的波次作为动态基线
      data$enrollment_wave[i] <- wave
      data$screening_status[i] <-
        "纳入最终分析"
      enrollment_found <- TRUE
      break
    }
    
    if (!enrollment_found) {
      if (!has_any_core_baseline) {
        data$screening_status[i] <-
          "排除：基线共病/体力活动/互联网使用信息缺失"
      } else if (!has_non_dementia_baseline) {
        data$screening_status[i] <-
          "排除：基线痴呆"
      } else if (!has_complete_covariate_baseline) {
        data$screening_status[i] <-
          "排除：基线协变量数据缺失"
      } else if (!has_followup_data) {
        data$screening_status[i] <-
          "排除：基线后痴呆随访数据缺失"
      } else {
        data$screening_status[i] <-
          "排除：其他原因"
      }
    }
  }
  data
}

# =====================================================================
# 9. 执行动态基线筛选
# =====================================================================
screened_data <- filter_sensitivity_analysis_data(
  total_data
)
data_in <- screened_data %>%
  filter(
    screening_status == "纳入最终分析"
  )

# =====================================================================
# 10. 提取动态基线变量及初步痴呆事件
# =====================================================================
extract_baseline_covariates <- function(data) {
  
  new_vars <- c(
    "baseline_both",
    "baseline_dementia_status",
    "baseline_phyactivities",
    "baseline_netuse",
    "baseline_mstat",
    "baseline_scocwk",
    "baseline_smoking",
    "baseline_drink",
    "baseline_Non_com_dis",
    "baseline_year",
    "last_followup_year",
    "time_to_event",
    "event_status"
  )
  
  data[new_vars] <- NA_real_
  
  for (i in seq_len(nrow(data))) {
    
    source_i <- safe_get_value(
      data,
      i,
      "data_source"
    )
    
    wave_i <- safe_get_value(
      data,
      i,
      "enrollment_wave"
    )
    
    wave_info <- get_wave_info(source_i)
    
    if (
      is.null(wave_info) ||
      is.na(wave_i)
    ) {
      next
    }
    
    wave_i <- as.integer(wave_i)
    max_wave_i <- wave_info$max_wave
    wave_years_i <- wave_info$wave_years
    baseline_year_i <- wave_years_i[wave_i]
    
    data$baseline_both[i] <- safe_get_value(
      data,
      i,
      paste0("r", wave_i, "both")
    )
    data$baseline_dementia_status[i] <- safe_get_value(
      data,
      i,
      paste0("r", wave_i, "dementia")
    )
    data$baseline_phyactivities[i] <- safe_get_value(
      data,
      i,
      paste0("r", wave_i, "phyactivities")
    )
    data$baseline_netuse[i] <- safe_get_value(
      data,
      i,
      paste0("r", wave_i, "netuse")
    )
    data$baseline_mstat[i] <- safe_get_value(
      data,
      i,
      paste0("r", wave_i, "mstat")
    )
    data$baseline_scocwk[i] <- safe_get_value(
      data,
      i,
      paste0("r", wave_i, "scocwk")
    )
    data$baseline_smoking[i] <- safe_get_value(
      data,
      i,
      paste0("r", wave_i, "smoking")
    )
    data$baseline_drink[i] <- safe_get_value(
      data,
      i,
      paste0("r", wave_i, "drink")
    )
    data$baseline_Non_com_dis[i] <- safe_get_value(
      data,
      i,
      paste0("r", wave_i, "Non_com_dis")
    )
    data$baseline_year[i] <- baseline_year_i
    
    onset_year_i <- NA_real_
    last_followup_year_i <- baseline_year_i
    event_i <- 0L
    
    future_waves <- seq.int(
      wave_i + 1L,
      max_wave_i
    )
    
    for (future_wave in future_waves) {
      
      dementia_i <- safe_get_value(
        data,
        i,
        paste0("r", future_wave, "dementia")
      )
      
      if (!is.na(dementia_i)) {
        current_year_i <- wave_years_i[future_wave]
        last_followup_year_i <- current_year_i
        if (
          dementia_i == 1 &&
          is.na(onset_year_i)
        ) {
          onset_year_i <- current_year_i
          event_i <- 1L
          break
        }
      }
    }
    
    data$last_followup_year[i] <- last_followup_year_i
    data$event_status[i] <- event_i
    
    if (event_i == 1L) {
      data$time_to_event[i] <-
        onset_year_i - baseline_year_i
    } else {
      data$time_to_event[i] <-
        last_followup_year_i - baseline_year_i
    }
  }
  
  data %>%
    select(
      record_id,
      ID,
      country,
      data_source,
      enrollment_wave,
      baseline_year,
      last_followup_year,
      yearsold,
      age,
      raeduc_c,
      ragender,
      baseline_both,
      baseline_dementia_status,
      baseline_phyactivities,
      baseline_netuse,
      baseline_mstat,
      baseline_scocwk,
      baseline_smoking,
      baseline_drink,
      baseline_Non_com_dis,
      time_to_event,
      event_status
    ) %>%
    filter(
      baseline_both %in% c(0, 1),
      baseline_dementia_status == 0,
      !is.na(yearsold),
      !is.na(age),
      !is.na(raeduc_c),
      !is.na(ragender),
      !is.na(baseline_phyactivities),
      !is.na(baseline_netuse),
      !is.na(baseline_mstat),
      !is.na(baseline_scocwk),
      !is.na(baseline_smoking),
      !is.na(baseline_drink),
      !is.na(baseline_Non_com_dis),
      !is.na(time_to_event),
      time_to_event > 0
    ) %>%
    mutate(
      country = factor(
        country,
        levels = c("CHARLS","HRS","SHARE","ELSA")
      ),
      baseline_both = factor(
        baseline_both,
        levels = c(0, 1),
        labels = c("无共病组", "共病组")
      ),
      yearsold = factor(
        yearsold,
        levels = c(1, 2, 3, 4),
        labels = c(
          "60岁以下",
          "60-69岁",
          "70-79岁",
          "80岁及以上"
        )
      ),
      ragender = factor(
        ragender,
        levels = c(1, 2),
        labels = c("男", "女")
      ),
      raeduc_c = factor(
        raeduc_c,
        levels = c(1, 2, 3),
        labels = c(
          "初中及以下",
          "高中",
          "大学及以上"
        )
      ),
      baseline_phyactivities = factor(
        baseline_phyactivities,
        levels = c(0, 1),
        labels = c("不活跃", "活跃")
      ),
      baseline_netuse = factor(
        baseline_netuse,
        levels = c(0, 1),
        labels = c("不使用", "使用")
      ),
      baseline_mstat = factor(
        baseline_mstat,
        levels = c(1, 2),
        labels = c("已婚/同居", "单身")
      ),
      baseline_scocwk = factor(
        baseline_scocwk,
        levels = c(0, 1),
        labels = c("不活跃", "活跃")
      ),
      baseline_smoking = factor(
        baseline_smoking,
        levels = c(0, 1, 2),
        labels = c(
          "戒烟",
          "吸烟",
          "从未吸烟"
        )
      ),
      baseline_drink = factor(
        baseline_drink,
        levels = c(0, 1),
        labels = c(
          "从未饮酒",
          "饮过酒"
        )
      ),
      baseline_Non_com_dis = factor(
        baseline_Non_com_dis,
        levels = c(0, 1),
        labels = c("无", "有")
      )
    )
}

# =====================================================================
# 11. 痴呆事件校正（与Cox原版完全一致）
# =====================================================================
correct_event_status <- function(data, origin_data) {
  
  dementia_vars <- paste0(
    "r",
    1:6,
    "dementia"
  )
  existing_dementia_vars <- intersect(
    dementia_vars,
    names(origin_data)
  )
  origin_data_sub <- origin_data %>%
    select(record_id, any_of(existing_dementia_vars))
  
  if (anyDuplicated(origin_data_sub$record_id) > 0) {
    stop("原始数据中的record_id不唯一。")
  }
  if (anyDuplicated(data$record_id) > 0) {
    stop("分析数据中的record_id不唯一。")
  }
  
  data_correct <- data %>%
    left_join(origin_data_sub, by = "record_id")
  
  for (i in seq_len(nrow(data_correct))) {
    
    source_i <- safe_get_value(
      data_correct,
      i,
      "data_source"
    )
    wave_i <- safe_get_value(
      data_correct,
      i,
      "enrollment_wave"
    )
    wave_info <- get_wave_info(source_i)
    
    if (is.null(wave_info) || is.na(wave_i)) {
      data_correct$event_status[i] <- 0L
      data_correct$time_to_event[i] <- NA_real_
      next
    }
    
    wave_i <- as.integer(wave_i)
    max_wave_i <- wave_info$max_wave
    wave_years_i <- wave_info$wave_years
    baseline_year_i <- wave_years_i[wave_i]
    
    if (wave_i >= max_wave_i) {
      data_correct$event_status[i] <- 0L
      data_correct$time_to_event[i] <- NA_real_
      next
    }
    
    future_waves <- seq.int(wave_i + 1L, max_wave_i)
    future_dementia <- vapply(
      future_waves,
      function(wave) {
        safe_get_value(
          data_correct,
          i,
          paste0("r", wave, "dementia")
        )
      },
      numeric(1)
    )
    
    valid_index <- which(!is.na(future_dementia))
    if (length(valid_index) == 0) {
      data_correct$event_status[i] <- 0L
      data_correct$time_to_event[i] <- NA_real_
      next
    }
    
    valid_dementia <- future_dementia[valid_index]
    valid_waves <- future_waves[valid_index]
    last_followup_wave <- tail(valid_waves,1)
    last_followup_year_i <- wave_years_i[last_followup_wave]
    data_correct$last_followup_year[i] <- last_followup_year_i
    
    event_i <- 0L
    onset_year_i <- NA_real_
    first_positive_position <- which(valid_dementia == 1)[1]
    
    if (!is.na(first_positive_position)) {
      first_positive_wave <- valid_waves[first_positive_position]
      first_positive_year <- wave_years_i[first_positive_wave]
      if (first_positive_position < length(valid_dementia)) {
        next_valid_dementia <- valid_dementia[first_positive_position + 1L]
        if (next_valid_dementia != 0) {
          event_i <- 1L
          onset_year_i <- first_positive_year
        }
      } else {
        event_i <- 1L
        onset_year_i <- first_positive_year
      }
    }
    
    data_correct$event_status[i] <- event_i
    if (event_i == 1L) {
      data_correct$time_to_event[i] <- onset_year_i - baseline_year_i
    } else {
      data_correct$time_to_event[i] <- last_followup_year_i - baseline_year_i
    }
  }
  
  data_correct %>%
    select(-any_of(existing_dementia_vars)) %>%
    filter(!is.na(time_to_event), time_to_event > 0)
}

# =====================================================================
# 12. 构建最终分析数据
# =====================================================================
analysis_data <- extract_baseline_covariates(
  data_in
) %>%
  correct_event_status(
    origin_data = data_in
  ) %>%
  mutate(
    event_status = as.integer(event_status)
  )

# =====================================================================
# 13. 样本筛选流程（CHARLS 内部）
# =====================================================================
n_all_participants <- nrow(total_data)
n_after_screening <- nrow(data_in)
n_final_analysis <- nrow(analysis_data)
n_removed_after_event_correction <-
  n_after_screening - n_final_analysis

flow_order <- c(
  "纳入最终分析",
  "排除：年龄<50岁或年龄缺失",
  "排除：基线共病/体力活动/互联网使用信息缺失",
  "排除：基线痴呆",
  "排除：基线协变量数据缺失",
  "排除：基线后痴呆随访数据缺失",
  "排除：其他原因",
  "排除：未知数据来源"
)

flow_table <- screened_data %>%
  count(
    screening_status,
    name = "N"
  ) %>%
  mutate(
    percent_of_total = round(
      N / n_all_participants * 100,
      2
    ),
    screening_status = factor(
      screening_status,
      levels = flow_order
    )
  ) %>%
  arrange(screening_status)

flow_by_country <- screened_data %>%
  mutate(
    screening_status = factor(
      screening_status,
      levels = flow_order
    )
  ) %>%
  count(
    country,
    screening_status,
    name = "N"
  ) %>%
  pivot_wider(
    names_from = screening_status,
    values_from = N,
    values_fill = 0
  )

# =====================================================================
# 14. 最终样本概况
# =====================================================================
analysis_sample_by_country <- analysis_data %>%
  group_by(country) %>%
  summarise(
    N = n(),
    dementia_events = sum(
      event_status == 1,
      na.rm = TRUE
    ),
    non_events = sum(
      event_status == 0,
      na.rm = TRUE
    ),
    total_person_years = sum(
      time_to_event,
      na.rm = TRUE
    ),
    mean_followup_years = mean(
      time_to_event,
      na.rm = TRUE
    ),
    median_followup_years = median(
      time_to_event,
      na.rm = TRUE
    ),
    .groups = "drop"
  ) %>%
  mutate(
    country = as.character(country)
  )

analysis_sample_overall <- analysis_data %>%
  summarise(
    country = "CHARLS总体",
    N = n(),
    dementia_events = sum(
      event_status == 1,
      na.rm = TRUE
    ),
    non_events = sum(
      event_status == 0,
      na.rm = TRUE
    ),
    total_person_years = sum(
      time_to_event,
      na.rm = TRUE
    ),
    mean_followup_years = mean(
      time_to_event,
      na.rm = TRUE
    ),
    median_followup_years = median(
      time_to_event,
      na.rm = TRUE
    )
  )

analysis_sample_with_overall <- bind_rows(
  analysis_sample_by_country,
  analysis_sample_overall
)

# =====================================================================
# 15. 基线特征表函数
# =====================================================================
control_group <- "无共病组"
comorbidity_group <- "共病组"

format_n_percent <- function(n, total) {
  if (is.na(total) || total == 0) {
    return(NA_character_)
  }
  sprintf(
    "%d (%.1f%%)",
    n,
    n / total * 100
  )
}

format_p_value <- function(p_value) {
  if (is.na(p_value)) {
    return(NA_character_)
  }
  if (p_value < 0.0001) {
    return("<0.0001")
  }
  sprintf("%.4f", p_value)
}

format_median_iqr <- function(x) {
  x <- x[!is.na(x)]
  if (length(x) == 0) {
    return(NA_character_)
  }
  q <- quantile(
    x,
    probs = c(0.25, 0.50, 0.75),
    names = FALSE
  )
  sprintf(
    "%.1f (%.1f‑%.1f)",
    q[2],
    q[1],
    q[3]
  )
}

get_chisq_result <- function(data, variable) {
  test_data <- data %>%
    filter(
      !is.na(.data[[variable]]),
      !is.na(baseline_both)
    )
  cross_table <- table(
    test_data[[variable]],
    test_data$baseline_both
  )
  if (nrow(cross_table) < 2 || ncol(cross_table) < 2) {
    return(
      list(
        statistic = NA_real_,
        p_value = NA_real_
      )
    )
  }
  test_result <- suppressWarnings(
    chisq.test(cross_table, correct = FALSE)
  )
  list(
    statistic = unname(test_result$statistic),
    p_value = test_result$p.value
  )
}

make_categorical_rows <- function(
    data,
    variable,
    variable_label
) {
  variable_levels <- levels(data[[variable]])
  test_result <- get_chisq_result(data, variable)
  
  overall_denominator <- sum(!is.na(data[[variable]]))
  control_denominator <- sum(
    data$baseline_both == control_group & !is.na(data[[variable]])
  )
  comorbidity_denominator <- sum(
    data$baseline_both == comorbidity_group & !is.na(data[[variable]])
  )
  
  category_rows <- lapply(
    seq_along(variable_levels),
    function(j) {
      level <- variable_levels[j]
      overall_count <- sum(data[[variable]] == level, na.rm = TRUE)
      control_count <- sum(
        data[[variable]] == level & data$baseline_both == control_group,
        na.rm = TRUE
      )
      comorbidity_count <- sum(
        data[[variable]] == level & data$baseline_both == comorbidity_group,
        na.rm = TRUE
      )
      
      tibble(
        variable = ifelse(j == 1, variable_label, ""),
        category = as.character(level),
        overall = format_n_percent(overall_count, overall_denominator),
        no_comorbidity_group = format_n_percent(control_count, control_denominator),
        comorbidity_group = format_n_percent(comorbidity_count, comorbidity_denominator),
        statistic = ifelse(
          j == 1 && !is.na(test_result$statistic),
          sprintf("%.2f", test_result$statistic),
          ""
        ),
        p_value = ifelse(j == 1, format_p_value(test_result$p_value), "")
      )
    }
  )
  bind_rows(category_rows)
}

# =====================================================================
# 16. 构建基线特征表
# =====================================================================
age_test <- t.test(
  age ~ baseline_both,
  data = analysis_data,
  var.equal = FALSE
)

baseline_table <- bind_rows(
  
  tibble(
    variable = "总人数",
    category = "",
    overall = sprintf("%d (100.0%%)", nrow(analysis_data)),
    no_comorbidity_group = format_n_percent(
      sum(analysis_data$baseline_both == control_group),
      nrow(analysis_data)
    ),
    comorbidity_group = format_n_percent(
      sum(analysis_data$baseline_both == comorbidity_group),
      nrow(analysis_data)
    ),
    statistic = "",
    p_value = ""
  ),
  
  make_categorical_rows(analysis_data, "ragender", "性别"),
  make_categorical_rows(analysis_data, "baseline_phyactivities", "身体活动"),
  make_categorical_rows(analysis_data, "baseline_netuse", "互联网使用"),
  make_categorical_rows(analysis_data, "baseline_mstat", "婚姻状况"),
  make_categorical_rows(analysis_data, "raeduc_c", "教育程度"),
  make_categorical_rows(analysis_data, "baseline_scocwk", "社会活动"),
  make_categorical_rows(analysis_data, "baseline_smoking", "吸烟状况"),
  make_categorical_rows(analysis_data, "baseline_drink", "饮酒状况"),
  make_categorical_rows(analysis_data, "baseline_Non_com_dis", "其他非传染性疾病"),
  make_categorical_rows(analysis_data, "yearsold", "年龄分组"),
  
  tibble(
    variable = "基线年龄，中位数（IQR），岁",
    category = "",
    overall = format_median_iqr(analysis_data$age),
    no_comorbidity_group = format_median_iqr(
      analysis_data$age[analysis_data$baseline_both == control_group]
    ),
    comorbidity_group = format_median_iqr(
      analysis_data$age[analysis_data$baseline_both == comorbidity_group]
    ),
    statistic = sprintf("%.2f", unname(age_test$statistic)),
    p_value = format_p_value(age_test$p.value)
  )
)

# =====================================================================
# 17. 论文展示版表格
# =====================================================================
baseline_table_publication <- baseline_table %>%
  transmute(
    `Variable` = variable,
    `Category` = category,
    `Overall` = overall,
    `No‑comorbidity group` = no_comorbidity_group,
    `Comorbidity group` = comorbidity_group,
    `Statistics` = statistic,
    `p value` = p_value
  )

# =====================================================================
# 18. 发病率计算
# =====================================================================
calculate_incidence <- function(data) {
  participant_n <- nrow(data)
  event_n <- sum(data$event_status == 1, na.rm = TRUE)
  person_years <- sum(data$time_to_event, na.rm = TRUE)
  median_followup <- median(data$time_to_event, na.rm = TRUE)
  followup_iqr <- quantile(
    data$time_to_event,
    probs = c(0.25, 0.75),
    na.rm = TRUE,
    names = FALSE
  )
  
  if (is.na(person_years) || person_years <= 0) {
    return(
      tibble(
        N = participant_n,
        dementia_events = event_n,
        total_person_years = NA_real_,
        median_followup_years = NA_real_,
        followup_iqr_lower = NA_real_,
        followup_iqr_upper = NA_real_,
        incidence_rate_per_100py = NA_real_,
        incidence_ci_lower = NA_real_,
        incidence_ci_upper = NA_real_,
        incidence_rate_95ci = NA_character_
      )
    )
  }
  
  poisson_ci <- poisson.test(x = event_n, T = person_years)$conf.int * 100
  incidence_rate <- event_n / person_years * 100
  
  tibble(
    N = participant_n,
    dementia_events = event_n,
    total_person_years = person_years,
    median_followup_years = median_followup,
    followup_iqr_lower = followup_iqr[1],
    followup_iqr_upper = followup_iqr[2],
    incidence_rate_per_100py = incidence_rate,
    incidence_ci_lower = poisson_ci[1],
    incidence_ci_upper = poisson_ci[2],
    incidence_rate_95ci = sprintf(
      "%.3f (95%% CI: %.3f‑%.3f)",
      incidence_rate,
      poisson_ci[1],
      poisson_ci[2]
    )
  )
}

# =====================================================================
# 19. CHARLS 总体及两组发病率
# =====================================================================
incidence_by_group <- bind_rows(
  calculate_incidence(analysis_data) %>% mutate(group = "CHARLS总体"),
  calculate_incidence(analysis_data %>% filter(baseline_both == control_group)) %>% mutate(group = control_group),
  calculate_incidence(analysis_data %>% filter(baseline_both == comorbidity_group)) %>% mutate(group = comorbidity_group)
) %>%
  select(
    group,
    N,
    dementia_events,
    total_person_years,
    median_followup_years,
    followup_iqr_lower,
    followup_iqr_upper,
    incidence_rate_per_100py,
    incidence_ci_lower,
    incidence_ci_upper,
    incidence_rate_95ci
  )

# =====================================================================
# 20. 各国总体发病率（仅CHARLS）
# =====================================================================
incidence_by_country <- analysis_data %>%
  group_by(country) %>%
  group_modify(~ calculate_incidence(.x)) %>%
  ungroup() %>%
  transmute(
    country = as.character(country),
    group = "总体",
    N,
    dementia_events,
    total_person_years,
    median_followup_years,
    followup_iqr_lower,
    followup_iqr_upper,
    incidence_rate_per_100py,
    incidence_ci_lower,
    incidence_ci_upper,
    incidence_rate_95ci
  )

# =====================================================================
# 21. 各国及共病分组发病率（仅CHARLS）
# =====================================================================
incidence_by_country_and_group <- analysis_data %>%
  group_by(country, baseline_both) %>%
  group_modify(~ calculate_incidence(.x)) %>%
  ungroup() %>%
  transmute(
    country = as.character(country),
    group = as.character(baseline_both),
    N,
    dementia_events,
    total_person_years,
    median_followup_years,
    followup_iqr_lower,
    followup_iqr_upper,
    incidence_rate_per_100py,
    incidence_ci_lower,
    incidence_ci_upper,
    incidence_rate_95ci
  )

incidence_all_results <- bind_rows(
  incidence_by_group %>% mutate(country = "CHARLS总体"),
  incidence_by_country,
  incidence_by_country_and_group
) %>%
  mutate(
    country = factor(country, levels = c("CHARLS总体","CHARLS"))
  ) %>%
  arrange(country, group)

# =====================================================================
# 22. 控制台输出
# =====================================================================
cat("\n====================================================\n")
cat("CHARLS共病人群样本筛选流程\n")
cat("====================================================\n")
cat("CHARLS原始样本量：", n_all_participants, "\n")
cat("动态基线筛选后样本量：", n_after_screening, "\n")
cat("事件校正后最终分析样本量：", n_final_analysis, "\n")
cat("事件校正后移除人数：", n_removed_after_event_correction, "\n\n")
print(flow_table)

cat("\n====================================================\n")
cat("CHARLS样本筛选流程（按国家列）\n")
cat("====================================================\n")
print(flow_by_country)

cat("\n====================================================\n")
cat("CHARLS最终分析样本概况\n")
cat("====================================================\n")
print(analysis_sample_with_overall)

cat("\n====================================================\n")
cat("CHARLS基线特征表\n")
cat("====================================================\n")
print(baseline_table_publication, n = Inf)

cat("\n====================================================\n")
cat("CHARLS总体及分组痴呆发病率\n")
cat("====================================================\n")
print(incidence_by_group)

cat("\n====================================================\n")
cat("CHARLS各国及分组痴呆发病率\n")
cat("====================================================\n")
print(incidence_all_results)

# =====================================================================
# 23. 导出CSV文件
# =====================================================================
write_excel_csv(
  flow_table,
  "CHARLS共病分析_表1_总体样本筛选流程.csv"
)
write_excel_csv(
  flow_by_country,
  "CHARLS共病分析_表2_各国样本筛选流程.csv"
)
write_excel_csv(
  analysis_sample_with_overall,
  "CHARLS共病分析_表3_最终分析样本概况.csv"
)
write_excel_csv(
  baseline_table,
  "CHARLS共病分析_表4_基线特征表_长格式.csv"
)
write_excel_csv(
  baseline_table_publication,
  "CHARLS共病分析_表4_基线特征表_论文展示格式.csv"
)
write_excel_csv(
  incidence_by_group,
  "CHARLS共病分析_表5_总体及分组痴呆发病率.csv"
)
write_excel_csv(
  incidence_all_results,
  "CHARLS共病分析_表6_各国及分组痴呆发病率.csv"
)
write_excel_csv(
  analysis_data,
  "CHARLS共病分析_最终基础信息及发病率分析数据.csv"
)
