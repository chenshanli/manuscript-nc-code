# =====================================================================
# 中介分析（终极优化版）：糖尿病（排除基线高血压）与痴呆风险
#
# 中介变量：身体活动（phyactivities）、互联网使用（netuse）
#
# 核心修订：
#   1. 间接效应（Indirect Effect / iHR）作为主要推断指标
#   2. 修复中介比例（Mediation Proportion）因分母抽样波动导致的 CI 异常
#   3. Meta 分析同时输出【全球 4 国全合并】与【欧美 3 国敏感性合并】
#   4. 严格采用 Rubin's Rules 处理多重插补 (m=50)
#   5. 包含完整案例敏感性分析、留一法 (LOO) 及 Schoenfeld PH 检验
#   6. 纵向中介路径效应汇总表（表3）：a-paths / b-paths / 效应分解，
#      含 OR/HR (95% CI)、p 值、I² 及异质性 p 值
#
# 分析定义（与糖尿病 Cox 主分析一致）：
#   1. 动态基线时 rXonlydiabe == 1 且 rXhypertension == 0：
#      归为"糖尿病且无高血压"组；
#   2. 动态基线时 rXonlydiabe == 0 且 rXhypertension == 0：
#      归为"无糖尿病且无高血压"对照组；
#   3. 动态基线高血压为 1 者排除；
#   4. 动态基线高血压状态缺失者排除；
#   5. 其他动态基线筛选、痴呆事件判定、Cox 调整变量、
#      Schoenfeld 残差 PH 假设检验和随机效应 Meta 分析
#      均与高血压中介主分析保持一致。
# =====================================================================

# ----- 0. 环境设置 -----

setwd("C:/CSL")

library(dplyr)
library(tidyr)
library(haven)
library(survival)
library(broom)
library(metafor)
library(mice)
library(purrr)
library(readr)
select <- dplyr::select

set.seed(20241201)
BOOT_TIMES <- 500
N_IMP      <- 50

# ----- 1. 读取原始数据 -----

total_data <- read_dta("onlydiabe_data_new.dta") %>%
  mutate(record_id = row_number())

# ----- 2. 全局必要变量检查 -----

required_basic_vars <- c("ID", "data_source", "yearsold", "age", "raeduc_c", "ragender")
missing_basic_vars  <- setdiff(required_basic_vars, names(total_data))

if (length(missing_basic_vars) > 0) {
  stop("数据中缺少以下必要变量：", paste(missing_basic_vars, collapse = ", "))
}

# ----- 3. 工具函数 -----

safe_get_value <- function(data, row_idx, var_name) {
  if (!var_name %in% names(data)) return(NA_real_)
  value <- data[[var_name]][row_idx]
  if (length(value) == 0 || is.null(value) || is.na(value)) return(NA_real_)
  suppressWarnings(as.numeric(value))
}

get_wave_info <- function(data_source) {
  data_source <- suppressWarnings(as.integer(data_source))
  switch(
    as.character(data_source),
    "1" = list(country = "CHARLS", max_wave = 5L,
               wave_years = c(2011, 2013, 2015, 2018, 2020)),
    "2" = list(country = "HRS",    max_wave = 6L,
               wave_years = c(2012, 2014, 2016, 2018, 2020, 2022)),
    "3" = list(country = "SHARE",  max_wave = 5L,
               wave_years = c(2013, 2015, 2017, 2020, 2022)),
    "4" = list(country = "ELSA",   max_wave = 5L,
               wave_years = c(2015, 2017, 2020, 2022, 2024)),
    NULL
  )
}

check_wave_columns <- function(data, wave) {
  required_wave_vars <- c(
    paste0("r", wave, "onlydiabe"),
    paste0("r", wave, "hypertension"),
    paste0("r", wave, "phyactivities"),
    paste0("r", wave, "netuse"),
    paste0("r", wave, "dementia"),
    paste0("r", wave, "mstat"),
    paste0("r", wave, "scocwk"),
    paste0("r", wave, "smoking"),
    paste0("r", wave, "Non_com_dis"),
    paste0("r", wave, "drink")
  )
  all(required_wave_vars %in% names(data))
}

get_baseline_variables <- function(data, i, wave) {
  list(
    onlydiabe    = safe_get_value(data, i, paste0("r", wave, "onlydiabe")),
    hypertension = safe_get_value(data, i, paste0("r", wave, "hypertension")),
    phyactivities = safe_get_value(data, i, paste0("r", wave, "phyactivities")),
    netuse        = safe_get_value(data, i, paste0("r", wave, "netuse")),
    dementia      = safe_get_value(data, i, paste0("r", wave, "dementia")),
    mstat         = safe_get_value(data, i, paste0("r", wave, "mstat")),
    scocwk        = safe_get_value(data, i, paste0("r", wave, "scocwk")),
    smoking       = safe_get_value(data, i, paste0("r", wave, "smoking")),
    Non_com_dis   = safe_get_value(data, i, paste0("r", wave, "Non_com_dis")),
    drink         = safe_get_value(data, i, paste0("r", wave, "drink"))
  )
}

has_followup_dementia_data <- function(data, i, enrollment_wave, max_wave) {
  if (is.na(enrollment_wave) || enrollment_wave >= max_wave) return(FALSE)
  future_waves <- seq.int(enrollment_wave + 1L, max_wave)
  future_dementia <- vapply(
    future_waves,
    function(wave) safe_get_value(data, i, paste0("r", wave, "dementia")),
    numeric(1)
  )
  any(!is.na(future_dementia))
}

# ----- 4. 动态基线筛选 -----

filter_sensitivity_analysis_data <- function(data) {
  data <- data %>%
    mutate(
      enrollment_wave   = NA_integer_,
      screening_status  = NA_character_,
      mediator_missing  = NA,
      country = case_when(
        data_source == 1 ~ "CHARLS",
        data_source == 2 ~ "HRS",
        data_source == 3 ~ "SHARE",
        data_source == 4 ~ "ELSA",
        TRUE ~ "Unknown"
      )
    )
  
  for (i in seq_len(nrow(data))) {
    source_i  <- safe_get_value(data, i, "data_source")
    wave_info <- get_wave_info(source_i)
    
    if (is.null(wave_info)) {
      data$screening_status[i] <- "排除：未知数据来源"
      next
    }
    
    if (is.na(data$age[i]) || data$age[i] < 50) {
      data$screening_status[i] <- "排除：年龄<50岁或年龄缺失"
      next
    }
    
    max_wave_i <- wave_info$max_wave
    
    has_exposure_hypertension_data  <- FALSE
    has_no_hypertension_baseline    <- FALSE
    has_non_dementia_baseline       <- FALSE
    has_complete_covariate_baseline <- FALSE
    has_followup_data               <- FALSE
    enrollment_found                <- FALSE
    
    for (wave in seq_len(max_wave_i - 1L)) {
      if (!check_wave_columns(data, wave)) next
      
      baseline_var <- get_baseline_variables(data, i, wave)
      
      if (is.na(baseline_var$onlydiabe) || is.na(baseline_var$hypertension)) next
      if (!baseline_var$onlydiabe %in% c(0, 1)) next
      if (!baseline_var$hypertension  %in% c(0, 1)) next
      
      has_exposure_hypertension_data <- TRUE
      
      # 排除基线高血压患者
      if (baseline_var$hypertension == 1) next
      
      has_no_hypertension_baseline <- TRUE
      
      if (is.na(baseline_var$dementia) || baseline_var$dementia != 0) next
      
      has_non_dementia_baseline <- TRUE
      
      all_covars <- c(
        baseline_var$onlydiabe,
        baseline_var$hypertension,
        baseline_var$dementia,
        baseline_var$mstat,
        baseline_var$scocwk,
        baseline_var$smoking,
        baseline_var$Non_com_dis,
        baseline_var$drink,
        data$yearsold[i],
        data$raeduc_c[i],
        data$ragender[i]
      )
      
      if (any(is.na(all_covars))) next
      
      has_complete_covariate_baseline <- TRUE
      
      if (!has_followup_dementia_data(data, i, wave, max_wave_i)) next
      
      has_followup_data <- TRUE
      data$enrollment_wave[i]  <- wave
      data$screening_status[i] <- "纳入最终分析"
      data$mediator_missing[i] <- is.na(baseline_var$phyactivities) | is.na(baseline_var$netuse)
      enrollment_found <- TRUE
      break
    }
    
    if (!enrollment_found) {
      if (!has_exposure_hypertension_data) {
        data$screening_status[i] <- "排除：基线糖尿病或高血压状态缺失"
      } else if (!has_no_hypertension_baseline) {
        data$screening_status[i] <- "排除：基线患高血压"
      } else if (!has_non_dementia_baseline) {
        data$screening_status[i] <- "排除：基线痴呆或基线暴露信息缺失"
      } else if (!has_complete_covariate_baseline) {
        data$screening_status[i] <- "排除：基线协变量数据缺失"
      } else if (!has_followup_data) {
        data$screening_status[i] <- "排除：基线后痴呆随访数据缺失"
      } else {
        data$screening_status[i] <- "排除：其他原因"
      }
    }
  }
  
  data
}

# ----- 5. 执行筛选 -----

screened_data <- filter_sensitivity_analysis_data(total_data)
data_in       <- screened_data %>% filter(screening_status == "纳入最终分析")

# ----- 6. 提取动态基线变量 -----

extract_baseline_covariates <- function(data) {
  new_vars <- c(
    "baseline_onlydiabe", "baseline_hypertension", "baseline_dementia_status",
    "baseline_phyactivities", "baseline_netuse",
    "baseline_mstat", "baseline_scocwk", "baseline_smoking",
    "baseline_drink", "baseline_Non_com_dis",
    "baseline_year", "last_followup_year",
    "time_to_event", "event_status"
  )
  
  data[new_vars] <- NA_real_
  
  for (i in seq_len(nrow(data))) {
    source_i  <- safe_get_value(data, i, "data_source")
    wave_i    <- safe_get_value(data, i, "enrollment_wave")
    wave_info <- get_wave_info(source_i)
    
    if (is.null(wave_info) || is.na(wave_i)) next
    
    wave_i          <- as.integer(wave_i)
    max_wave_i      <- wave_info$max_wave
    wave_years_i    <- wave_info$wave_years
    baseline_year_i <- wave_years_i[wave_i]
    
    data$baseline_onlydiabe[i]       <- safe_get_value(data, i, paste0("r", wave_i, "onlydiabe"))
    data$baseline_hypertension[i]    <- safe_get_value(data, i, paste0("r", wave_i, "hypertension"))
    data$baseline_dementia_status[i] <- safe_get_value(data, i, paste0("r", wave_i, "dementia"))
    data$baseline_phyactivities[i]   <- safe_get_value(data, i, paste0("r", wave_i, "phyactivities"))
    data$baseline_netuse[i]          <- safe_get_value(data, i, paste0("r", wave_i, "netuse"))
    data$baseline_mstat[i]           <- safe_get_value(data, i, paste0("r", wave_i, "mstat"))
    data$baseline_scocwk[i]          <- safe_get_value(data, i, paste0("r", wave_i, "scocwk"))
    data$baseline_smoking[i]         <- safe_get_value(data, i, paste0("r", wave_i, "smoking"))
    data$baseline_drink[i]           <- safe_get_value(data, i, paste0("r", wave_i, "drink"))
    data$baseline_Non_com_dis[i]     <- safe_get_value(data, i, paste0("r", wave_i, "Non_com_dis"))
    
    data$baseline_year[i]            <- baseline_year_i
    
    onset_year_i        <- NA_real_
    last_followup_year_i <- baseline_year_i
    event_i             <- 0L
    
    future_waves <- seq.int(wave_i + 1L, max_wave_i)
    
    for (future_wave in future_waves) {
      dementia_i     <- safe_get_value(data, i, paste0("r", future_wave, "dementia"))
      current_year_i <- wave_years_i[future_wave]
      
      if (!is.na(dementia_i)) {
        last_followup_year_i <- current_year_i
        if (dementia_i == 1 && is.na(onset_year_i)) {
          onset_year_i <- current_year_i
          event_i      <- 1L
          break
        }
      }
    }
    
    data$last_followup_year[i] <- last_followup_year_i
    data$event_status[i]       <- event_i
    
    if (event_i == 1L) {
      data$time_to_event[i] <- onset_year_i - baseline_year_i
    } else {
      data$time_to_event[i] <- last_followup_year_i - baseline_year_i
    }
  }
  
  data %>%
    select(
      record_id, ID, country, data_source, enrollment_wave,
      baseline_year, last_followup_year, mediator_missing,
      yearsold, age, raeduc_c, ragender,
      baseline_onlydiabe, baseline_hypertension, baseline_dementia_status,
      baseline_phyactivities, baseline_netuse,
      baseline_mstat, baseline_scocwk, baseline_smoking,
      baseline_drink, baseline_Non_com_dis,
      time_to_event, event_status
    ) %>%
    filter(
      baseline_onlydiabe %in% c(0, 1),
      baseline_hypertension == 0,
      baseline_dementia_status == 0,
      !is.na(yearsold), !is.na(age),
      !is.na(raeduc_c), !is.na(ragender),
      !is.na(baseline_mstat), !is.na(baseline_scocwk),
      !is.na(baseline_smoking), !is.na(baseline_drink),
      !is.na(baseline_Non_com_dis),
      !is.na(time_to_event),
      time_to_event > 0
    )
}

# ----- 7. 校正不稳定痴呆事件 -----

correct_event_status <- function(data, origin_data) {
  dementia_vars <- paste0("r", 1:6, "dementia")
  existing_dementia_vars <- intersect(dementia_vars, names(origin_data))
  
  origin_data_sub <- origin_data %>%
    select(record_id, any_of(existing_dementia_vars))
  
  data_correct <- data %>%
    left_join(origin_data_sub, by = "record_id")
  
  for (i in seq_len(nrow(data_correct))) {
    source_i  <- safe_get_value(data_correct, i, "data_source")
    wave_i    <- safe_get_value(data_correct, i, "enrollment_wave")
    wave_info <- get_wave_info(source_i)
    
    if (is.null(wave_info) || is.na(wave_i)) {
      data_correct$event_status[i]  <- 0L
      data_correct$time_to_event[i] <- NA_real_
      next
    }
    
    wave_i          <- as.integer(wave_i)
    max_wave_i      <- wave_info$max_wave
    wave_years_i    <- wave_info$wave_years
    baseline_year_i <- wave_years_i[wave_i]
    
    if (wave_i >= max_wave_i) {
      data_correct$event_status[i]  <- 0L
      data_correct$time_to_event[i] <- NA_real_
      next
    }
    
    future_waves <- seq.int(wave_i + 1L, max_wave_i)
    
    future_dementia <- vapply(
      future_waves,
      function(wave) safe_get_value(data_correct, i, paste0("r", wave, "dementia")),
      numeric(1)
    )
    
    valid_index <- which(!is.na(future_dementia))
    
    if (length(valid_index) == 0) {
      data_correct$event_status[i]  <- 0L
      data_correct$time_to_event[i] <- NA_real_
      next
    }
    
    valid_dementia <- future_dementia[valid_index]
    valid_waves    <- future_waves[valid_index]
    
    last_followup_wave   <- tail(valid_waves, 1)
    last_followup_year_i <- wave_years_i[last_followup_wave]
    data_correct$last_followup_year[i] <- last_followup_year_i
    
    event_i      <- 0L
    onset_year_i <- NA_real_
    
    first_positive_position <- which(valid_dementia == 1)[1]
    
    if (!is.na(first_positive_position)) {
      first_positive_wave <- valid_waves[first_positive_position]
      first_positive_year <- wave_years_i[first_positive_wave]
      
      if (first_positive_position < length(valid_dementia)) {
        next_valid_dementia <- valid_dementia[first_positive_position + 1L]
        if (next_valid_dementia != 0) {
          event_i      <- 1L
          onset_year_i <- first_positive_year
        }
      } else {
        event_i      <- 1L
        onset_year_i <- first_positive_year
      }
    }
    
    data_correct$event_status[i] <- event_i
    
    if (event_i == 1L) {
      data_correct$time_to_event[i] <- onset_year_i - baseline_year_i
    } else {
      data_correct$time_to_event[i] <- last_followup_year_i - baseline_year_i
    }
  }
  
  data_correct %>%
    select(-any_of(existing_dementia_vars)) %>%
    filter(!is.na(time_to_event), time_to_event > 0)
}

# ----- 8. 构建分析基线数据 -----

cox_data_initial <- extract_baseline_covariates(data_in)

cox_data_final <- correct_event_status(
  data        = cox_data_initial,
  origin_data = data_in
) %>%
  mutate(event_status = as.integer(event_status))

# ----- 9. 描述与缺失统计 -----

n_all_participants <- nrow(total_data)

flow_order <- c(
  "纳入最终分析",
  "排除：年龄<50岁或年龄缺失",
  "排除：基线糖尿病或高血压状态缺失",
  "排除：基线患高血压",
  "排除：基线痴呆或基线暴露信息缺失",
  "排除：基线协变量数据缺失",
  "排除：基线后痴呆随访数据缺失",
  "排除：其他原因",
  "排除：未知数据来源"
)

flow_table <- screened_data %>%
  count(screening_status, name = "N") %>%
  mutate(
    percent_of_total = round(N / n_all_participants * 100, 2),
    screening_status = factor(screening_status, levels = flow_order)
  ) %>%
  arrange(screening_status)

flow_by_country <- screened_data %>%
  mutate(screening_status = factor(screening_status, levels = flow_order)) %>%
  group_by(country, screening_status) %>%
  summarise(N = n(), .groups = "drop") %>%
  pivot_wider(names_from = screening_status, values_from = N, values_fill = 0)

sample_by_country <- cox_data_final %>%
  group_by(country) %>%
  summarise(
    N = n(),
    diabetes_group  = sum(baseline_onlydiabe == 1, na.rm = TRUE),
    control_group   = sum(baseline_onlydiabe == 0, na.rm = TRUE),
    dementia_events = sum(event_status == 1, na.rm = TRUE),
    non_events      = sum(event_status == 0, na.rm = TRUE),
    mean_followup   = round(mean(time_to_event, na.rm = TRUE), 2),
    median_followup = median(time_to_event, na.rm = TRUE),
    mediator_phy_missing = sum(is.na(baseline_phyactivities)),
    mediator_net_missing = sum(is.na(baseline_netuse)),
    .groups = "drop"
  ) %>%
  mutate(country = as.character(country))

overall_sample <- cox_data_final %>%
  summarise(
    country = "总体（四国合并）",
    N = n(),
    diabetes_group  = sum(baseline_onlydiabe == 1, na.rm = TRUE),
    control_group   = sum(baseline_onlydiabe == 0, na.rm = TRUE),
    dementia_events = sum(event_status == 1, na.rm = TRUE),
    non_events      = sum(event_status == 0, na.rm = TRUE),
    mean_followup   = round(mean(time_to_event, na.rm = TRUE), 2),
    median_followup = median(time_to_event, na.rm = TRUE),
    mediator_phy_missing = sum(is.na(baseline_phyactivities)),
    mediator_net_missing = sum(is.na(baseline_netuse))
  )

sample_with_overall <- bind_rows(sample_by_country, overall_sample)

miss_diag <- data.frame(
  variable   = c("baseline_phyactivities", "baseline_netuse"),
  n_missing  = c(sum(is.na(cox_data_final$baseline_phyactivities)),
                 sum(is.na(cox_data_final$baseline_netuse))),
  n_total    = nrow(cox_data_final)
) %>%
  mutate(pct_missing = round(n_missing / n_total * 100, 2))

miss_diag_by_country <- cox_data_final %>%
  group_by(country) %>%
  summarise(
    N = n(),
    phy_missing = sum(is.na(baseline_phyactivities)),
    phy_pct = round(sum(is.na(baseline_phyactivities)) / n() * 100, 2),
    net_missing = sum(is.na(baseline_netuse)),
    net_pct = round(sum(is.na(baseline_netuse)) / n() * 100, 2),
    .groups = "drop"
  )

# ----- 10. MICE 多重插补 -----

imp_vars <- c(
  "baseline_phyactivities", "baseline_netuse",
  "baseline_onlydiabe", "event_status", "time_to_event",
  "yearsold", "ragender", "raeduc_c",
  "baseline_mstat", "baseline_scocwk",
  "baseline_smoking", "baseline_drink",
  "baseline_Non_com_dis", "data_source"
)

data_imp <- cox_data_final[, imp_vars]
data_imp_num <- as.data.frame(lapply(data_imp, as.numeric))

cat("\n====================================================\n")
cat("开始 MICE 多重插补 (m =", N_IMP, ", maxit = 20) ...\n")
cat("====================================================\n")

imp_result <- mice(
  data_imp_num,
  m       = N_IMP,
  maxit   = 50,
  method  = c("pmm", "pmm", rep("", ncol(data_imp_num) - 2)),
  predictorMatrix = quickpred(data_imp_num, mincor = 0.1),
  seed    = 20241201,
  printFlag = TRUE
)

cat("MICE 插补完成。\n")

# ----- 11. 中介分析核心函数（修复分母极端波动）-----

mediate_analysis <- function(data_sub, mediator_name, boot_times = 500) {
  tryCatch({
    covariates <- c(
      "yearsold", "ragender", "raeduc_c",
      "baseline_mstat", "baseline_scocwk",
      "baseline_smoking", "baseline_drink",
      "baseline_Non_com_dis"
    )
    
    med_formula <- as.formula(paste(
      mediator_name, "~ baseline_onlydiabe +",
      paste(covariates, collapse = " + ")
    ))
    
    out_formula <- as.formula(paste(
      "Surv(time_to_event, event_status) ~ baseline_onlydiabe +",
      mediator_name, "+",
      paste(covariates, collapse = " + ")
    ))
    
    out_formula_total <- as.formula(paste(
      "Surv(time_to_event, event_status) ~ baseline_onlydiabe +",
      paste(covariates, collapse = " + ")
    ))
    
    med_model       <- lm(med_formula, data = data_sub)
    out_model       <- coxph(out_formula, data = data_sub)
    out_model_total <- coxph(out_formula_total, data = data_sub)
    
    a_coef        <- coef(med_model)["baseline_onlydiabe"]
    b_coef        <- coef(out_model)[mediator_name]
    c_total_coef  <- coef(out_model_total)["baseline_onlydiabe"]
    
    indirect_effect <- a_coef * b_coef
    
    # 点估计中介比例
    mediation_proportion <- ifelse(c_total_coef > 0 && indirect_effect > 0,
                                   (indirect_effect / c_total_coef) * 100, NA_real_)
    
    a_se <- summary(med_model)$coefficients["baseline_onlydiabe", "Std. Error"]
    b_se <- summary(out_model)$coefficients[mediator_name, "se(coef)"]
    
    # Delta-method 标准误
    indirect_se      <- sqrt(a_coef^2 * b_se^2 + b_coef^2 * a_se^2)
    indirect_z       <- indirect_effect / indirect_se
    indirect_p_delta <- 2 * (1 - pnorm(abs(indirect_z)))
    
    # ----- Bootstrap 检验间接效应 -----
    
    boot_indirect <- numeric(boot_times)
    
    for (i in 1:boot_times) {
      boot_idx  <- sample(1:nrow(data_sub), nrow(data_sub), replace = TRUE)
      boot_data <- data_sub[boot_idx, ]
      
      boot_med <- tryCatch(lm(med_formula, data = boot_data), error = function(e) NULL)
      boot_out <- tryCatch(coxph(out_formula, data = boot_data), error = function(e) NULL)
      
      if (!is.null(boot_med) && !is.null(boot_out)) {
        boot_a <- tryCatch(coef(boot_med)["baseline_onlydiabe"], error = function(e) NA)
        boot_b <- tryCatch(coef(boot_out)[mediator_name], error = function(e) NA)
        
        if (!is.na(boot_a) && !is.na(boot_b)) {
          boot_indirect[i] <- boot_a * boot_b
        } else {
          boot_indirect[i] <- NA
        }
      } else {
        boot_indirect[i] <- NA
      }
    }
    
    boot_indirect <- boot_indirect[!is.na(boot_indirect)]
    
    boot_pval <- function(vals, null_val = 0) {
      n_b <- length(vals)
      if (n_b == 0) return(NA_real_)
      p <- 2 * min(
        (sum(vals <= null_val) + 1) / (n_b + 1),
        (sum(vals >= null_val) + 1) / (n_b + 1)
      )
      min(p, 1)
    }
    
    if (length(boot_indirect) > 0) {
      indirect_ci_lower <- as.numeric(quantile(boot_indirect, 0.025, na.rm = TRUE))
      indirect_ci_upper <- as.numeric(quantile(boot_indirect, 0.975, na.rm = TRUE))
      indirect_boot_sd  <- sd(boot_indirect)
      indirect_boot_p   <- boot_pval(boot_indirect)
    } else {
      indirect_ci_lower <- NA_real_
      indirect_ci_upper <- NA_real_
      indirect_boot_sd  <- NA_real_
      indirect_boot_p   <- NA_real_
    }
    
    return(list(
      a_coef               = as.numeric(a_coef),
      b_coef               = as.numeric(b_coef),
      c_total              = as.numeric(c_total_coef),
      indirect_effect      = as.numeric(indirect_effect),
      indirect_se          = as.numeric(indirect_se),
      indirect_ci_lower    = indirect_ci_lower,
      indirect_ci_upper    = indirect_ci_upper,
      indirect_boot_sd     = indirect_boot_sd,
      indirect_boot_p      = indirect_boot_p,
      indirect_p_delta     = as.numeric(indirect_p_delta),
      mediation_proportion = as.numeric(mediation_proportion),
      sample_size          = nrow(data_sub),
      boot_success         = length(boot_indirect)
    ))
  }, error = function(e) {
    return(NULL)
  })
}

# ----- 12. Rubin's Rules 跨插补集合并函数 -----

rubin_pool <- function(estimates, ses) {
  ok <- !is.na(estimates) & !is.na(ses) & is.finite(estimates) & is.finite(ses)
  estimates <- estimates[ok]
  ses       <- ses[ok]
  m_act     <- length(estimates)
  
  if (m_act == 0) {
    return(list(pooled = NA_real_, se = NA_real_, ci_lower = NA_real_,
                ci_upper = NA_real_, p_value = NA_real_, df = NA_real_,
                v_within = NA_real_, v_between = NA_real_, v_total = NA_real_,
                lambda = NA_real_))
  }
  
  qbar <- mean(estimates)
  ubar <- mean(ses^2)
  b    <- if (m_act >= 2) var(estimates) else 0
  
  v_total <- ubar + (1 + 1 / m_act) * b
  
  df <- if (b == 0 || m_act < 2) Inf else (m_act - 1) * (1 + ubar / ((1 + 1 / m_act) * b))^2
  
  se     <- sqrt(v_total)
  t_stat <- qbar / se
  
  if (is.infinite(df)) {
    p_value  <- 2 * (1 - pnorm(abs(t_stat)))
    ci_lower <- qbar - qnorm(0.975) * se
    ci_upper <- qbar + qnorm(0.975) * se
  } else {
    p_value  <- 2 * (1 - pt(abs(t_stat), df))
    ci_lower <- qbar - qt(0.975, df) * se
    ci_upper <- qbar + qt(0.975, df) * se
  }
  
  lambda <- ifelse(v_total > 0, ((1 + 1 / m_act) * b) / v_total, NA_real_)
  
  list(pooled = qbar, se = se, ci_lower = ci_lower, ci_upper = ci_upper,
       p_value = p_value, df = df, v_within = ubar, v_between = b,
       v_total = v_total, lambda = lambda)
}

# ----- 13. 单插补集内 Meta 合并函数 -----

pool_meta_indirect <- function(db_res, exclude_db = NULL) {
  tryCatch({
    if (!is.null(exclude_db)) {
      db_res <- db_res[!names(db_res) %in% exclude_db]
    }
    
    yi <- sapply(db_res, function(x) if (!is.null(x)) x$indirect_effect else NA_real_)
    sei <- sapply(db_res, function(x) {
      if (!is.null(x)) {
        if (!is.na(x$indirect_boot_sd) && x$indirect_boot_sd > 0) x$indirect_boot_sd else x$indirect_se
      } else NA_real_
    })
    
    valid <- !is.na(yi) & !is.na(sei) & sei > 0 & is.finite(sei)
    
    if (sum(valid) >= 2) {
      meta <- rma(yi = yi[valid], sei = sei[valid], method = "REML")
      list(
        indirect_logHR = as.numeric(meta$b[1]),
        se             = as.numeric(meta$se),
        CI_lower       = as.numeric(meta$ci.lb),
        CI_upper       = as.numeric(meta$ci.ub),
        p_value        = as.numeric(meta$pval),
        I2             = as.numeric(meta$I2),
        Q              = as.numeric(meta$QE),
        p_Q            = as.numeric(meta$QEp),
        tau2           = as.numeric(meta$tau2),
        k              = sum(valid)
      )
    } else {
      list(indirect_logHR = NA_real_, se = NA_real_, CI_lower = NA_real_,
           CI_upper = NA_real_, p_value = NA_real_, I2 = NA_real_,
           Q = NA_real_, p_Q = NA_real_, tau2 = NA_real_, k = sum(valid))
    }
  }, error = function(e) {
    list(indirect_logHR = NA_real_, se = NA_real_, CI_lower = NA_real_,
         CI_upper = NA_real_, p_value = NA_real_, I2 = NA_real_,
         Q = NA_real_, p_Q = NA_real_, tau2 = NA_real_, k = NA_integer_)
  })
}

# =====================================================================
# 纵向中介路径效应函数（对应表3）
#   a-paths: 糖尿病 → 中介变量（logistic 回归，输出 OR）
#   b-paths: 中介变量 → 痴呆（联合 Cox 模型，输出 HR）
#   c'     : 直接效应（联合 Cox 模型中糖尿病系数）
#   c      : 总效应（无中介 Cox 模型中糖尿病系数）
#   间接效应 = a × b（Delta-method SE）
# =====================================================================

compute_path_effects <- function(data_sub) {
  tryCatch({
    covariates <- c(
      "yearsold", "ragender", "raeduc_c",
      "baseline_mstat", "baseline_scocwk",
      "baseline_smoking", "baseline_drink",
      "baseline_Non_com_dis"
    )
    
    # --- a1: Diabetes → Physical activity (logistic → OR) ---
    a1_formula <- as.formula(paste(
      "baseline_phyactivities ~ baseline_onlydiabe +",
      paste(covariates, collapse = " + ")
    ))
    a1_fit <- glm(a1_formula, data = data_sub, family = binomial())
    a1_est <- unname(coef(a1_fit)["baseline_onlydiabe"])
    a1_se  <- unname(summary(a1_fit)$coefficients["baseline_onlydiabe", "Std. Error"])
    
    # --- a2: Diabetes → Internet use (logistic → OR) ---
    a2_formula <- as.formula(paste(
      "baseline_netuse ~ baseline_onlydiabe +",
      paste(covariates, collapse = " + ")
    ))
    a2_fit <- glm(a2_formula, data = data_sub, family = binomial())
    a2_est <- unname(coef(a2_fit)["baseline_onlydiabe"])
    a2_se  <- unname(summary(a2_fit)$coefficients["baseline_onlydiabe", "Std. Error"])
    
    # --- Joint outcome model: b1, b2, c' (Cox → HR) ---
    joint_formula <- as.formula(paste(
      "Surv(time_to_event, event_status) ~ baseline_onlydiabe +",
      "baseline_phyactivities + baseline_netuse +",
      paste(covariates, collapse = " + ")
    ))
    joint_fit <- coxph(joint_formula, data = data_sub)
    joint_summ <- summary(joint_fit)$coefficients
    
    b1_est <- unname(joint_summ["baseline_phyactivities", "coef"])
    b1_se  <- unname(joint_summ["baseline_phyactivities", "se(coef)"])
    b2_est <- unname(joint_summ["baseline_netuse", "coef"])
    b2_se  <- unname(joint_summ["baseline_netuse", "se(coef)"])
    cp_est <- unname(joint_summ["baseline_onlydiabe", "coef"])
    cp_se  <- unname(joint_summ["baseline_onlydiabe", "se(coef)"])
    
    # --- Total effect: c (Cox without mediators → HR) ---
    total_formula <- as.formula(paste(
      "Surv(time_to_event, event_status) ~ baseline_onlydiabe +",
      paste(covariates, collapse = " + ")
    ))
    total_fit <- coxph(total_formula, data = data_sub)
    c_est <- unname(coef(total_fit)["baseline_onlydiabe"])
    c_se  <- unname(summary(total_fit)$coefficients["baseline_onlydiabe", "se(coef)"])
    
    # --- Indirect effects: a × b (Delta-method SE) ---
    ind_pa_est  <- a1_est * b1_est
    ind_pa_se   <- sqrt(a1_est^2 * b1_se^2 + b1_est^2 * a1_se^2)
    ind_net_est <- a2_est * b2_est
    ind_net_se  <- sqrt(a2_est^2 * b2_se^2 + b2_est^2 * a2_se^2)
    
    list(
      a1       = c(est = a1_est,  se = a1_se),
      a2       = c(est = a2_est,  se = a2_se),
      b1       = c(est = b1_est,  se = b1_se),
      b2       = c(est = b2_est,  se = b2_se),
      c_total  = c(est = c_est,   se = c_se),
      c_prime  = c(est = cp_est,  se = cp_se),
      ind_pa   = c(est = ind_pa_est,  se = ind_pa_se),
      ind_net  = c(est = ind_net_est, se = ind_net_se),
      n        = nrow(data_sub),
      events   = sum(data_sub$event_status == 1)
    )
  }, error = function(e) {
    message("    [路径分析失败] ", e$message)
    NULL
  })
}

# ----- 14. 运行多重插补分析（单中介模型）-----

db_names <- c("CHARLS", "HRS", "SHARE", "ELSA")
db_codes <- c(1, 2, 3, 4)

phy_db_by_imp         <- list()
net_db_by_imp         <- list()
phy_pooled_all_by_imp <- list()
net_pooled_all_by_imp <- list()
phy_pooled_west_by_imp <- list()
net_pooled_west_by_imp <- list()

for (imp_i in 1:N_IMP) {
  cat("\n--- 正在分析插补数据集 ", imp_i, "/", N_IMP, " ---\n", sep = "")
  
  imp_data_num <- complete(imp_result, imp_i)
  
  imp_data <- imp_data_num %>%
    mutate(
      yearsold      = factor(yearsold, levels = c(1, 2, 3, 4)),
      ragender      = factor(ragender, levels = c(1, 2)),
      raeduc_c      = factor(raeduc_c, levels = c(1, 2, 3)),
      baseline_mstat   = factor(baseline_mstat, levels = c(1, 2)),
      baseline_scocwk  = factor(baseline_scocwk, levels = c(0, 1)),
      baseline_smoking = factor(baseline_smoking, levels = c(0, 1, 2)),
      baseline_drink   = factor(baseline_drink, levels = c(0, 1)),
      baseline_Non_com_dis = factor(baseline_Non_com_dis, levels = c(0, 1)),
      baseline_onlydiabe    = as.numeric(baseline_onlydiabe),
      baseline_phyactivities = as.numeric(baseline_phyactivities),
      baseline_netuse        = as.numeric(baseline_netuse),
      event_status   = as.integer(event_status),
      time_to_event  = as.numeric(time_to_event),
      data_source    = as.numeric(data_source)
    )
  
  phy_db_res <- list()
  net_db_res <- list()
  
  for (j in seq_along(db_codes)) {
    db_data <- imp_data %>% filter(data_source == db_codes[j])
    
    if (nrow(db_data) >= 30) {
      cat("  ", db_names[j], ": 身体活动中介分析 ... ", sep = "")
      phy_db_res[[db_names[j]]] <- mediate_analysis(db_data, "baseline_phyactivities", boot_times = BOOT_TIMES)
      cat("完成; 互联网中介分析 ... ")
      net_db_res[[db_names[j]]] <- mediate_analysis(db_data, "baseline_netuse", boot_times = BOOT_TIMES)
      cat("完成\n")
    } else {
      phy_db_res[[db_names[j]]] <- NULL
      net_db_res[[db_names[j]]] <- NULL
    }
  }
  
  phy_db_by_imp[[imp_i]] <- phy_db_res
  net_db_by_imp[[imp_i]] <- net_db_res
  
  # A. 4国全合并
  phy_pooled_all_by_imp[[imp_i]] <- pool_meta_indirect(phy_db_res)
  net_pooled_all_by_imp[[imp_i]] <- pool_meta_indirect(net_db_res)
  
  # B. 欧美3国合并 (排除 CHARLS)
  phy_pooled_west_by_imp[[imp_i]] <- pool_meta_indirect(phy_db_res, exclude_db = "CHARLS")
  net_pooled_west_by_imp[[imp_i]] <- pool_meta_indirect(net_db_res, exclude_db = "CHARLS")
}

# =====================================================================
# 运行 10 重插补分析（并行中介路径效应，表3）
# =====================================================================

cat("\n====================================================\n")
cat("开始计算纵向中介路径效应汇总（表3）...\n")
cat("====================================================\n")

path_db_by_imp  <- list()
path_meta_by_imp <- list()

path_names <- c("a1", "a2", "b1", "b2", "c_total", "c_prime", "ind_pa", "ind_net")

for (imp_i in 1:N_IMP) {
  cat("\n--- 路径效应分析: 插补数据集 ", imp_i, "/", N_IMP, " ---\n", sep = "")
  
  imp_data_num <- complete(imp_result, imp_i)
  
  imp_data_path <- imp_data_num %>%
    mutate(
      yearsold      = factor(yearsold, levels = c(1, 2, 3, 4)),
      ragender      = factor(ragender, levels = c(1, 2)),
      raeduc_c      = factor(raeduc_c, levels = c(1, 2, 3)),
      baseline_mstat   = factor(baseline_mstat, levels = c(1, 2)),
      baseline_scocwk  = factor(baseline_scocwk, levels = c(0, 1)),
      baseline_smoking = factor(baseline_smoking, levels = c(0, 1, 2)),
      baseline_drink   = factor(baseline_drink, levels = c(0, 1)),
      baseline_Non_com_dis = factor(baseline_Non_com_dis, levels = c(0, 1)),
      baseline_onlydiabe    = as.numeric(baseline_onlydiabe),
      baseline_phyactivities = as.numeric(baseline_phyactivities),
      baseline_netuse        = as.numeric(baseline_netuse),
      event_status   = as.integer(event_status),
      time_to_event  = as.numeric(time_to_event),
      data_source    = as.numeric(data_source)
    )
  
  path_db_res <- list()
  
  for (j in seq_along(db_codes)) {
    db_data <- imp_data_path %>% filter(data_source == db_codes[j])
    
    if (nrow(db_data) >= 30) {
      cat("  ", db_names[j], " ... ", sep = "")
      res_tmp <- compute_path_effects(db_data)
      
      if (is.null(res_tmp)) {
        cat("失败（已跳过）\n")
      } else {
        path_db_res[[db_names[j]]] <- res_tmp
        cat("完成 (N=", res_tmp$n,
            ", events=", res_tmp$events, ")\n", sep = "")
      }
    }
  }
  
  path_db_by_imp[[imp_i]] <- path_db_res
  
  # 对每条路径在本插补集内做 Meta 合并
  path_meta <- list()
  
  for (pname in path_names) {
    yi  <- sapply(path_db_res, function(x) if (!is.null(x)) x[[pname]]["est"] else NA_real_)
    sei <- sapply(path_db_res, function(x) if (!is.null(x)) x[[pname]]["se"]  else NA_real_)
    
    valid <- !is.na(yi) & !is.na(sei) & sei > 0 & is.finite(sei) & is.finite(yi)
    
    if (sum(valid) >= 2) {
      meta <- tryCatch(
        rma(yi = yi[valid], sei = sei[valid], method = "REML"),
        error = function(e) NULL
      )
      
      if (!is.null(meta)) {
        path_meta[[pname]] <- list(
          est   = as.numeric(meta$b[1]),
          se    = as.numeric(meta$se),
          ci_lb = as.numeric(meta$ci.lb),
          ci_ub = as.numeric(meta$ci.ub),
          pval  = as.numeric(meta$pval),
          I2    = as.numeric(meta$I2),
          Q     = as.numeric(meta$QE),
          Qp    = as.numeric(meta$QEp),
          tau2  = as.numeric(meta$tau2),
          k     = sum(valid)
        )
      } else {
        path_meta[[pname]] <- list(
          est = NA_real_, se = NA_real_, ci_lb = NA_real_, ci_ub = NA_real_,
          pval = NA_real_, I2 = NA_real_, Q = NA_real_, Qp = NA_real_,
          tau2 = NA_real_, k = sum(valid)
        )
      }
    } else if (sum(valid) == 1) {
      path_meta[[pname]] <- list(
        est   = yi[valid],
        se    = sei[valid],
        ci_lb = yi[valid] - qnorm(0.975) * sei[valid],
        ci_ub = yi[valid] + qnorm(0.975) * sei[valid],
        pval  = 2 * (1 - pnorm(abs(yi[valid] / sei[valid]))),
        I2    = NA_real_, Q = NA_real_, Qp = NA_real_, tau2 = NA_real_,
        k     = 1L
      )
    } else {
      path_meta[[pname]] <- list(
        est = NA_real_, se = NA_real_, ci_lb = NA_real_, ci_ub = NA_real_,
        pval = NA_real_, I2 = NA_real_, Q = NA_real_, Qp = NA_real_,
        tau2 = NA_real_, k = 0L
      )
    }
  }
  
  path_meta_by_imp[[imp_i]] <- path_meta
}

# ----- 15. 跨插补集合：分国家总结表（Rubin's Rules）-----

pool_mi_db <- function(results_by_imp, db_names) {
  do.call(rbind, lapply(db_names, function(db) {
    a_coef  <- sapply(results_by_imp, function(imp) if (!is.null(imp[[db]])) imp[[db]]$a_coef else NA_real_)
    b_coef  <- sapply(results_by_imp, function(imp) if (!is.null(imp[[db]])) imp[[db]]$b_coef else NA_real_)
    c_tot   <- sapply(results_by_imp, function(imp) if (!is.null(imp[[db]])) imp[[db]]$c_total else NA_real_)
    ind     <- sapply(results_by_imp, function(imp) if (!is.null(imp[[db]])) imp[[db]]$indirect_effect else NA_real_)
    ind_sd  <- sapply(results_by_imp, function(imp) if (!is.null(imp[[db]])) imp[[db]]$indirect_boot_sd else NA_real_)
    ind_dse <- sapply(results_by_imp, function(imp) if (!is.null(imp[[db]])) imp[[db]]$indirect_se else NA_real_)
    prop    <- sapply(results_by_imp, function(imp) if (!is.null(imp[[db]])) imp[[db]]$mediation_proportion else NA_real_)
    ns      <- sapply(results_by_imp, function(imp) if (!is.null(imp[[db]])) imp[[db]]$sample_size else NA_real_)
    
    ind_ses   <- ifelse(!is.na(ind_sd) & ind_sd > 0, ind_sd, ind_dse)
    ind_rubin <- rubin_pool(ind, ind_ses)
    
    valid_props <- prop[!is.na(prop) & is.finite(prop)]
    mean_prop   <- if (length(valid_props) > 0) mean(valid_props) else NA_real_
    
    data.frame(
      Database          = db,
      N                 = round(mean(ns, na.rm = TRUE)),
      a_coef            = round(mean(a_coef, na.rm = TRUE), 4),
      b_coef_logHR      = round(mean(b_coef, na.rm = TRUE), 4),
      c_total_logHR     = round(mean(c_tot, na.rm = TRUE), 4),
      c_total_HR        = round(exp(mean(c_tot, na.rm = TRUE)), 3),
      Indirect_logHR    = round(ind_rubin$pooled, 4),
      Indirect_SE       = round(ind_rubin$se, 4),
      Indirect_HR       = round(exp(ind_rubin$pooled), 3),
      Indirect_CI_lower = round(ind_rubin$ci_lower, 4),
      Indirect_CI_upper = round(ind_rubin$ci_upper, 4),
      iHR_95CI          = sprintf("%.3f (%.3f, %.3f)", exp(ind_rubin$pooled), exp(ind_rubin$ci_lower), exp(ind_rubin$ci_upper)),
      Indirect_p        = ind_rubin$p_value,
      Mediation_Pct     = ifelse(!is.na(mean_prop), sprintf("%.1f%%", mean_prop), "—"),
      MI_lambda         = round(ind_rubin$lambda, 4),
      stringsAsFactors  = FALSE
    )
  }))
}

phy_db_summary <- pool_mi_db(phy_db_by_imp, db_names)
net_db_summary <- pool_mi_db(net_db_by_imp, db_names)

# ----- 16. Meta 合并汇报表（4 国全合并 与 欧美 3 国敏感性）-----

pool_mi_overall <- function(pooled_by_imp, label, model_type) {
  ests <- sapply(pooled_by_imp, function(x) x$indirect_logHR)
  ses  <- sapply(pooled_by_imp, function(x) x$se)
  i2   <- sapply(pooled_by_imp, function(x) x$I2)
  q    <- sapply(pooled_by_imp, function(x) x$Q)
  p_q  <- sapply(pooled_by_imp, function(x) x$p_Q)
  tau2 <- sapply(pooled_by_imp, function(x) x$tau2)
  k    <- sapply(pooled_by_imp, function(x) x$k)
  
  rubin <- rubin_pool(ests, ses)
  
  data.frame(
    Mediator      = label,
    Analysis_Type = model_type,
    k             = round(mean(k, na.rm = TRUE)),
    Pooled_logHR  = round(rubin$pooled, 4),
    SE            = round(rubin$se, 4),
    Pooled_iHR    = round(exp(rubin$pooled), 3),
    CI_lower      = round(exp(rubin$ci_lower), 3),
    CI_upper      = round(exp(rubin$ci_upper), 3),
    Pooled_Result = sprintf("%.3f (%.3f, %.3f)", exp(rubin$pooled), exp(rubin$ci_lower), exp(rubin$ci_upper)),
    p_value       = rubin$p_value,
    Mean_I2_Pct   = paste0(round(mean(i2, na.rm = TRUE), 1), "%"),
    Mean_Q        = round(mean(q, na.rm = TRUE), 2),
    Mean_p_Q      = mean(p_q, na.rm = TRUE),
    MI_lambda     = round(rubin$lambda, 4),
    stringsAsFactors = FALSE
  )
}

phy_final_all  <- pool_mi_overall(phy_pooled_all_by_imp,  "Physical Activity", "4-Cohort Global Pooled")
phy_final_west <- pool_mi_overall(phy_pooled_west_by_imp, "Physical Activity", "Western Cohorts (Excl. CHARLS)")
net_final_all  <- pool_mi_overall(net_pooled_all_by_imp,  "Internet Use",      "4-Cohort Global Pooled")
net_final_west <- pool_mi_overall(net_pooled_west_by_imp, "Internet Use",      "Western Cohorts (Excl. CHARLS)")

meta_combined_table <- bind_rows(phy_final_all, phy_final_west, net_final_all, net_final_west)

# =====================================================================
# 跨插补集合：路径效应汇总表（表3，Rubin's Rules）
# =====================================================================

path_labels <- data.frame(
  path  = c("a1", "a2", "b1", "b2", "c_total", "c_prime", "ind_pa", "ind_net"),
  group = c("a-paths", "a-paths", "b-paths", "b-paths",
            "Effect decomposition", "Effect decomposition",
            "Effect decomposition", "Effect decomposition"),
  path_label = c(
    "Diabetes \u2192 Physical activity (a1)",
    "Diabetes \u2192 Internet use (a2)",
    "Physical activity \u2192 Dementia (b1)",
    "Internet use \u2192 Dementia (b2)",
    "Total effect (Diabetes \u2192 Dementia)",
    "Direct effect (Diabetes \u2192 Dementia)",
    "Indirect effect via Physical activity",
    "Indirect effect via Internet use"
  ),
  effect_type = c("OR", "OR", "HR", "HR", "HR", "HR", "iHR", "iHR"),
  stringsAsFactors = FALSE
)

path_summary <- do.call(rbind, lapply(path_labels$path, function(pname) {
  ests <- sapply(path_meta_by_imp, function(x) x[[pname]]$est)
  ses  <- sapply(path_meta_by_imp, function(x) x[[pname]]$se)
  i2s  <- sapply(path_meta_by_imp, function(x) x[[pname]]$I2)
  qs   <- sapply(path_meta_by_imp, function(x) x[[pname]]$Q)
  qps  <- sapply(path_meta_by_imp, function(x) x[[pname]]$Qp)
  ks   <- sapply(path_meta_by_imp, function(x) x[[pname]]$k)
  
  rubin <- rubin_pool(ests, ses)
  info  <- path_labels[path_labels$path == pname, ]
  
  p_val <- rubin$p_value
  p_fmt <- ifelse(is.na(p_val), "—",
                  ifelse(p_val < 0.001, "<0.001", sprintf("%.3f", p_val)))
  
  mean_i2  <- mean(i2s, na.rm = TRUE)
  mean_qp  <- mean(qps, na.rm = TRUE)
  i2_fmt   <- ifelse(is.na(mean_i2), "—", sprintf("%.1f", mean_i2))
  qp_fmt   <- ifelse(is.na(mean_qp), "—",
                     ifelse(mean_qp < 0.001, "<0.001", sprintf("%.3f", mean_qp)))
  
  est_val <- exp(rubin$pooled)
  ci_lo   <- exp(rubin$ci_lower)
  ci_hi   <- exp(rubin$ci_upper)
  
  data.frame(
    Group        = info$group,
    Path         = info$path_label,
    Effect_Type  = info$effect_type,
    k            = round(mean(ks, na.rm = TRUE)),
    Estimate     = round(est_val, 3),
    CI_lower     = round(ci_lo, 3),
    CI_upper     = round(ci_hi, 3),
    Result_CI    = sprintf("%.3f (%.3f to %.3f)", est_val, ci_lo, ci_hi),
    p_value      = p_val,
    p_formatted  = p_fmt,
    I2_pct       = i2_fmt,
    Het_p        = qp_fmt,
    Mean_Q       = round(mean(qs, na.rm = TRUE), 2),
    MI_lambda    = round(rubin$lambda, 4),
    stringsAsFactors = FALSE
  )
}))

# 分国家路径估计（供森林图等后续使用）
path_by_country_summary <- do.call(rbind, lapply(db_names, function(db) {
  do.call(rbind, lapply(path_labels$path, function(pname) {
    ests <- sapply(path_db_by_imp, function(imp) {
      if (!is.null(imp[[db]])) imp[[db]][[pname]]["est"] else NA_real_
    })
    ses <- sapply(path_db_by_imp, function(imp) {
      if (!is.null(imp[[db]])) imp[[db]][[pname]]["se"] else NA_real_
    })
    ns <- sapply(path_db_by_imp, function(imp) {
      if (!is.null(imp[[db]])) imp[[db]]$n else NA_real_
    })
    
    rubin <- rubin_pool(ests, ses)
    info  <- path_labels[path_labels$path == pname, ]
    
    data.frame(
      Database    = db,
      Path        = info$path_label,
      Effect_Type = info$effect_type,
      N           = round(mean(ns, na.rm = TRUE)),
      log_Est     = round(rubin$pooled, 4),
      SE          = round(rubin$se, 4),
      Estimate    = round(exp(rubin$pooled), 3),
      CI_lower    = round(exp(rubin$ci_lower), 3),
      CI_upper    = round(exp(rubin$ci_upper), 3),
      Result_CI   = sprintf("%.3f (%.3f to %.3f)",
                            exp(rubin$pooled), exp(rubin$ci_lower), exp(rubin$ci_upper)),
      p_value     = rubin$p_value,
      stringsAsFactors = FALSE
    )
  }))
}))

# ----- 17. 打印主要结果 -----

cat("\n====================================================\n")
cat("表3. 纵向中介分析路径效应汇总（合并结果）\n")
cat("====================================================\n")
print(path_summary %>% select(Group, Path, Result_CI, p_formatted, I2_pct, Het_p),
      row.names = FALSE)

cat("\n====================================================\n")
cat("表5. 身体活动：分国家中介分析结果（Rubin's Rules 汇总）\n")
cat("====================================================\n")
print(phy_db_summary %>% select(Database, N, a_coef, b_coef_logHR, c_total_HR, iHR_95CI, Indirect_p, Mediation_Pct), row.names = FALSE)

cat("\n====================================================\n")
cat("表6. 互联网使用：分国家中介分析结果（Rubin's Rules 汇总）\n")
cat("====================================================\n")
print(net_db_summary %>% select(Database, N, a_coef, b_coef_logHR, c_total_HR, iHR_95CI, Indirect_p, Mediation_Pct), row.names = FALSE)

cat("\n====================================================\n")
cat("表7. 总体 Meta 合并分析（分层呈现全球合并与欧美队列合并）\n")
cat("====================================================\n")
print(meta_combined_table %>% select(Mediator, Analysis_Type, k, Pooled_Result, p_value, Mean_I2_Pct), row.names = FALSE)

# ----- 18. 完整案例敏感性分析 -----

cat("\n====================================================\n")
cat("开始完整案例敏感性分析 (Complete Case) ...\n")
cat("====================================================\n")

prepare_factor_data <- function(data) {
  data %>%
    mutate(
      yearsold      = factor(yearsold, levels = c(1, 2, 3, 4)),
      ragender      = factor(ragender, levels = c(1, 2)),
      raeduc_c      = factor(raeduc_c, levels = c(1, 2, 3)),
      baseline_mstat   = factor(baseline_mstat, levels = c(1, 2)),
      baseline_scocwk  = factor(baseline_scocwk, levels = c(0, 1)),
      baseline_smoking = factor(baseline_smoking, levels = c(0, 1, 2)),
      baseline_drink   = factor(baseline_drink, levels = c(0, 1)),
      baseline_Non_com_dis = factor(baseline_Non_com_dis, levels = c(0, 1)),
      baseline_onlydiabe    = as.numeric(baseline_onlydiabe),
      baseline_phyactivities = as.numeric(baseline_phyactivities),
      baseline_netuse        = as.numeric(baseline_netuse),
      event_status   = as.integer(event_status),
      time_to_event  = as.numeric(time_to_event)
    )
}

mediator_map <- c(
  "baseline_phyactivities" = "Physical Activity",
  "baseline_netuse"        = "Internet Use"
)

cc_results <- list()
cc_meta_input <- list(
  "Physical Activity" = list(yi = c(), sei = c(), labels = c()),
  "Internet Use"      = list(yi = c(), sei = c(), labels = c())
)

for (med_var in names(mediator_map)) {
  med_label <- mediator_map[[med_var]]
  
  for (db in db_names) {
    n_total <- sum(cox_data_final$country == db)
    cc_data <- cox_data_final[cox_data_final$country == db, ]
    cc_data <- cc_data[!is.na(cc_data[[med_var]]), ]
    n_cc    <- nrow(cc_data)
    n_miss  <- n_total - n_cc
    
    if (n_cc >= 30) {
      cc_fac <- prepare_factor_data(cc_data)
      res    <- mediate_analysis(cc_fac, med_var, boot_times = BOOT_TIMES)
      
      if (!is.null(res)) {
        cc_results[[paste(med_label, db, sep = "_")]] <- data.frame(
          Mediator          = med_label,
          Database          = db,
          N_complete        = n_cc,
          Pct_missing       = round(n_miss / n_total * 100, 2),
          Indirect_HR       = round(exp(res$indirect_effect), 3),
          iHR_95CI          = sprintf("%.3f (%.3f, %.3f)", exp(res$indirect_effect), exp(res$indirect_ci_lower), exp(res$indirect_ci_upper)),
          Indirect_p        = res$indirect_boot_p,
          Mediation_Pct     = ifelse(!is.na(res$mediation_proportion), sprintf("%.1f%%", res$mediation_proportion), "—"),
          stringsAsFactors  = FALSE
        )
        
        cc_se <- if (!is.na(res$indirect_boot_sd) && res$indirect_boot_sd > 0) res$indirect_boot_sd else res$indirect_se
        cc_meta_input[[med_label]]$yi     <- c(cc_meta_input[[med_label]]$yi, res$indirect_effect)
        cc_meta_input[[med_label]]$sei    <- c(cc_meta_input[[med_label]]$sei, cc_se)
        cc_meta_input[[med_label]]$labels <- c(cc_meta_input[[med_label]]$labels, db)
      }
    }
  }
}

cc_summary <- do.call(rbind, cc_results)

cc_meta_summary <- do.call(rbind, lapply(names(cc_meta_input), function(med_label) {
  yi  <- cc_meta_input[[med_label]]$yi
  sei <- cc_meta_input[[med_label]]$sei
  
  valid <- !is.na(yi) & !is.na(sei) & sei > 0 & is.finite(sei)
  
  if (sum(valid) >= 2) {
    meta <- rma(yi = yi[valid], sei = sei[valid], method = "REML")
    data.frame(
      Mediator      = med_label,
      k             = sum(valid),
      Pooled_iHR    = round(exp(meta$b[1]), 3),
      Pooled_Result = sprintf("%.3f (%.3f, %.3f)", exp(meta$b[1]), exp(meta$ci.lb), exp(meta$ci.ub)),
      p_value       = meta$pval,
      I2_Pct        = paste0(round(meta$I2, 1), "%"),
      stringsAsFactors = FALSE
    )
  } else {
    NULL
  }
}))

# ----- 19. Meta 留一法敏感性分析 -----

loo_results <- list()

mediator_by_imp <- list(
  "Physical Activity" = phy_db_by_imp,
  "Internet Use"      = net_db_by_imp
)

for (med_label in names(mediator_by_imp)) {
  res_by_imp <- mediator_by_imp[[med_label]]
  
  for (excluded_db in db_names) {
    loo_by_imp <- vector("list", N_IMP)
    
    for (imp_i in 1:N_IMP) {
      tmp_res <- res_by_imp[[imp_i]]
      tmp_res[[excluded_db]] <- NULL
      loo_by_imp[[imp_i]] <- pool_meta_indirect(tmp_res)
    }
    
    loo_pooled <- pool_mi_overall(loo_by_imp, med_label, paste0("Excluding ", excluded_db))
    loo_pooled$Excluded <- excluded_db
    loo_results[[paste(med_label, excluded_db, sep = "_")]] <- loo_pooled
  }
}

loo_summary <- do.call(rbind, loo_results) %>%
  select(Mediator, Excluded, k, Pooled_Result, p_value, Mean_I2_Pct)

# ----- 20. Schoenfeld PH 检验 -----

complete_data <- cox_data_final %>%
  filter(!is.na(baseline_phyactivities), !is.na(baseline_netuse)) %>%
  mutate(
    yearsold      = factor(yearsold, levels = c(1,2,3,4), labels = c("60岁以下","60-69岁","70-79岁","80岁及以上")),
    ragender      = factor(ragender, levels = c(1,2), labels = c("男","女")),
    raeduc_c      = factor(raeduc_c, levels = c(1,2,3), labels = c("初中及以下","高中","大学及以上")),
    baseline_onlydiabe = factor(baseline_onlydiabe, levels = c(0,1), labels = c("无糖尿病且无高血压","糖尿病且无高血压")),
    baseline_phyactivities = factor(baseline_phyactivities, levels = c(0,1), labels = c("不活跃","活跃")),
    baseline_netuse = factor(baseline_netuse, levels = c(0,1), labels = c("不使用","使用")),
    baseline_mstat  = factor(baseline_mstat, levels = c(1,2), labels = c("已婚/同居","单身")),
    baseline_scocwk = factor(baseline_scocwk, levels = c(0,1), labels = c("不活跃","活跃")),
    baseline_smoking = factor(baseline_smoking, levels = c(0,1,2), labels = c("戒烟","吸烟","从未吸烟")),
    baseline_drink  = factor(baseline_drink, levels = c(0,1), labels = c("从未饮酒","饮过酒")),
    baseline_Non_com_dis = factor(baseline_Non_com_dis, levels = c(0,1), labels = c("无","有"))
  )

ph_formula <- Surv(time_to_event, event_status) ~ baseline_onlydiabe +
  yearsold + ragender + raeduc_c +
  baseline_phyactivities + baseline_netuse +
  baseline_mstat + baseline_scocwk +
  baseline_smoking + baseline_drink + baseline_Non_com_dis

ph_results <- do.call(rbind, lapply(db_names, function(cn) {
  dt <- droplevels(complete_data %>% filter(country == cn))
  
  if (nrow(dt) == 0 || sum(dt$event_status == 1) == 0 || nlevels(dt$baseline_onlydiabe) < 2) {
    return(data.frame(country = cn, variable = NA_character_, rho = NA_real_, chisq = NA_real_, p_value = NA_real_, ph_assumption = "无法检验", stringsAsFactors = FALSE))
  }
  
  fit <- tryCatch(coxph(ph_formula, data = dt, x = TRUE, model = TRUE), error = function(e) NULL)
  
  if (is.null(fit)) {
    return(data.frame(country = cn, variable = NA_character_, rho = NA_real_, chisq = NA_real_, p_value = NA_real_, ph_assumption = "模型拟合失败", stringsAsFactors = FALSE))
  }
  
  zph <- tryCatch(cox.zph(fit, transform = "km"), error = function(e) NULL)
  
  if (is.null(zph)) {
    return(data.frame(country = cn, variable = NA_character_, rho = NA_real_, chisq = NA_real_, p_value = NA_real_, ph_assumption = "Schoenfeld残差计算失败", stringsAsFactors = FALSE))
  }
  
  tab <- as.data.frame(zph$table) %>% tibble::rownames_to_column("variable")
  
  if (!"rho" %in% names(tab))   tab$rho  <- NA_real_
  if (!"chisq" %in% names(tab)) tab$chisq <- NA_real_
  if (!"p" %in% names(tab))     tab$p    <- NA_real_
  
  tab %>% transmute(
    country = cn, variable = variable, rho = rho, chisq = chisq, p_value = p,
    ph_assumption = case_when(
      is.na(p_value) ~ "无法判断",
      variable == "GLOBAL" & p_value >= 0.05 ~ "整体模型满足PH假设",
      variable == "GLOBAL" & p_value <  0.05 ~ "整体模型可能违反PH假设",
      p_value >= 0.05 ~ "未发现违反PH假设证据",
      p_value <  0.05 ~ "可能违反PH假设"
    )
  )
}))

# ----- 21. 导出结果文件 -----

write_excel_csv(flow_table,             "糖尿病中介_表1_筛选流程_总体.csv")
write_excel_csv(flow_by_country,        "糖尿病中介_表2_筛选流程_分国家.csv")
write_excel_csv(sample_with_overall,    "糖尿病中介_表3_样本量事件数随访.csv")
write_excel_csv(miss_diag,              "糖尿病中介_表4_中介变量缺失诊断.csv")
write_excel_csv(miss_diag_by_country,   "糖尿病中介_表4b_中介变量缺失诊断_分国家.csv")
write_excel_csv(path_summary,           "糖尿病中介_路径效应汇总_合并结果.csv")
write_excel_csv(path_by_country_summary,"糖尿病中介_路径效应_分国家估计.csv")
write_excel_csv(phy_db_summary,         "糖尿病中介_表5_身体活动_分国家结果.csv")
write_excel_csv(net_db_summary,         "糖尿病中介_表6_互联网使用_分国家结果.csv")
write_excel_csv(meta_combined_table,    "糖尿病中介_表7_总体与分层Meta合并结果.csv")
write_excel_csv(ph_results,             "糖尿病中介_表8_Schoenfeld_PH检验.csv")
write_excel_csv(cc_summary,             "糖尿病中介_表9_完整案例敏感性分析_分国家.csv")
write_excel_csv(cc_meta_summary,        "糖尿病中介_表9b_完整案例敏感性分析_Meta合并.csv")
write_excel_csv(loo_summary,            "糖尿病中介_表10_Meta留一法敏感性分析.csv")
write_excel_csv(cox_data_final,         "糖尿病中介_最终分析数据.csv")

cat("\n====================================================\n")
cat("全套分析已顺利完成并成功导出！\n")
cat("新增：糖尿病中介_路径效应汇总_合并结果.csv（a-paths / b-paths / 效应分解）\n")
cat("新增：糖尿病中介_路径效应_分国家估计.csv（供森林图使用）\n")
cat("===============