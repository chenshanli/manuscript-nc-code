# =====================================================================
# Cox 回归、Schoenfeld 残差比例风险假设检验及随机效应 Meta 分析
#
# 代码逻辑结构：
# 1. 读取并检查原始数据
# 2. 根据动态基线规则筛选研究对象
# 3. 提取动态基线协变量、计算随访时间和痴呆事件
# 4. 校正痴呆事件状态及随访时间
# 5. 分国家进行多变量 Cox 回归
# 6. 使用 Schoenfeld 残差检验 Cox 比例风险假设
# 7. 对四国 Cox 结果进行随机效应 Meta 分析
# 8. 导出流程图、Cox、PH 假设检验及 Meta 分析结果
# =====================================================================

# =====================================================================
# 0. 环境设置与加载包
# =====================================================================

setwd("E:/csl/CSL/database")

library(dplyr)
library(tidyr)
library(haven)
library(survival)
library(broom)
library(meta)
library(readr)

# 防止其他包覆盖 dplyr::select
select <- dplyr::select

# =====================================================================
# 1. 读取数据
# =====================================================================

total_data <- read_dta("both_data_new.dta") %>%
  mutate(record_id = row_number())

# =====================================================================
# 2. 基础变量检查与死亡变量处理
# =====================================================================

required_basic_vars <- c(
  "ID", "data_source", "yearsold", "age", "raeduc_c", "ragender"
)

missing_basic_vars <- setdiff(required_basic_vars, names(total_data))

if (length(missing_basic_vars) > 0) {
  stop(
    "数据中缺少以下必要变量：",
    paste(missing_basic_vars, collapse = ", ")
  )
}

# 死亡变量：如果存在，则将缺失值填补为 0
death_vars <- c(
  "r1death", "r2death", "r3death",
  "r4death", "r5death", "r6death"
)

existing_death_vars <- intersect(death_vars, names(total_data))

if (length(existing_death_vars) > 0) {
  total_data <- total_data %>%
    mutate(
      across(
        all_of(existing_death_vars),
        ~ replace_na(as.numeric(.x), 0)
      )
    )
}

# =====================================================================
# 3. 全局安全取值函数
# =====================================================================

safe_get_value <- function(data, row_idx, var_name) {
  
  if (!var_name %in% names(data)) {
    return(NA_real_)
  }
  
  value <- data[[var_name]][row_idx]
  
  if (length(value) == 0 || is.null(value) || is.na(value)) {
    return(NA_real_)
  }
  
  suppressWarnings(as.numeric(value))
}

# =====================================================================
# 4. 定义各队列波次及调查年份
# =====================================================================

get_wave_info <- function(data_source) {
  
  data_source <- as.integer(data_source)
  
  switch(
    as.character(data_source),
    "1" = list(
      country = "CHARLS",
      max_wave = 5L,
      wave_years = c(2011, 2013, 2015, 2018, 2020)
    ),
    "2" = list(
      country = "HRS",
      max_wave = 6L,
      wave_years = c(2012, 2014, 2016, 2018, 2020, 2022)
    ),
    "3" = list(
      country = "SHARE",
      max_wave = 5L,
      wave_years = c(2013, 2015, 2017, 2020, 2022)
    ),
    "4" = list(
      country = "ELSA",
      max_wave = 5L,
      wave_years = c(2015, 2017, 2020, 2022, 2024)
    ),
    NULL
  )
}

# =====================================================================
# 5. 检查某一波次基线所需变量是否完整存在于数据框中
# =====================================================================

check_wave_columns <- function(data, wave) {
  
  required_wave_vars <- c(
    paste0("r", wave, "both"),
    paste0("r", wave, "phyactivities"),
    paste0("r", wave, "netuse"),
    paste0("r", wave, "dementia"),
    paste0("r", wave, "mstat"),
    paste0("r", wave, "scocwk"),
    paste0("r", wave, "smoking"),
    paste0("r", wave, "Non_com_dis"),
    paste0("r", wave, "drink")
  )
  
  all(required_wave_vars %in% names(data))
}

# =====================================================================
# 6. 提取某一研究对象某一波次的基线变量
# =====================================================================

get_baseline_variables <- function(data, i, wave) {
  
  list(
    both = safe_get_value(data, i, paste0("r", wave, "both")),
    phyactivities = safe_get_value(data, i, paste0("r", wave, "phyactivities")),
    netuse = safe_get_value(data, i, paste0("r", wave, "netuse")),
    dementia = safe_get_value(data, i, paste0("r", wave, "dementia")),
    mstat = safe_get_value(data, i, paste0("r", wave, "mstat")),
    scocwk = safe_get_value(data, i, paste0("r", wave, "scocwk")),
    smoking = safe_get_value(data, i, paste0("r", wave, "smoking")),
    Non_com_dis = safe_get_value(data, i, paste0("r", wave, "Non_com_dis")),
    drink = safe_get_value(data, i, paste0("r", wave, "drink"))
  )
}

# =====================================================================
# 7. 判断基线后是否至少存在一波有效痴呆随访数据
# =====================================================================

has_followup_dementia_data <- function(data, i, enrollment_wave, max_wave) {
  
  if (is.na(enrollment_wave) || enrollment_wave >= max_wave) {
    return(FALSE)
  }
  
  future_waves <- seq.int(enrollment_wave + 1L, max_wave)
  
  future_dementia <- vapply(
    future_waves,
    function(wave) safe_get_value(data, i, paste0("r", wave, "dementia")),
    numeric(1)
  )
  
  any(!is.na(future_dementia))
}

# =====================================================================
# 8. 动态基线样本筛选
# =====================================================================

filter_data_by_conditions_modified <- function(data) {
  
  data <- data %>%
    mutate(
      enrollment_wave = NA_integer_,
      screening_status = NA_character_,
      country = case_when(
        data_source == 1 ~ "CHARLS",
        data_source == 2 ~ "HRS",
        data_source == 3 ~ "SHARE",
        data_source == 4 ~ "ELSA",
        TRUE ~ "Unknown"
      )
    )
  
  for (i in seq_len(nrow(data))) {
    
    source_i <- safe_get_value(data, i, "data_source")
    wave_info <- get_wave_info(source_i)
    
    # 排除未知数据来源
    if (is.null(wave_info)) {
      data$screening_status[i] <- "排除：未知数据来源"
      next
    }
    
    # 年龄限制
    if (is.na(data$age[i]) || data$age[i] < 50) {
      data$screening_status[i] <- "排除：年龄<50岁或年龄缺失"
      next
    }
    
    max_wave_i <- wave_info$max_wave
    
    has_any_core_baseline <- FALSE
    has_non_dementia_baseline <- FALSE
    has_complete_covariate_baseline <- FALSE
    has_followup_data <- FALSE
    enrollment_found <- FALSE
    
    # 最后一波之后没有随访，不能作为基线
    for (wave in seq_len(max_wave_i - 1L)) {
      
      # 该波次变量不完整时跳过
      if (!check_wave_columns(data, wave)) {
        next
      }
      
      baseline_var <- get_baseline_variables(data, i, wave)
      
      # 核心暴露变量：共病、体力活动、互联网使用
      core_exposure_vars <- c(
        baseline_var$both,
        baseline_var$phyactivities,
        baseline_var$netuse
      )
      
      if (any(is.na(core_exposure_vars))) {
        next
      }
      
      has_any_core_baseline <- TRUE
      
      # 基线痴呆状态必须已知且为无痴呆
      if (is.na(baseline_var$dementia) || baseline_var$dementia == 1) {
        next
      }
      
      has_non_dementia_baseline <- TRUE
      
      # 检查所有协变量是否完整
      all_baseline_vars <- c(
        baseline_var$both,
        baseline_var$phyactivities,
        baseline_var$netuse,
        baseline_var$dementia,
        baseline_var$mstat,
        baseline_var$scocwk,
        baseline_var$smoking,
        baseline_var$Non_com_dis,
        baseline_var$drink,
        data$yearsold[i],
        data$raeduc_c[i],
        data$ragender[i]
      )
      
      if (any(is.na(all_baseline_vars))) {
        next
      }
      
      has_complete_covariate_baseline <- TRUE
      
      # 检查基线之后是否有有效的痴呆随访
      if (!has_followup_dementia_data(data, i, wave, max_wave_i)) {
        next
      }
      
      has_followup_data <- TRUE
      
      # 使用最早符合条件的波次作为动态基线
      data$enrollment_wave[i] <- wave
      data$screening_status[i] <- "纳入最终分析"
      enrollment_found <- TRUE
      
      break
    }
    
    # 记录互不重复的排除原因
    if (!enrollment_found) {
      if (!has_any_core_baseline) {
        data$screening_status[i] <- "排除：基线共病/体力活动/互联网使用信息缺失"
      } else if (!has_non_dementia_baseline) {
        data$screening_status[i] <- "排除：基线痴呆或阿尔茨海默病"
      } else if (!has_complete_covariate_baseline) {
        data$screening_status[i] <- "排除：基线痴呆或协变量数据缺失"
      } else if (!has_followup_data) {
        data$screening_status[i] <- "排除：Wave 1至Wave 5/6随访痴呆数据缺失"
      } else {
        data$screening_status[i] <- "排除：其他原因"
      }
    }
  }
  
  data
}

# =====================================================================
# 9. 运行样本筛选
# =====================================================================

screened_data <- filter_data_by_conditions_modified(total_data)

data_In <- screened_data %>%
  filter(screening_status == "纳入最终分析")

# =====================================================================
# 10. 提取动态基线协变量、随访时间与初步事件状态
# =====================================================================

extract_baseline_covs_fixed <- function(data) {
  
  baseline_vars <- c(
    "baseline_both",
    "baseline_dementia_status",
    "baseline_phyactivities",
    "baseline_netuse",
    "baseline_mstat",
    "baseline_scocwk",
    "baseline_smoking",
    "baseline_drink",
    "baseline_Non_com_dis",
    "baseline_year",
    "last_followup_year",
    "time_to_event",
    "event_status"
  )
  
  data[baseline_vars] <- NA_real_
  
  for (i in seq_len(nrow(data))) {
    
    source_i <- safe_get_value(data, i, "data_source")
    wave_i <- safe_get_value(data, i, "enrollment_wave")
    wave_info <- get_wave_info(source_i)
    
    if (is.null(wave_info) || is.na(wave_i)) {
      next
    }
    
    wave_i <- as.integer(wave_i)
    max_wave_i <- wave_info$max_wave
    wave_years_i <- wave_info$wave_years
    baseline_year_i <- wave_years_i[wave_i]
    
    # 提取动态基线协变量
    data$baseline_both[i] <- safe_get_value(data, i, paste0("r", wave_i, "both"))
    data$baseline_dementia_status[i] <- safe_get_value(data, i, paste0("r", wave_i, "dementia"))
    data$baseline_phyactivities[i] <- safe_get_value(data, i, paste0("r", wave_i, "phyactivities"))
    data$baseline_netuse[i] <- safe_get_value(data, i, paste0("r", wave_i, "netuse"))
    data$baseline_mstat[i] <- safe_get_value(data, i, paste0("r", wave_i, "mstat"))
    data$baseline_scocwk[i] <- safe_get_value(data, i, paste0("r", wave_i, "scocwk"))
    data$baseline_smoking[i] <- safe_get_value(data, i, paste0("r", wave_i, "smoking"))
    data$baseline_drink[i] <- safe_get_value(data, i, paste0("r", wave_i, "drink"))
    data$baseline_Non_com_dis[i] <- safe_get_value(data, i, paste0("r", wave_i, "Non_com_dis"))
    data$baseline_year[i] <- baseline_year_i
    
    onset_year <- NA_real_
    last_followup_year_i <- baseline_year_i
    event_i <- 0L
    
    future_waves <- seq.int(wave_i + 1L, max_wave_i)
    
    for (future_wave in future_waves) {
      
      dementia_i <- safe_get_value(data, i, paste0("r", future_wave, "dementia"))
      current_year_i <- wave_years_i[future_wave]
      
      # 非缺失痴呆状态视为有效随访
      if (!is.na(dementia_i)) {
        
        last_followup_year_i <- current_year_i
        
        # 第一次观察到痴呆事件
        if (dementia_i == 1 && is.na(onset_year)) {
          onset_year <- current_year_i
          event_i <- 1L
          break
        }
      }
    }
    
    data$last_followup_year[i] <- last_followup_year_i
    data$event_status[i] <- event_i
    
    if (event_i == 1L) {
      data$time_to_event[i] <- onset_year - baseline_year_i
    } else {
      data$time_to_event[i] <- last_followup_year_i - baseline_year_i
    }
  }
  
  data %>%
    select(
      record_id,
      ID,
      country,
      data_source,
      enrollment_wave,
      baseline_year,
      last_followup_year,
      yearsold,
      age,
      raeduc_c,
      ragender,
      baseline_both,
      baseline_dementia_status,
      baseline_phyactivities,
      baseline_netuse,
      baseline_mstat,
      baseline_scocwk,
      baseline_smoking,
      baseline_drink,
      baseline_Non_com_dis,
      time_to_event,
      event_status,
      any_of(death_vars)
    ) %>%
    filter(
      baseline_dementia_status == 0,
      !is.na(baseline_both),
      !is.na(yearsold),
      !is.na(age),
      !is.na(raeduc_c),
      !is.na(ragender),
      !is.na(baseline_phyactivities),
      !is.na(baseline_netuse),
      !is.na(baseline_mstat),
      !is.na(baseline_scocwk),
      !is.na(baseline_smoking),
      !is.na(baseline_drink),
      !is.na(baseline_Non_com_dis),
      !is.na(time_to_event),
      time_to_event > 0
    ) %>%
    mutate(
      country = factor(country, levels = c("CHARLS", "HRS", "SHARE", "ELSA")),
      
      raeduc_c = factor(
        raeduc_c,
        levels = c(1, 2, 3),
        labels = c("初中及以下", "高中", "大学及以上")
      ),
      
      yearsold = factor(
        yearsold,
        levels = c(1, 2, 3, 4),
        labels = c("60岁以下", "60-69岁", "70-79岁", "80岁及以上")
      ),
      
      ragender = factor(
        ragender,
        levels = c(1, 2),
        labels = c("男", "女")
      ),
      
      baseline_both = factor(
        baseline_both,
        levels = c(0, 1),
        labels = c("无共病", "仅共病")
      ),
      
      baseline_phyactivities = factor(
        baseline_phyactivities,
        levels = c(0, 1),
        labels = c("不活跃", "活跃")
      ),
      
      baseline_netuse = factor(
        baseline_netuse,
        levels = c(0, 1),
        labels = c("不使用", "使用")
      ),
      
      baseline_mstat = factor(
        baseline_mstat,
        levels = c(1, 2),
        labels = c("已婚/同居", "单身")
      ),
      
      baseline_scocwk = factor(
        baseline_scocwk,
        levels = c(0, 1),
        labels = c("不活跃", "活跃")
      ),
      
      baseline_smoking = factor(
        baseline_smoking,
        levels = c(0, 1, 2),
        labels = c("戒烟", "吸烟", "从未吸烟")
      ),
      
      baseline_drink = factor(
        baseline_drink,
        levels = c(0, 1),
        labels = c("从未饮酒", "饮过酒")
      ),
      
      baseline_Non_com_dis = factor(
        baseline_Non_com_dis,
        levels = c(0, 1),
        labels = c("无", "有")
      )
    )
}

# =====================================================================
# 11. 校正痴呆事件状态及随访时间
# =====================================================================
#
# 校正规则：
# 若第一次观察到痴呆=1，且下一次有效痴呆观测值=0，
# 则将该痴呆事件视为不成立，并将随访时间改为最后有效随访时间。
# =====================================================================

correct_event_status <- function(data, origin_data) {
  
  dem_vars <- paste0("r", 1:6, "dementia")
  existing_dem_vars <- intersect(dem_vars, names(origin_data))
  
  origin_data_sub <- origin_data %>%
    select(record_id, any_of(existing_dem_vars))
  
  if (anyDuplicated(origin_data_sub$record_id) > 0) {
    stop("record_id 在原始数据中不唯一。")
  }
  
  if (anyDuplicated(data$record_id) > 0) {
    stop("record_id 在 Cox 分析数据中不唯一。")
  }
  
  data_correct <- data %>%
    left_join(origin_data_sub, by = "record_id")
  
  for (i in seq_len(nrow(data_correct))) {
    
    wave_i <- safe_get_value(data_correct, i, "enrollment_wave")
    source_i <- safe_get_value(data_correct, i, "data_source")
    wave_info <- get_wave_info(source_i)
    
    if (is.null(wave_info) || is.na(wave_i)) {
      data_correct$event_status[i] <- 0L
      data_correct$time_to_event[i] <- NA_real_
      next
    }
    
    wave_i <- as.integer(wave_i)
    max_wave_i <- wave_info$max_wave
    wave_years_i <- wave_info$wave_years
    baseline_year_i <- wave_years_i[wave_i]
    
    if (wave_i >= max_wave_i) {
      data_correct$event_status[i] <- 0L
      data_correct$time_to_event[i] <- NA_real_
      next
    }
    
    future_waves <- seq.int(wave_i + 1L, max_wave_i)
    
    future_dem <- vapply(
      future_waves,
      function(wave) {
        safe_get_value(data_correct, i, paste0("r", wave, "dementia"))
      },
      numeric(1)
    )
    
    valid_index <- which(!is.na(future_dem))
    
    # 无有效后续随访数据时移除
    if (length(valid_index) == 0) {
      data_correct$event_status[i] <- 0L
      data_correct$time_to_event[i] <- NA_real_
      next
    }
    
    valid_dem <- future_dem[valid_index]
    valid_waves <- future_waves[valid_index]
    
    last_followup_wave <- tail(valid_waves, 1)
    last_followup_year_i <- wave_years_i[last_followup_wave]
    
    data_correct$last_followup_year[i] <- last_followup_year_i
    
    real_event <- 0L
    onset_year_i <- NA_real_
    
    first_positive_position <- which(valid_dem == 1)[1]
    
    if (!is.na(first_positive_position)) {
      
      first_positive_wave <- valid_waves[first_positive_position]
      first_positive_year <- wave_years_i[first_positive_wave]
      
      # 首次阳性不是最后一次有效观察时，检查其下一次有效观察
      if (first_positive_position < length(valid_dem)) {
        
        next_valid_dementia <- valid_dem[first_positive_position + 1L]
        
        if (next_valid_dementia != 0) {
          real_event <- 1L
          onset_year_i <- first_positive_year
        }
        
      } else {
        # 首次阳性为最后一次有效观察时，判定为事件
        real_event <- 1L
        onset_year_i <- first_positive_year
      }
    }
    
    data_correct$event_status[i] <- real_event
    
    if (real_event == 1L) {
      data_correct$time_to_event[i] <- onset_year_i - baseline_year_i
    } else {
      data_correct$time_to_event[i] <- last_followup_year_i - baseline_year_i
    }
  }
  
  data_correct %>%
    select(-any_of(existing_dem_vars)) %>%
    filter(
      !is.na(time_to_event),
      time_to_event > 0
    )
}

# =====================================================================
# 12. 构建最终 Cox 分析数据
# =====================================================================

cox_data_clean <- extract_baseline_covs_fixed(data_In)

cox_data_final <- correct_event_status(
  data = cox_data_clean,
  origin_data = data_In
)

# =====================================================================
# 13. 流程图与最终样本量统计
# =====================================================================

n_all_participants <- nrow(total_data)

flow_order <- c(
  "纳入最终分析",
  "排除：年龄<50岁或年龄缺失",
  "排除：基线共病/体力活动/互联网使用信息缺失",
  "排除：基线痴呆或阿尔茨海默病",
  "排除：基线痴呆或协变量数据缺失",
  "排除：Wave 1至Wave 5/6随访痴呆数据缺失",
  "排除：其他原因",
  "排除：未知数据来源"
)

flow_table <- screened_data %>%
  count(screening_status, name = "N") %>%
  mutate(
    percent_of_total = round(N / n_all_participants * 100, 2),
    screening_status = factor(screening_status, levels = flow_order)
  ) %>%
  arrange(screening_status)

flow_by_country <- screened_data %>%
  mutate(screening_status = factor(screening_status, levels = flow_order)) %>%
  group_by(country, screening_status) %>%
  summarise(N = n(), .groups = "drop") %>%
  tidyr::pivot_wider(
    names_from = screening_status,
    values_from = N,
    values_fill = 0
  )

n_after_screening <- nrow(data_In)
n_final_analysis <- nrow(cox_data_final)
n_removed_after_event_correction <- n_after_screening - n_final_analysis

analysis_sample_by_country <- cox_data_final %>%
  group_by(country) %>%
  summarise(
    N = n(),
    dementia_events = sum(event_status == 1, na.rm = TRUE),
    non_events = sum(event_status == 0, na.rm = TRUE),
    mean_followup_years = mean(time_to_event, na.rm = TRUE),
    median_followup_years = median(time_to_event, na.rm = TRUE),
    .groups = "drop"
  ) %>%
  mutate(country = as.character(country))

overall_followup <- cox_data_final %>%
  summarise(
    country = "总体（四国合并）",
    N = n(),
    dementia_events = sum(event_status == 1, na.rm = TRUE),
    non_events = sum(event_status == 0, na.rm = TRUE),
    mean_followup_years = mean(time_to_event, na.rm = TRUE),
    median_followup_years = median(time_to_event, na.rm = TRUE)
  )

analysis_sample_with_overall <- bind_rows(
  analysis_sample_by_country,
  overall_followup
)

cat("\n====================================================\n")
cat("流程图样本量结果\n")
cat("====================================================\n")
cat("\n所有参与者总数：", n_all_participants, "\n")
print(flow_table)

cat("\n动态基线筛选后样本量：", n_after_screening, "\n")
cat("结局校正后最终分析样本量：", n_final_analysis, "\n")
cat("结局校正后移除人数：", n_removed_after_event_correction, "\n")

cat("\n====================================================\n")
cat("各国家样本筛选情况\n")
cat("====================================================\n")
print(flow_by_country)

cat("\n====================================================\n")
cat("最终分析样本量、痴呆事件数及随访时间\n")
cat("====================================================\n")
print(analysis_sample_with_overall)

# =====================================================================
# 14. 定义 Cox 模型公式
# =====================================================================
#
# 此模型公式同时用于：
# 1. 各国 Cox 回归主分析；
# 2. Schoenfeld 残差比例风险假设检验。
# =====================================================================

cox_model_formula <- Surv(time_to_event, event_status) ~
  baseline_both +
  yearsold +
  ragender +
  raeduc_c +
  baseline_phyactivities +
  baseline_netuse +
  baseline_mstat +
  baseline_scocwk +
  baseline_smoking +
  baseline_drink +
  baseline_Non_com_dis

# =====================================================================
# 15. 各国家 Cox 回归函数
# =====================================================================

empty_cox_result <- function(country_name, n_total, n_events) {
  tibble(
    country = country_name,
    N = n_total,
    events = n_events,
    HR = NA_real_,
    CI_lower = NA_real_,
    CI_upper = NA_real_,
    p_value = NA_real_,
    logHR = NA_real_,
    se_logHR = NA_real_
  )
}

run_cox_by_country <- function(dt, country_name) {
  
  n_total <- nrow(dt)
  n_events <- sum(dt$event_status == 1, na.rm = TRUE)
  
  # 无样本或无事件时 Cox 模型无法估计
  if (n_total == 0 || n_events == 0) {
    return(empty_cox_result(country_name, n_total, n_events))
  }
  
  # 删除无观测水平的因子水平，避免模型矩阵错误
  dt <- droplevels(dt)
  
  cox_model <- tryCatch(
    coxph(
      formula = cox_model_formula,
      data = dt,
      x = TRUE
    ),
    error = function(e) NULL
  )
  
  if (is.null(cox_model)) {
    return(empty_cox_result(country_name, n_total, n_events))
  }
  
  cox_result <- broom::tidy(
    cox_model,
    conf.int = TRUE,
    exponentiate = TRUE
  )
  
  # 自动识别 baseline_both 的非参考组结果
  exposure_result <- cox_result %>%
    filter(grepl("^baseline_both", term))
  
  # 暴露变量无有效估计结果时返回空值
  if (nrow(exposure_result) != 1 ||
      is.na(exposure_result$estimate) ||
      is.na(exposure_result$conf.low) ||
      is.na(exposure_result$conf.high)) {
    return(empty_cox_result(country_name, n_total, n_events))
  }
  
  exposure_result %>%
    transmute(
      country = country_name,
      N = n_total,
      events = n_events,
      HR = estimate,
      CI_lower = conf.low,
      CI_upper = conf.high,
      p_value = p.value,
      logHR = log(estimate),
      se_logHR = (log(conf.high) - log(conf.low)) / (2 * qnorm(0.975))
    )
}

# =====================================================================
# 16. 按国家进行 Cox 回归
# =====================================================================

country_CHARLS <- cox_data_final %>% filter(country == "CHARLS")
country_HRS <- cox_data_final %>% filter(country == "HRS")
country_SHARE <- cox_data_final %>% filter(country == "SHARE")
country_ELSA <- cox_data_final %>% filter(country == "ELSA")

all_res <- bind_rows(
  run_cox_by_country(country_CHARLS, "CHARLS"),
  run_cox_by_country(country_HRS, "HRS"),
  run_cox_by_country(country_SHARE, "SHARE"),
  run_cox_by_country(country_ELSA, "ELSA")
)

all_res_display <- all_res %>%
  mutate(
    HR_95CI = case_when(
      is.na(HR) ~ NA_character_,
      TRUE ~ sprintf("%.3f (%.3f–%.3f)", HR, CI_lower, CI_upper)
    ),
    p_display = case_when(
      is.na(p_value) ~ NA_character_,
      p_value < 0.001 ~ "<0.001",
      TRUE ~ sprintf("%.3f", p_value)
    )
  ) %>%
  select(
    country,
    N,
    events,
    HR,
    CI_lower,
    CI_upper,
    HR_95CI,
    p_value,
    p_display,
    logHR,
    se_logHR
  )

cat("\n====================================================\n")
cat("四个国家多变量 Cox 回归结果\n")
cat("暴露变量：仅共病 vs 无共病\n")
cat("====================================================\n")
print(all_res_display, digits = 4)

# =====================================================================
# 17. Schoenfeld 残差比例风险假设检验
# =====================================================================
#
# 使用 survival::cox.zph() 对 Cox 模型进行检验。
#
# 原假设：协变量效应不随时间变化，即满足比例风险假设。
# p >= 0.05：未发现违反比例风险假设的证据。
# p < 0.05 ：提示可能违反比例风险假设。
#
# GLOBAL 行表示整个 Cox 模型的总体比例风险假设检验结果。
# =====================================================================

empty_ph_result <- function(country_name, message) {
  tibble(
    country = country_name,
    variable = NA_character_,
    rho = NA_real_,
    chisq = NA_real_,
    p_value = NA_real_,
    ph_assumption = message
  )
}

test_ph_assumption_by_country <- function(dt, country_name) {
  
  n_total <- nrow(dt)
  n_events <- sum(dt$event_status == 1, na.rm = TRUE)
  
  # Cox 模型及 Schoenfeld 残差检验均至少需要一个事件
  if (n_total == 0 || n_events == 0) {
    return(
      empty_ph_result(
        country_name,
        "无法检验：无样本或无痴呆事件"
      )
    )
  }
  
  dt <- droplevels(dt)
  
  # 拟合与主分析一致的 Cox 模型
  cox_model <- tryCatch(
    coxph(
      formula = cox_model_formula,
      data = dt,
      x = TRUE
    ),
    error = function(e) NULL
  )
  
  if (is.null(cox_model)) {
    return(
      empty_ph_result(
        country_name,
        "无法检验：Cox 模型拟合失败"
      )
    )
  }
  
  # 基于 Schoenfeld 残差检验比例风险假设
  ph_test <- tryCatch(
    cox.zph(cox_model, transform = "km"),
    error = function(e) NULL
  )
  
  if (is.null(ph_test)) {
    return(
      empty_ph_result(
        country_name,
        "无法检验：Schoenfeld 残差计算失败"
      )
    )
  }
  
  # cox.zph() 输出矩阵通常包含 rho、chisq、p 三列
  ph_table <- as.data.frame(ph_test$table) %>%
    tibble::rownames_to_column(var = "variable")
  
  # 兼容不同 survival 版本的列名
  if (!"rho" %in% names(ph_table)) {
    ph_table$rho <- NA_real_
  }
  
  if (!"chisq" %in% names(ph_table)) {
    ph_table$chisq <- NA_real_
  }
  
  if (!"p" %in% names(ph_table)) {
    ph_table$p <- NA_real_
  }
  
  ph_table %>%
    transmute(
      country = country_name,
      variable = variable,
      rho = rho,
      chisq = chisq,
      p_value = p,
      ph_assumption = case_when(
        is.na(p_value) ~ "无法判断",
        variable == "GLOBAL" & p_value >= 0.05 ~
          "整体模型满足比例风险假设",
        variable == "GLOBAL" & p_value < 0.05 ~
          "整体模型可能违反比例风险假设",
        p_value >= 0.05 ~
          "未发现违反比例风险假设的证据",
        p_value < 0.05 ~
          "可能违反比例风险假设"
      )
    )
}

# 分国家执行 Schoenfeld 残差检验
ph_assumption_results <- bind_rows(
  test_ph_assumption_by_country(country_CHARLS, "CHARLS"),
  test_ph_assumption_by_country(country_HRS, "HRS"),
  test_ph_assumption_by_country(country_SHARE, "SHARE"),
  test_ph_assumption_by_country(country_ELSA, "ELSA")
) %>%
  mutate(
    p_display = case_when(
      is.na(p_value) ~ NA_character_,
      p_value < 0.001 ~ "<0.001",
      TRUE ~ sprintf("%.3f", p_value)
    )
  )

# 提取整体模型比例风险假设检验结果
ph_global_results <- ph_assumption_results %>%
  filter(variable == "GLOBAL") %>%
  select(
    country,
    rho,
    chisq,
    p_value,
    p_display,
    ph_assumption
  )

cat("\n====================================================\n")
cat("Schoenfeld 残差比例风险假设检验结果\n")
cat("====================================================\n")
print(ph_assumption_results, digits = 4)

cat("\n====================================================\n")
cat("各国 Cox 模型整体比例风险假设检验结果（GLOBAL）\n")
cat("====================================================\n")
print(ph_global_results, digits = 4)

# =====================================================================
# 18. 四国随机效应 Meta 分析
# =====================================================================

meta_dat <- all_res %>%
  filter(
    !is.na(logHR),
    !is.na(se_logHR),
    is.finite(logHR),
    is.finite(se_logHR),
    se_logHR > 0
  )

if (nrow(meta_dat) < 2) {
  stop("可用于 Meta 分析的国家少于 2 个，无法进行 Meta 分析。")
}

m_random <- metagen(
  TE = logHR,
  seTE = se_logHR,
  studlab = country,
  data = meta_dat,
  sm = "HR",
  common = FALSE,
  random = TRUE,
  method.tau = "REML",
  hakn = FALSE,
  title = "共病与痴呆风险：四国随机效应 Meta 分析"
)

# =====================================================================
# 19. 提取随机效应 Meta 分析结果
# =====================================================================

meta_result <- tibble(
  model = "随机效应模型（REML）",
  countries_included = nrow(meta_dat),
  
  pooled_HR = exp(m_random$TE.random),
  pooled_CI_lower = exp(m_random$lower.random),
  pooled_CI_upper = exp(m_random$upper.random),
  pooled_p_value = m_random$pval.random,
  
  Q = m_random$Q,
  df_Q = m_random$df.Q,
  p_heterogeneity = m_random$pval.Q,
  
  I2 = m_random$I2,
  I2_percent = m_random$I2 * 100,
  
  tau = m_random$tau,
  tau2 = m_random$tau^2
) %>%
  mutate(
    pooled_HR_95CI = sprintf(
      "%.3f (%.3f–%.3f)",
      pooled_HR,
      pooled_CI_lower,
      pooled_CI_upper
    ),
    
    pooled_p_display = case_when(
      is.na(pooled_p_value) ~ NA_character_,
      pooled_p_value < 0.001 ~ "<0.001",
      TRUE ~ sprintf("%.3f", pooled_p_value)
    ),
    
    heterogeneity_p_display = case_when(
      is.na(p_heterogeneity) ~ NA_character_,
      p_heterogeneity < 0.001 ~ "<0.001",
      TRUE ~ sprintf("%.3f", p_heterogeneity)
    ),
    
    I2_display = paste0(round(I2_percent, 1), "%")
  )

cat("\n====================================================\n")
cat("四国随机效应 Meta 分析结果\n")
cat("====================================================\n")
print(meta_result, digits = 4)

cat("\n====================================================\n")
cat("Meta 分析完整输出\n")
cat("====================================================\n")
print(m_random, digits = 4)

cat("\n---------------- 随机效应模型汇总 ----------------\n")
cat("合并 HR =", round(meta_result$pooled_HR, 3), "\n")
cat(
  "95% CI =",
  round(meta_result$pooled_CI_lower, 3),
  "~",
  round(meta_result$pooled_CI_upper, 3),
  "\n"
)
cat("合并效应 P 值 =", meta_result$pooled_p_display, "\n")
cat("Cochran Q =", round(meta_result$Q, 3), "\n")
cat("异质性自由度(df) =", meta_result$df_Q, "\n")
cat("异质性 P 值 =", meta_result$heterogeneity_p_display, "\n")
cat("I² =", meta_result$I2_display, "\n")
cat("Tau =", round(meta_result$tau, 4), "\n")
cat("Tau² =", round(meta_result$tau2, 4), "\n")

# =====================================================================
# 20. 导出结果文件
# =====================================================================

readr::write_excel_csv(
  flow_table,
  file = "表1_总体流程图样本量_共病.csv"
)

readr::write_excel_csv(
  flow_by_country,
  file = "表2_各国流程图样本量_共病.csv"
)

readr::write_excel_csv(
  analysis_sample_with_overall,
  file = "表3_各国及四国合并最终分析样本量事件数及随访时间_共病.csv"
)

readr::write_excel_csv(
  all_res_display,
  file = "表4_各国Cox回归结果_共病.csv"
)

readr::write_excel_csv(
  meta_result,
  file = "表5_随机效应Meta分析结果_共病.csv"
)

# 各协变量及整体模型的 Schoenfeld 残差检验结果
readr::write_excel_csv(
  ph_assumption_results,
  file = "表6_各国Cox模型比例风险假设检验_Schoenfeld残差-共病.csv"
)

# 仅导出各国家整体模型（GLOBAL）比例风险假设检验结果
readr::write_excel_csv(
  ph_global_results,
  file = "表7_各国Cox模型整体比例风险假设检验_GLOBAL-共病.csv"
)

readr::write_excel_csv(
  cox_data_final,
  file = "最终Cox分析数据_共病.csv"
)