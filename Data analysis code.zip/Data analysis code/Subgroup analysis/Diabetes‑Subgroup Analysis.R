# =====================================================================
# 糖尿病（排除基线高血压）与痴呆风险亚组分析
# 动态基线筛选、结局校正、分国家 Cox 与随机效应 Meta
#
# 分析定义：
# 1. 动态基线时 rXonlydiabe == 1 且 rXhypertension == 0：
#    归为"糖尿病且无高血压"组；
# 2. 动态基线时 rXonlydiabe == 0 且 rXhypertension == 0：
#    归为"无糖尿病且无高血压"对照组；
# 3. 动态基线高血压为 1 者排除；
# 4. 动态基线高血压状态缺失者排除；
# 5. 其他动态基线筛选、痴呆事件判定、Cox 调整变量、
#    随机效应 Meta 分析均与主分析保持一致。
#
# 代码逻辑结构：
# 1. 读取原始数据并进行变量检查
# 2. 按排除基线高血压规则进行动态基线筛选
# 3. 提取动态基线协变量、随访时间和痴呆事件
# 4. 校正痴呆事件状态，生成 cox_data_final
# 5. 基于 cox_data_final 开展分国家亚组 Cox 回归
# 6. 对各亚组水平进行四国随机效应 Meta 分析
# 7. 异质性来源与 CHARLS 估计稳定性辅助分析
# 8. 导出中文 CSV 文件
# =====================================================================

# =====================================================================
# 0. 环境设置与加载包
# =====================================================================
setwd("E:/csl/CSL/database")
library(dplyr)
library(tidyr)
library(haven)
library(survival)
library(broom)
library(meta)
library(metafor)
library(readr)
select <- dplyr::select

# =====================================================================
# 1. 读取数据及基础变量检查
# =====================================================================
total_data <- read_dta("onlydiabe_data_new.dta") %>%
  mutate(record_id = row_number())

required_basic_vars <- c(
  "ID", "data_source", "yearsold", "age", "raeduc_c", "ragender"
)
missing_basic_vars <- setdiff(required_basic_vars, names(total_data))
if (length(missing_basic_vars) > 0) {
  stop(
    "数据中缺少以下必要变量：",
    paste(missing_basic_vars, collapse = ", ")
  )
}

# =====================================================================
# 2. 安全取值函数与队列波次信息
# =====================================================================
safe_get_value <- function(data, row_idx, var_name) {
  
  if (!var_name %in% names(data)) {
    return(NA_real_)
  }
  
  value <- data[[var_name]][row_idx]
  
  if (length(value) == 0 || is.null(value) || is.na(value)) {
    return(NA_real_)
  }
  
  suppressWarnings(as.numeric(value))
}

get_wave_info <- function(data_source) {
  
  data_source <- suppressWarnings(as.integer(data_source))
  
  switch(
    as.character(data_source),
    
    "1" = list(
      country = "CHARLS",
      max_wave = 5L,
      wave_years = c(2011, 2013, 2015, 2018, 2020)
    ),
    
    "2" = list(
      country = "HRS",
      max_wave = 6L,
      wave_years = c(2012, 2014, 2016, 2018, 2020, 2022)
    ),
    
    "3" = list(
      country = "SHARE",
      max_wave = 5L,
      wave_years = c(2013, 2015, 2017, 2020, 2022)
    ),
    
    "4" = list(
      country = "ELSA",
      max_wave = 5L,
      wave_years = c(2015, 2017, 2020, 2022, 2024)
    ),
    
    NULL
  )
}

# =====================================================================
# 3. 动态基线筛选所需函数
# =====================================================================
check_wave_columns <- function(data, wave) {
  
  required_wave_vars <- c(
    paste0("r", wave, "onlydiabe"),
    paste0("r", wave, "hypertension"),
    paste0("r", wave, "phyactivities"),
    paste0("r", wave, "netuse"),
    paste0("r", wave, "dementia"),
    paste0("r", wave, "mstat"),
    paste0("r", wave, "scocwk"),
    paste0("r", wave, "smoking"),
    paste0("r", wave, "Non_com_dis"),
    paste0("r", wave, "drink")
  )
  
  all(required_wave_vars %in% names(data))
}

get_baseline_variables <- function(data, i, wave) {
  
  list(
    onlydiabe = safe_get_value(data, i, paste0("r", wave, "onlydiabe")),
    hypertension = safe_get_value(data, i, paste0("r", wave, "hypertension")),
    phyactivities = safe_get_value(data, i, paste0("r", wave, "phyactivities")),
    netuse = safe_get_value(data, i, paste0("r", wave, "netuse")),
    dementia = safe_get_value(data, i, paste0("r", wave, "dementia")),
    mstat = safe_get_value(data, i, paste0("r", wave, "mstat")),
    scocwk = safe_get_value(data, i, paste0("r", wave, "scocwk")),
    smoking = safe_get_value(data, i, paste0("r", wave, "smoking")),
    Non_com_dis = safe_get_value(data, i, paste0("r", wave, "Non_com_dis")),
    drink = safe_get_value(data, i, paste0("r", wave, "drink"))
  )
}

has_followup_dementia_data <- function(data, i, enrollment_wave, max_wave) {
  
  if (is.na(enrollment_wave) || enrollment_wave >= max_wave) {
    return(FALSE)
  }
  
  future_waves <- seq.int(enrollment_wave + 1L, max_wave)
  
  future_dementia <- vapply(
    future_waves,
    function(wave) {
      safe_get_value(data, i, paste0("r", wave, "dementia"))
    },
    numeric(1)
  )
  
  any(!is.na(future_dementia))
}

# =====================================================================
# 4. 动态基线样本筛选（排除基线高血压）
#
# 仅纳入：
# - 无高血压：rXhypertension == 0；
# - 糖尿病组：rXonlydiabe == 1；
# - 对照组：rXonlydiabe == 0。
# =====================================================================
filter_sensitivity_analysis_data <- function(data) {
  
  data <- data %>%
    mutate(
      enrollment_wave = NA_integer_,
      screening_status = NA_character_,
      country = case_when(
        data_source == 1 ~ "CHARLS",
        data_source == 2 ~ "HRS",
        data_source == 3 ~ "SHARE",
        data_source == 4 ~ "ELSA",
        TRUE ~ "Unknown"
      )
    )
  
  for (i in seq_len(nrow(data))) {
    
    source_i <- safe_get_value(data, i, "data_source")
    wave_info <- get_wave_info(source_i)
    
    if (is.null(wave_info)) {
      data$screening_status[i] <- "排除：未知数据来源"
      next
    }
    
    if (is.na(data$age[i]) || data$age[i] < 50) {
      data$screening_status[i] <- "排除：年龄<50岁或年龄缺失"
      next
    }
    
    max_wave_i <- wave_info$max_wave
    
    has_exposure_hypertension_data <- FALSE
    has_no_hypertension_baseline <- FALSE
    has_non_dementia_baseline <- FALSE
    has_complete_covariate_baseline <- FALSE
    has_followup_data <- FALSE
    enrollment_found <- FALSE
    
    # 最后一波没有后续随访，不能作为基线
    for (wave in seq_len(max_wave_i - 1L)) {
      
      if (!check_wave_columns(data, wave)) {
        next
      }
      
      baseline_var <- get_baseline_variables(data, i, wave)
      
      # 糖尿病及高血压状态必须已知
      if (is.na(baseline_var$onlydiabe) || is.na(baseline_var$hypertension)) {
        next
      }
      
      # onlydiabe 仅允许为 0 或 1
      if (!baseline_var$onlydiabe %in% c(0, 1)) {
        next
      }
      
      # hypertension 仅允许为 0 或 1
      if (!baseline_var$hypertension %in% c(0, 1)) {
        next
      }
      
      has_exposure_hypertension_data <- TRUE
      
      # 基线患高血压者排除
      if (baseline_var$hypertension == 1) {
        next
      }
      
      has_no_hypertension_baseline <- TRUE
      
      # 基线体力活动、互联网使用必须有数据
      if (is.na(baseline_var$phyactivities) || is.na(baseline_var$netuse)) {
        next
      }
      
      # 基线必须无痴呆
      if (is.na(baseline_var$dementia) || baseline_var$dementia != 0) {
        next
      }
      
      has_non_dementia_baseline <- TRUE
      
      # 所有协变量必须完整
      all_baseline_vars <- c(
        baseline_var$onlydiabe,
        baseline_var$hypertension,
        baseline_var$phyactivities,
        baseline_var$netuse,
        baseline_var$dementia,
        baseline_var$mstat,
        baseline_var$scocwk,
        baseline_var$smoking,
        baseline_var$Non_com_dis,
        baseline_var$drink,
        data$yearsold[i],
        data$raeduc_c[i],
        data$ragender[i]
      )
      
      if (any(is.na(all_baseline_vars))) {
        next
      }
      
      has_complete_covariate_baseline <- TRUE
      
      if (!has_followup_dementia_data(data, i, wave, max_wave_i)) {
        next
      }
      
      has_followup_data <- TRUE
      
      # 选择最早满足条件的波次为动态基线
      data$enrollment_wave[i] <- wave
      data$screening_status[i] <- "纳入最终分析"
      enrollment_found <- TRUE
      
      break
    }
    
    if (!enrollment_found) {
      
      if (!has_exposure_hypertension_data) {
        data$screening_status[i] <- "排除：基线糖尿病或高血压状态缺失"
        
      } else if (!has_no_hypertension_baseline) {
        data$screening_status[i] <- "排除：基线患高血压"
        
      } else if (!has_non_dementia_baseline) {
        data$screening_status[i] <- "排除：基线痴呆或基线暴露信息缺失"
        
      } else if (!has_complete_covariate_baseline) {
        data$screening_status[i] <- "排除：基线协变量数据缺失"
        
      } else if (!has_followup_data) {
        data$screening_status[i] <- "排除：基线后痴呆随访数据缺失"
        
      } else {
        data$screening_status[i] <- "排除：其他原因"
      }
    }
  }
  
  data
}

screened_data <- filter_sensitivity_analysis_data(total_data)
data_in <- screened_data %>%
  filter(screening_status == "纳入最终分析")

# =====================================================================
# 5. 提取动态基线协变量、随访时间及初步事件
# =====================================================================
extract_baseline_covariates <- function(data) {
  
  new_vars <- c(
    "baseline_onlydiabe",
    "baseline_hypertension",
    "baseline_dementia_status",
    "baseline_phyactivities",
    "baseline_netuse",
    "baseline_mstat",
    "baseline_scocwk",
    "baseline_smoking",
    "baseline_drink",
    "baseline_Non_com_dis",
    "baseline_year",
    "last_followup_year",
    "time_to_event",
    "event_status"
  )
  
  data[new_vars] <- NA_real_
  
  for (i in seq_len(nrow(data))) {
    
    source_i <- safe_get_value(data, i, "data_source")
    wave_i <- safe_get_value(data, i, "enrollment_wave")
    wave_info <- get_wave_info(source_i)
    
    if (is.null(wave_info) || is.na(wave_i)) {
      next
    }
    
    wave_i <- as.integer(wave_i)
    max_wave_i <- wave_info$max_wave
    wave_years_i <- wave_info$wave_years
    baseline_year_i <- wave_years_i[wave_i]
    
    # 提取动态基线协变量
    data$baseline_onlydiabe[i] <- safe_get_value(
      data, i, paste0("r", wave_i, "onlydiabe")
    )
    data$baseline_hypertension[i] <- safe_get_value(
      data, i, paste0("r", wave_i, "hypertension")
    )
    data$baseline_dementia_status[i] <- safe_get_value(
      data, i, paste0("r", wave_i, "dementia")
    )
    data$baseline_phyactivities[i] <- safe_get_value(
      data, i, paste0("r", wave_i, "phyactivities")
    )
    data$baseline_netuse[i] <- safe_get_value(
      data, i, paste0("r", wave_i, "netuse")
    )
    data$baseline_mstat[i] <- safe_get_value(
      data, i, paste0("r", wave_i, "mstat")
    )
    data$baseline_scocwk[i] <- safe_get_value(
      data, i, paste0("r", wave_i, "scocwk")
    )
    data$baseline_smoking[i] <- safe_get_value(
      data, i, paste0("r", wave_i, "smoking")
    )
    data$baseline_drink[i] <- safe_get_value(
      data, i, paste0("r", wave_i, "drink")
    )
    data$baseline_Non_com_dis[i] <- safe_get_value(
      data, i, paste0("r", wave_i, "Non_com_dis")
    )
    
    data$baseline_year[i] <- baseline_year_i
    
    onset_year_i <- NA_real_
    last_followup_year_i <- baseline_year_i
    event_i <- 0L
    
    future_waves <- seq.int(wave_i + 1L, max_wave_i)
    
    for (future_wave in future_waves) {
      
      dementia_i <- safe_get_value(
        data, i, paste0("r", future_wave, "dementia")
      )
      
      current_year_i <- wave_years_i[future_wave]
      
      if (!is.na(dementia_i)) {
        
        last_followup_year_i <- current_year_i
        
        if (dementia_i == 1 && is.na(onset_year_i)) {
          onset_year_i <- current_year_i
          event_i <- 1L
          break
        }
      }
    }
    
    data$last_followup_year[i] <- last_followup_year_i
    data$event_status[i] <- event_i
    
    if (event_i == 1L) {
      data$time_to_event[i] <- onset_year_i - baseline_year_i
    } else {
      data$time_to_event[i] <- last_followup_year_i - baseline_year_i
    }
  }
  
  data %>%
    select(
      record_id,
      ID,
      country,
      data_source,
      enrollment_wave,
      baseline_year,
      last_followup_year,
      yearsold,
      age,
      raeduc_c,
      ragender,
      baseline_onlydiabe,
      baseline_hypertension,
      baseline_dementia_status,
      baseline_phyactivities,
      baseline_netuse,
      baseline_mstat,
      baseline_scocwk,
      baseline_smoking,
      baseline_drink,
      baseline_Non_com_dis,
      time_to_event,
      event_status
    ) %>%
    
    # 再次确保最终分析对象均无高血压、协变量完整
    filter(
      baseline_onlydiabe %in% c(0, 1),
      baseline_hypertension == 0,
      baseline_dementia_status == 0,
      !is.na(yearsold),
      !is.na(age),
      !is.na(raeduc_c),
      !is.na(ragender),
      !is.na(baseline_phyactivities),
      !is.na(baseline_netuse),
      !is.na(baseline_mstat),
      !is.na(baseline_scocwk),
      !is.na(baseline_smoking),
      !is.na(baseline_drink),
      !is.na(baseline_Non_com_dis),
      !is.na(time_to_event),
      time_to_event > 0
    ) %>%
    
    mutate(
      country = factor(
        country,
        levels = c("CHARLS", "HRS", "SHARE", "ELSA")
      ),
      
      # 暴露组：糖尿病且无高血压
      # 对照组：无糖尿病且无高血压
      baseline_onlydiabe = factor(
        baseline_onlydiabe,
        levels = c(0, 1),
        labels = c("无糖尿病且无高血压", "糖尿病且无高血压")
      ),
      
      yearsold = factor(
        yearsold,
        levels = c(1, 2, 3, 4),
        labels = c("60岁以下", "60-69岁", "70-79岁", "80岁及以上")
      ),
      
      ragender = factor(
        ragender,
        levels = c(1, 2),
        labels = c("男", "女")
      ),
      
      raeduc_c = factor(
        raeduc_c,
        levels = c(1, 2, 3),
        labels = c("初中及以下", "高中", "大学及以上")
      ),
      
      baseline_phyactivities = factor(
        baseline_phyactivities,
        levels = c(0, 1),
        labels = c("不活跃", "活跃")
      ),
      
      baseline_netuse = factor(
        baseline_netuse,
        levels = c(0, 1),
        labels = c("不使用", "使用")
      ),
      
      baseline_mstat = factor(
        baseline_mstat,
        levels = c(1, 2),
        labels = c("已婚/同居", "单身")
      ),
      
      baseline_scocwk = factor(
        baseline_scocwk,
        levels = c(0, 1),
        labels = c("不活跃", "活跃")
      ),
      
      baseline_smoking = factor(
        baseline_smoking,
        levels = c(0, 1, 2),
        labels = c("戒烟", "吸烟", "从未吸烟")
      ),
      
      baseline_drink = factor(
        baseline_drink,
        levels = c(0, 1),
        labels = c("从未饮酒", "饮过酒")
      ),
      
      baseline_Non_com_dis = factor(
        baseline_Non_com_dis,
        levels = c(0, 1),
        labels = c("无", "有")
      )
    )
}

cox_data_initial <- extract_baseline_covariates(data_in)

# =====================================================================
# 6. 校正痴呆事件状态及随访时间
#
# 校正规则：
# 首次观察到痴呆=1 后，若下一次有效痴呆观测为 0，
# 则该首次阳性不判定为痴呆事件，随访至最后一次有效观测。
# =====================================================================
correct_event_status <- function(data, origin_data) {
  
  dementia_vars <- paste0("r", 1:6, "dementia")
  existing_dementia_vars <- intersect(dementia_vars, names(origin_data))
  
  origin_data_sub <- origin_data %>%
    select(record_id, any_of(existing_dementia_vars))
  
  if (anyDuplicated(origin_data_sub$record_id) > 0) {
    stop("原始数据中的 record_id 不唯一。")
  }
  
  if (anyDuplicated(data$record_id) > 0) {
    stop("分析数据中的 record_id 不唯一。")
  }
  
  data_correct <- data %>%
    left_join(origin_data_sub, by = "record_id")
  
  for (i in seq_len(nrow(data_correct))) {
    
    source_i <- safe_get_value(data_correct, i, "data_source")
    wave_i <- safe_get_value(data_correct, i, "enrollment_wave")
    wave_info <- get_wave_info(source_i)
    
    if (is.null(wave_info) || is.na(wave_i)) {
      data_correct$event_status[i] <- 0L
      data_correct$time_to_event[i] <- NA_real_
      next
    }
    
    wave_i <- as.integer(wave_i)
    max_wave_i <- wave_info$max_wave
    wave_years_i <- wave_info$wave_years
    baseline_year_i <- wave_years_i[wave_i]
    
    if (wave_i >= max_wave_i) {
      data_correct$event_status[i] <- 0L
      data_correct$time_to_event[i] <- NA_real_
      next
    }
    
    future_waves <- seq.int(wave_i + 1L, max_wave_i)
    
    future_dementia <- vapply(
      future_waves,
      function(wave) {
        safe_get_value(data_correct, i, paste0("r", wave, "dementia"))
      },
      numeric(1)
    )
    
    valid_index <- which(!is.na(future_dementia))
    
    if (length(valid_index) == 0) {
      data_correct$event_status[i] <- 0L
      data_correct$time_to_event[i] <- NA_real_
      next
    }
    
    valid_dementia <- future_dementia[valid_index]
    valid_waves <- future_waves[valid_index]
    
    last_followup_wave <- tail(valid_waves, 1)
    last_followup_year_i <- wave_years_i[last_followup_wave]
    
    data_correct$last_followup_year[i] <- last_followup_year_i
    
    event_i <- 0L
    onset_year_i <- NA_real_
    
    first_positive_position <- which(valid_dementia == 1)[1]
    
    if (!is.na(first_positive_position)) {
      
      first_positive_wave <- valid_waves[first_positive_position]
      first_positive_year <- wave_years_i[first_positive_wave]
      
      if (first_positive_position < length(valid_dementia)) {
        
        next_valid_dementia <- valid_dementia[first_positive_position + 1L]
        
        if (next_valid_dementia != 0) {
          event_i <- 1L
          onset_year_i <- first_positive_year
        }
        
      } else {
        event_i <- 1L
        onset_year_i <- first_positive_year
      }
    }
    
    data_correct$event_status[i] <- event_i
    
    if (event_i == 1L) {
      data_correct$time_to_event[i] <- onset_year_i - baseline_year_i
    } else {
      data_correct$time_to_event[i] <- last_followup_year_i - baseline_year_i
    }
  }
  
  data_correct %>%
    select(-any_of(existing_dementia_vars)) %>%
    filter(
      !is.na(time_to_event),
      time_to_event > 0
    )
}

# =====================================================================
# 7. 构建最终 Cox 分析数据：cox_data_final
# =====================================================================
cox_data_final <- correct_event_status(
  data = cox_data_initial,
  origin_data = data_in
) %>%
  mutate(event_status = as.integer(event_status)) %>%
  droplevels()

# 导出最终 Cox 分析数据；亚组分析直接复用此数据
readr::write_excel_csv(
  cox_data_final,
  file = "最终Cox分析数据_糖尿病无高血压.csv"
)

# =====================================================================
# 8. 敏感性分析流程图及样本量统计
# =====================================================================
n_all_participants <- nrow(total_data)
flow_order <- c(
  "纳入最终分析",
  "排除：年龄<50岁或年龄缺失",
  "排除：基线糖尿病或高血压状态缺失",
  "排除：基线患高血压",
  "排除：基线痴呆或基线暴露信息缺失",
  "排除：基线协变量数据缺失",
  "排除：基线后痴呆随访数据缺失",
  "排除：其他原因",
  "排除：未知数据来源"
)
flow_table <- screened_data %>%
  count(screening_status, name = "N") %>%
  mutate(
    percent_of_total = round(N / n_all_participants * 100, 2),
    screening_status = factor(screening_status, levels = flow_order)
  ) %>%
  arrange(screening_status)

flow_by_country <- screened_data %>%
  mutate(screening_status = factor(screening_status, levels = flow_order)) %>%
  group_by(country, screening_status) %>%
  summarise(N = n(), .groups = "drop") %>%
  pivot_wider(
    names_from = screening_status,
    values_from = N,
    values_fill = 0
  )

n_after_screening <- nrow(data_in)
n_final_analysis <- nrow(cox_data_final)
n_removed_after_event_correction <- n_after_screening - n_final_analysis

analysis_sample_by_country <- cox_data_final %>%
  group_by(country) %>%
  summarise(
    N = n(),
    diabetes_no_hypertension = sum(
      baseline_onlydiabe == "糖尿病且无高血压",
      na.rm = TRUE
    ),
    control_no_diabetes_no_hypertension = sum(
      baseline_onlydiabe == "无糖尿病且无高血压",
      na.rm = TRUE
    ),
    dementia_events = sum(event_status == 1, na.rm = TRUE),
    non_events = sum(event_status == 0, na.rm = TRUE),
    mean_followup_years = mean(time_to_event, na.rm = TRUE),
    median_followup_years = median(time_to_event, na.rm = TRUE),
    .groups = "drop"
  ) %>%
  mutate(country = as.character(country))

overall_followup <- cox_data_final %>%
  summarise(
    country = "总体（四国合并）",
    N = n(),
    diabetes_no_hypertension = sum(
      baseline_onlydiabe == "糖尿病且无高血压",
      na.rm = TRUE
    ),
    control_no_diabetes_no_hypertension = sum(
      baseline_onlydiabe == "无糖尿病且无高血压",
      na.rm = TRUE
    ),
    dementia_events = sum(event_status == 1, na.rm = TRUE),
    non_events = sum(event_status == 0, na.rm = TRUE),
    mean_followup_years = mean(time_to_event, na.rm = TRUE),
    median_followup_years = median(time_to_event, na.rm = TRUE)
  )

analysis_sample_with_overall <- bind_rows(
  analysis_sample_by_country,
  overall_followup
)

cat("\n====================================================\n")
cat("敏感性分析流程图样本量结果\n")
cat("====================================================\n")
cat("\n原始总样本量：", n_all_participants, "\n")
print(flow_table)
cat("\n动态基线筛选后样本量：", n_after_screening, "\n")
cat("结局校正后最终分析样本量：", n_final_analysis, "\n")
cat("结局校正后移除人数：", n_removed_after_event_correction, "\n")
cat("\n====================================================\n")
cat("各国家敏感性分析筛选情况\n")
cat("====================================================\n")
print(flow_by_country)
cat("\n====================================================\n")
cat("最终分析样本量、事件数和随访时间\n")
cat("====================================================\n")
print(analysis_sample_with_overall)

# =====================================================================
# 9. 基于 cox_data_final 创建亚组变量
# =====================================================================
subgroup_data <- cox_data_final %>%
  mutate(
    subgroup_age = yearsold,
    subgroup_gender = ragender,
    subgroup_education = raeduc_c,
    
    subgroup_ncd = factor(
      baseline_Non_com_dis,
      levels = c("无", "有"),
      labels = c("无其他慢性病", "有其他慢性病")
    ),
    
    subgroup_physical_activity = baseline_phyactivities,
    subgroup_internet_use = baseline_netuse
  ) %>%
  droplevels()

# =====================================================================
# 10. 亚组定义及对应调整变量
#
# 每个亚组模型均不再调整自身的分层变量。
# =====================================================================
all_adjustment_vars <- c(
  "yearsold",
  "ragender",
  "raeduc_c",
  "baseline_phyactivities",
  "baseline_netuse",
  "baseline_mstat",
  "baseline_scocwk",
  "baseline_smoking",
  "baseline_drink",
  "baseline_Non_com_dis"
)

subgroup_config <- data.frame(
  subgroup = c(
    "年龄",
    "性别",
    "教育水平",
    "其他慢性病",
    "体力活动",
    "互联网使用"
  ),
  
  subgroup_var = c(
    "subgroup_age",
    "subgroup_gender",
    "subgroup_education",
    "subgroup_ncd",
    "subgroup_physical_activity",
    "subgroup_internet_use"
  ),
  
  exclude_adjustment_var = c(
    "yearsold",
    "ragender",
    "raeduc_c",
    "baseline_Non_com_dis",
    "baseline_phyactivities",
    "baseline_netuse"
  ),
  
  stringsAsFactors = FALSE
)

# =====================================================================
# 11. 构建适用于当前亚组的 Cox 模型公式
# =====================================================================
build_subgroup_formula <- function(data, excluded_var) {
  
  adjustment_vars <- setdiff(all_adjustment_vars, excluded_var)
  
  valid_adjustment_vars <- adjustment_vars[
    vapply(
      adjustment_vars,
      function(var) {
        length(unique(stats::na.omit(data[[var]]))) > 1
      },
      logical(1)
    )
  ]
  
  formula_vars <- c("baseline_onlydiabe", valid_adjustment_vars)
  
  as.formula(
    paste(
      "Surv(time_to_event, event_status) ~",
      paste(formula_vars, collapse = " + ")
    )
  )
}

# =====================================================================
# 12. 单个国家、单个亚组水平 Cox 回归
# =====================================================================
empty_subgroup_cox_result <- function(
    subgroup_name,
    subgroup_level,
    country_name,
    n_total,
    n_events,
    message
) {
  
  tibble(
    亚组 = subgroup_name,
    亚组水平 = subgroup_level,
    国家 = country_name,
    样本量 = n_total,
    痴呆事件数 = n_events,
    HR = NA_real_,
    CI下限 = NA_real_,
    CI上限 = NA_real_,
    P值 = NA_real_,
    logHR = NA_real_,
    SE_logHR = NA_real_,
    结果状态 = message
  )
}

run_subgroup_cox <- function(
    data,
    subgroup_name,
    subgroup_level,
    country_name,
    excluded_var
) {
  
  n_total <- nrow(data)
  n_events <- sum(data$event_status == 1, na.rm = TRUE)
  
  exposure_levels <- length(unique(stats::na.omit(data$baseline_onlydiabe)))
  
  if (n_total == 0) {
    return(
      empty_subgroup_cox_result(
        subgroup_name, subgroup_level, country_name,
        n_total, n_events, "无法估计：无样本"
      )
    )
  }
  
  if (n_events == 0) {
    return(
      empty_subgroup_cox_result(
        subgroup_name, subgroup_level, country_name,
        n_total, n_events, "无法估计：无痴呆事件"
      )
    )
  }
  
  if (exposure_levels < 2) {
    return(
      empty_subgroup_cox_result(
        subgroup_name, subgroup_level, country_name,
        n_total, n_events, "无法估计：糖尿病变量仅一个水平"
      )
    )
  }
  
  data <- droplevels(data)
  cox_formula <- build_subgroup_formula(data, excluded_var)
  
  cox_fit <- tryCatch(
    coxph(
      formula = cox_formula,
      data = data,
      x = TRUE
    ),
    error = function(e) NULL
  )
  
  if (is.null(cox_fit)) {
    return(
      empty_subgroup_cox_result(
        subgroup_name, subgroup_level, country_name,
        n_total, n_events, "无法估计：Cox 模型拟合失败"
      )
    )
  }
  
  fit_result <- broom::tidy(
    cox_fit,
    conf.int = TRUE,
    exponentiate = TRUE
  )
  
  exposure_result <- fit_result %>%
    filter(grepl("^baseline_onlydiabe", term))
  
  if (
    nrow(exposure_result) != 1 ||
    any(is.na(c(
      exposure_result$estimate,
      exposure_result$conf.low,
      exposure_result$conf.high
    )))
  ) {
    return(
      empty_subgroup_cox_result(
        subgroup_name, subgroup_level, country_name,
        n_total, n_events, "无法估计：未获得糖尿病效应值"
      )
    )
  }
  
  se_loghr <- (
    log(exposure_result$conf.high) -
      log(exposure_result$conf.low)
  ) / (2 * qnorm(0.975))
  
  tibble(
    亚组 = subgroup_name,
    亚组水平 = subgroup_level,
    国家 = country_name,
    样本量 = n_total,
    痴呆事件数 = n_events,
    HR = exposure_result$estimate,
    CI下限 = exposure_result$conf.low,
    CI上限 = exposure_result$conf.high,
    P值 = exposure_result$p.value,
    logHR = log(exposure_result$estimate),
    SE_logHR = se_loghr,
    结果状态 = "估计成功"
  )
}

# =====================================================================
# 13. 分国家执行所有亚组 Cox 回归
# =====================================================================
countries <- c("CHARLS", "HRS", "SHARE", "ELSA")
subgroup_cox_results <- tibble()

for (config_i in seq_len(nrow(subgroup_config))) {
  
  subgroup_name_i <- subgroup_config$subgroup[config_i]
  subgroup_var_i <- subgroup_config$subgroup_var[config_i]
  excluded_var_i <- subgroup_config$exclude_adjustment_var[config_i]
  
  subgroup_levels_i <- levels(subgroup_data[[subgroup_var_i]])
  
  for (level_i in subgroup_levels_i) {
    
    data_level_i <- subgroup_data %>%
      filter(.data[[subgroup_var_i]] == level_i)
    
    for (country_i in countries) {
      
      data_country_i <- data_level_i %>%
        filter(country == country_i)
      
      result_i <- run_subgroup_cox(
        data = data_country_i,
        subgroup_name = subgroup_name_i,
        subgroup_level = level_i,
        country_name = country_i,
        excluded_var = excluded_var_i
      )
      
      subgroup_cox_results <- bind_rows(
        subgroup_cox_results,
        result_i
      )
    }
  }
}

subgroup_cox_results_display <- subgroup_cox_results %>%
  mutate(
    `HR（95%CI）` = case_when(
      is.na(HR) ~ NA_character_,
      TRUE ~ sprintf("%.3f（%.3f–%.3f）", HR, CI下限, CI上限)
    ),
    
    `P值（格式化）` = case_when(
      is.na(P值) ~ NA_character_,
      P值 < 0.001 ~ "<0.001",
      TRUE ~ sprintf("%.3f", P值)
    )
  ) %>%
  select(
    亚组,
    亚组水平,
    国家,
    样本量,
    痴呆事件数,
    HR,
    CI下限,
    CI上限,
    `HR（95%CI）`,
    P值,
    `P值（格式化）`,
    logHR,
    SE_logHR,
    结果状态
  )

# =====================================================================
# 14. 各亚组水平进行四国随机效应 Meta 分析
# =====================================================================
run_subgroup_meta <- function(data, subgroup_name, subgroup_level) {
  
  meta_data <- data %>%
    filter(
      亚组 == subgroup_name,
      亚组水平 == subgroup_level,
      !is.na(logHR),
      !is.na(SE_logHR),
      is.finite(logHR),
      is.finite(SE_logHR),
      SE_logHR > 0
    )
  
  if (nrow(meta_data) < 2) {
    return(
      tibble(
        亚组 = subgroup_name,
        亚组水平 = subgroup_level,
        纳入国家数 = nrow(meta_data),
        合并HR = NA_real_,
        合并CI下限 = NA_real_,
        合并CI上限 = NA_real_,
        合并P值 = NA_real_,
        Q统计量 = NA_real_,
        Q自由度 = NA_real_,
        异质性P值 = NA_real_,
        I2百分比 = NA_real_,
        Tau2 = NA_real_,
        Meta结果状态 = "无法进行 Meta 分析：有效国家少于2个"
      )
    )
  }
  
  meta_fit <- tryCatch(
    metagen(
      TE = logHR,
      seTE = SE_logHR,
      studlab = 国家,
      data = meta_data,
      sm = "HR",
      common = FALSE,
      random = TRUE,
      method.tau = "REML",
      hakn = FALSE
    ),
    error = function(e) NULL
  )
  
  if (is.null(meta_fit)) {
    return(
      tibble(
        亚组 = subgroup_name,
        亚组水平 = subgroup_level,
        纳入国家数 = nrow(meta_data),
        合并HR = NA_real_,
        合并CI下限 = NA_real_,
        合并CI上限 = NA_real_,
        合并P值 = NA_real_,
        Q统计量 = NA_real_,
        Q自由度 = NA_real_,
        异质性P值 = NA_real_,
        I2百分比 = NA_real_,
        Tau2 = NA_real_,
        Meta结果状态 = "无法进行 Meta 分析：模型拟合失败"
      )
    )
  }
  
  tibble(
    亚组 = subgroup_name,
    亚组水平 = subgroup_level,
    纳入国家数 = nrow(meta_data),
    合并HR = exp(meta_fit$TE.random),
    合并CI下限 = exp(meta_fit$lower.random),
    合并CI上限 = exp(meta_fit$upper.random),
    合并P值 = meta_fit$pval.random,
    Q统计量 = meta_fit$Q,
    Q自由度 = meta_fit$df.Q,
    异质性P值 = meta_fit$pval.Q,
    I2百分比 = meta_fit$I2 * 100,
    Tau2 = meta_fit$tau^2,
    Meta结果状态 = "Meta 分析成功"
  )
}

subgroup_meta_results <- tibble()

for (config_i in seq_len(nrow(subgroup_config))) {
  
  subgroup_name_i <- subgroup_config$subgroup[config_i]
  subgroup_var_i <- subgroup_config$subgroup_var[config_i]
  subgroup_levels_i <- levels(subgroup_data[[subgroup_var_i]])
  
  for (level_i in subgroup_levels_i) {
    
    meta_result_i <- run_subgroup_meta(
      data = subgroup_cox_results,
      subgroup_name = subgroup_name_i,
      subgroup_level = level_i
    )
    
    subgroup_meta_results <- bind_rows(
      subgroup_meta_results,
      meta_result_i
    )
  }
}

subgroup_meta_results_display <- subgroup_meta_results %>%
  mutate(
    `合并HR（95%CI）` = case_when(
      is.na(合并HR) ~ NA_character_,
      TRUE ~ sprintf(
        "%.3f（%.3f–%.3f）",
        合并HR,
        合并CI下限,
        合并CI上限
      )
    ),
    
    `合并P值（格式化）` = case_when(
      is.na(合并P值) ~ NA_character_,
      合并P值 < 0.001 ~ "<0.001",
      TRUE ~ sprintf("%.3f", 合并P值)
    ),
    
    `异质性P值（格式化）` = case_when(
      is.na(异质性P值) ~ NA_character_,
      异质性P值 < 0.001 ~ "<0.001",
      TRUE ~ sprintf("%.3f", 异质性P值)
    ),
    
    `I²` = case_when(
      is.na(I2百分比) ~ NA_character_,
      TRUE ~ paste0(sprintf("%.1f", I2百分比), "%")
    )
  ) %>%
  select(
    亚组,
    亚组水平,
    纳入国家数,
    合并HR,
    合并CI下限,
    合并CI上限,
    `合并HR（95%CI）`,
    合并P值,
    `合并P值（格式化）`,
    Q统计量,
    Q自由度,
    异质性P值,
    `异质性P值（格式化）`,
    I2百分比,
    `I²`,
    Tau2,
    Meta结果状态
  )

# =====================================================================
# 15. 生成与论文图表类似的宽表结果
# =====================================================================
subgroup_country_wide <- subgroup_cox_results_display %>%
  select(
    亚组,
    亚组水平,
    国家,
    样本量,
    痴呆事件数,
    `HR（95%CI）`,
    `P值（格式化）`
  ) %>%
  pivot_wider(
    names_from = 国家,
    values_from = c(样本量, 痴呆事件数, `HR（95%CI）`, `P值（格式化）`),
    names_glue = "{国家}_{.value}"
  )

subgroup_final_table <- subgroup_country_wide %>%
  left_join(
    subgroup_meta_results_display %>%
      select(
        亚组,
        亚组水平,
        纳入国家数,
        `合并HR（95%CI）`,
        `合并P值（格式化）`,
        `I²`,
        `异质性P值（格式化）`,
        Meta结果状态
      ),
    by = c("亚组", "亚组水平")
  ) %>%
  arrange(
    factor(
      亚组,
      levels = c("年龄", "性别", "教育水平", "其他慢性病", "体力活动", "互联网使用")
    ),
    亚组水平
  )

# =====================================================================
# 16. 输出主结果
# =====================================================================
cat("\n====================================================\n")
cat("最终 Cox 分析样本量（排除基线高血压）\n")
cat("====================================================\n")
cat("最终样本量：", nrow(cox_data_final), "\n")
cat("痴呆事件数：", sum(cox_data_final$event_status == 1, na.rm = TRUE), "\n")

cat("\n====================================================\n")
cat("各国家亚组 Cox 回归结果\n")
cat("暴露：糖尿病且无高血压 vs 无糖尿病且无高血压\n")
cat("====================================================\n")
print(subgroup_cox_results_display, n = Inf)

cat("\n====================================================\n")
cat("各亚组随机效应 Meta 分析结果\n")
cat("====================================================\n")
print(subgroup_meta_results_display, n = Inf)

cat("\n====================================================\n")
cat("亚组分析汇总宽表\n")
cat("====================================================\n")
print(subgroup_final_table, n = Inf)

# =====================================================================
# 17. 导出主分析中文 CSV 文件
# =====================================================================
readr::write_excel_csv(
  cox_data_final,
  file = "表1_最终Cox分析数据_糖尿病无高血压.csv"
)
readr::write_excel_csv(
  subgroup_cox_results_display,
  file = "表2_各国亚组Cox回归结果_糖尿病无高血压.csv"
)
readr::write_excel_csv(
  subgroup_meta_results_display,
  file = "表3_亚组随机效应Meta分析结果_糖尿病无高血压.csv"
)
readr::write_excel_csv(
  subgroup_final_table,
  file = "表4_糖尿病无高血压与痴呆风险亚组分析汇总表.csv"
)
readr::write_excel_csv(
  screened_data,
  file = "附表1_动态基线筛选结果_糖尿病无高血压.csv"
)
readr::write_excel_csv(
  flow_table,
  file = "附表2_敏感性分析流程图样本量_糖尿病无高血压.csv"
)
readr::write_excel_csv(
  analysis_sample_with_overall,
  file = "附表3_最终分析样本量事件数随访_糖尿病无高血压.csv"
)

cat("\n====================================================\n")
cat("主分析文件导出完成：\n")
cat("1. 表1_最终Cox分析数据_糖尿病无高血压.csv\n")
cat("2. 表2_各国亚组Cox回归结果_糖尿病无高血压.csv\n")
cat("3. 表3_亚组随机效应Meta分析结果_糖尿病无高血压.csv\n")
cat("4. 表4_糖尿病无高血压与痴呆风险亚组分析汇总表.csv\n")
cat("5. 附表1_动态基线筛选结果_糖尿病无高血压.csv\n")
cat("6. 附表2_敏感性分析流程图样本量_糖尿病无高血压.csv\n")
cat("7. 附表3_最终分析样本量事件数随访_糖尿病无高血压.csv\n")
cat("====================================================\n")


# =====================================================================
# 异质性来源与 CHARLS 队列估计稳定性辅助分析
#
# 运行位置：主亚组分析完成后，依赖以下对象：
# 1. cox_data_final
# 2. subgroup_data
# 3. subgroup_cox_results
# =====================================================================

# =====================================================================
# 18. 检查核心分析对象
# =====================================================================
required_objects <- c(
  "cox_data_final",
  "subgroup_data",
  "subgroup_cox_results"
)
missing_objects <- required_objects[
  !vapply(required_objects, exists, logical(1), inherits = TRUE)
]
if (length(missing_objects) > 0) {
  stop(
    "缺少以下分析对象，请先运行主 Cox 分析及亚组分析代码：",
    paste(missing_objects, collapse = "、")
  )
}

required_vars <- c(
  "country",
  "time_to_event",
  "event_status",
  "baseline_onlydiabe",
  "yearsold",
  "ragender",
  "raeduc_c",
  "baseline_phyactivities",
  "baseline_netuse"
)
missing_vars <- setdiff(required_vars, names(cox_data_final))
if (length(missing_vars) > 0) {
  stop(
    "cox_data_final 中缺少以下变量：",
    paste(missing_vars, collapse = "、")
  )
}

# =====================================================================
# 19. 辅助函数
# =====================================================================
format_p_value <- function(p_value) {
  
  case_when(
    is.na(p_value) ~ NA_character_,
    p_value < 0.001 ~ "<0.001",
    TRUE ~ sprintf("%.3f", p_value)
  )
}

format_percent <- function(value, digits = 1) {
  
  case_when(
    is.na(value) ~ NA_character_,
    TRUE ~ paste0(sprintf(paste0("%.", digits, "f"), value), "%")
  )
}

format_hr_ci <- function(hr, lower_ci, upper_ci) {
  
  case_when(
    is.na(hr) | is.na(lower_ci) | is.na(upper_ci) ~ NA_character_,
    TRUE ~ sprintf("%.3f（%.3f–%.3f）", hr, lower_ci, upper_ci)
  )
}

# =====================================================================
# 20. 四国队列特征与暴露分布
# =====================================================================
cohort_characteristics <- cox_data_final %>%
  mutate(
    痴呆事件 = as.integer(event_status == 1),
    随访时间 = as.numeric(time_to_event),
    
    年龄数值 = case_when(
      as.character(yearsold) == "60岁以下" ~ 55,
      as.character(yearsold) == "60-69岁" ~ 65,
      as.character(yearsold) == "70-79岁" ~ 75,
      as.character(yearsold) == "80岁及以上" ~ 85,
      TRUE ~ NA_real_
    )
  ) %>%
  group_by(country) %>%
  summarise(
    样本量 = n(),
    痴呆事件数 = sum(痴呆事件, na.rm = TRUE),
    痴呆事件率百分比 = mean(痴呆事件, na.rm = TRUE) * 100,
    
    平均随访时间年 = mean(随访时间, na.rm = TRUE),
    随访时间标准差年 = sd(随访时间, na.rm = TRUE),
    
    # 糖尿病且无高血压暴露分布
    糖尿病无高血压人数 = sum(
      as.character(baseline_onlydiabe) == "糖尿病且无高血压",
      na.rm = TRUE
    ),
    糖尿病无高血压比例百分比 = mean(
      as.character(baseline_onlydiabe) == "糖尿病且无高血压",
      na.rm = TRUE
    ) * 100,
    
    互联网使用人数 = sum(
      as.character(baseline_netuse) == "使用",
      na.rm = TRUE
    ),
    互联网使用率百分比 = mean(
      as.character(baseline_netuse) == "使用",
      na.rm = TRUE
    ) * 100,
    
    体力活动活跃人数 = sum(
      as.character(baseline_phyactivities) == "活跃",
      na.rm = TRUE
    ),
    体力活动活跃率百分比 = mean(
      as.character(baseline_phyactivities) == "活跃",
      na.rm = TRUE
    ) * 100,
    
    `60岁以下人数` = sum(
      as.character(yearsold) == "60岁以下",
      na.rm = TRUE
    ),
    `60岁以下比例百分比` = mean(
      as.character(yearsold) == "60岁以下",
      na.rm = TRUE
    ) * 100,
    
    `60至69岁人数` = sum(
      as.character(yearsold) == "60-69岁",
      na.rm = TRUE
    ),
    `60至69岁比例百分比` = mean(
      as.character(yearsold) == "60-69岁",
      na.rm = TRUE
    ) * 100,
    
    `70至79岁人数` = sum(
      as.character(yearsold) == "70-79岁",
      na.rm = TRUE
    ),
    `70至79岁比例百分比` = mean(
      as.character(yearsold) == "70-79岁",
      na.rm = TRUE
    ) * 100,
    
    `80岁及以上人数` = sum(
      as.character(yearsold) == "80岁及以上",
      na.rm = TRUE
    ),
    `80岁及以上比例百分比` = mean(
      as.character(yearsold) == "80岁及以上",
      na.rm = TRUE
    ) * 100,
    
    `70岁及以上比例百分比` = mean(
      as.character(yearsold) %in% c("70-79岁", "80岁及以上"),
      na.rm = TRUE
    ) * 100,
    
    年龄结构近似均值 = mean(年龄数值, na.rm = TRUE),
    
    初中及以下人数 = sum(
      as.character(raeduc_c) == "初中及以下",
      na.rm = TRUE
    ),
    初中及以下比例百分比 = mean(
      as.character(raeduc_c) == "初中及以下",
      na.rm = TRUE
    ) * 100,
    
    高中人数 = sum(
      as.character(raeduc_c) == "高中",
      na.rm = TRUE
    ),
    高中比例百分比 = mean(
      as.character(raeduc_c) == "高中",
      na.rm = TRUE
    ) * 100,
    
    大学及以上人数 = sum(
      as.character(raeduc_c) == "大学及以上",
      na.rm = TRUE
    ),
    大学及以上比例百分比 = mean(
      as.character(raeduc_c) == "大学及以上",
      na.rm = TRUE
    ) * 100,
    
    高教育水平比例百分比 = mean(
      as.character(raeduc_c) == "大学及以上",
      na.rm = TRUE
    ) * 100,
    
    .groups = "drop"
  ) %>%
  mutate(
    国家 = as.character(country),
    痴呆事件率 = format_percent(痴呆事件率百分比),
    糖尿病无高血压比例 = format_percent(糖尿病无高血压比例百分比),
    互联网使用率 = format_percent(互联网使用率百分比),
    体力活动活跃率 = format_percent(体力活动活跃率百分比),
    `70岁及以上比例` = format_percent(`70岁及以上比例百分比`),
    高教育水平比例 = format_percent(高教育水平比例百分比)
  ) %>%
  select(
    国家,
    样本量,
    痴呆事件数,
    痴呆事件率百分比,
    痴呆事件率,
    平均随访时间年,
    随访时间标准差年,
    
    糖尿病无高血压人数,
    糖尿病无高血压比例百分比,
    糖尿病无高血压比例,
    
    互联网使用人数,
    互联网使用率百分比,
    互联网使用率,
    
    体力活动活跃人数,
    体力活动活跃率百分比,
    体力活动活跃率,
    
    `60岁以下人数`,
    `60岁以下比例百分比`,
    `60至69岁人数`,
    `60至69岁比例百分比`,
    `70至79岁人数`,
    `70至79岁比例百分比`,
    `80岁及以上人数`,
    `80岁及以上比例百分比`,
    `70岁及以上比例百分比`,
    `70岁及以上比例`,
    年龄结构近似均值,
    
    初中及以下人数,
    初中及以下比例百分比,
    高中人数,
    高中比例百分比,
    大学及以上人数,
    大学及以上比例百分比,
    高教育水平比例百分比,
    高教育水平比例
  ) %>%
  arrange(match(国家, c("CHARLS", "HRS", "SHARE", "ELSA")))

print(cohort_characteristics, n = Inf)

# =====================================================================
# 21. 计算各国、各亚组估计结果的置信区间宽度
# =====================================================================
subgroup_precision_results <- subgroup_cox_results %>%
  mutate(
    CI宽度_HR尺度 = case_when(
      !is.na(CI上限) & !is.na(CI下限) ~ CI上限 - CI下限,
      TRUE ~ NA_real_
    ),
    
    CI宽度_logHR尺度 = case_when(
      !is.na(CI上限) &
        !is.na(CI下限) &
        CI上限 > 0 &
        CI下限 > 0 ~ log(CI上限) - log(CI下限),
      TRUE ~ NA_real_
    ),
    
    估计精度评价 = case_when(
      is.na(CI宽度_logHR尺度) ~ "无法计算",
      CI宽度_logHR尺度 >= 5 ~ "极不稳定：置信区间极宽",
      CI宽度_logHR尺度 >= 3 ~ "不稳定：置信区间较宽",
      CI宽度_logHR尺度 >= 1.5 ~ "精度有限：置信区间中等宽度",
      TRUE ~ "估计相对稳定"
    ),
    
    `HR（95%CI）` = format_hr_ci(HR, CI下限, CI上限),
    `P值（格式化）` = format_p_value(P值)
  ) %>%
  select(
    亚组,
    亚组水平,
    国家,
    样本量,
    痴呆事件数,
    HR,
    CI下限,
    CI上限,
    `HR（95%CI）`,
    P值,
    `P值（格式化）`,
    logHR,
    SE_logHR,
    CI宽度_HR尺度,
    CI宽度_logHR尺度,
    估计精度评价,
    结果状态
  ) %>%
  arrange(
    亚组,
    亚组水平,
    match(国家, c("CHARLS", "HRS", "SHARE", "ELSA"))
  )

country_precision_summary <- subgroup_precision_results %>%
  filter(
    !is.na(CI宽度_logHR尺度),
    is.finite(CI宽度_logHR尺度)
  ) %>%
  group_by(国家) %>%
  summarise(
    可估计亚组数 = n(),
    平均log尺度CI宽度 = mean(CI宽度_logHR尺度, na.rm = TRUE),
    中位数log尺度CI宽度 = median(CI宽度_logHR尺度, na.rm = TRUE),
    最大log尺度CI宽度 = max(CI宽度_logHR尺度, na.rm = TRUE),
    CI宽度大于等于3的亚组数 = sum(CI宽度_logHR尺度 >= 3, na.rm = TRUE),
    CI宽度大于等于5的亚组数 = sum(CI宽度_logHR尺度 >= 5, na.rm = TRUE),
    .groups = "drop"
  ) %>%
  arrange(match(国家, c("CHARLS", "HRS", "SHARE", "ELSA")))

charls_unstable_subgroups <- subgroup_precision_results %>%
  filter(
    国家 == "CHARLS",
    估计精度评价 %in% c(
      "极不稳定：置信区间极宽",
      "不稳定：置信区间较宽"
    )
  ) %>%
  arrange(desc(CI宽度_logHR尺度))

# =====================================================================
# 22. 含 95% 预测区间的随机效应 Meta 分析
# =====================================================================
run_meta_with_prediction_interval <- function(
    data,
    subgroup_name,
    subgroup_level
) {
  
  meta_data <- data %>%
    filter(
      亚组 == subgroup_name,
      亚组水平 == subgroup_level,
      !is.na(logHR),
      !is.na(SE_logHR),
      is.finite(logHR),
      is.finite(SE_logHR),
      SE_logHR > 0
    )
  
  if (nrow(meta_data) < 2) {
    return(
      tibble(
        亚组 = subgroup_name,
        亚组水平 = subgroup_level,
        纳入国家数 = nrow(meta_data),
        合并HR = NA_real_,
        合并CI下限 = NA_real_,
        合并CI上限 = NA_real_,
        合并P值 = NA_real_,
        Q统计量 = NA_real_,
        Q自由度 = NA_real_,
        异质性P值 = NA_real_,
        I2百分比 = NA_real_,
        Tau2 = NA_real_,
        预测区间下限 = NA_real_,
        预测区间上限 = NA_real_,
        Meta结果状态 = "无法进行Meta分析：有效国家少于2个"
      )
    )
  }
  
  meta_fit <- tryCatch(
    meta::metagen(
      TE = logHR,
      seTE = SE_logHR,
      studlab = 国家,
      data = meta_data,
      sm = "HR",
      common = FALSE,
      random = TRUE,
      method.tau = "REML",
      hakn = FALSE,
      prediction = TRUE
    ),
    error = function(e) NULL
  )
  
  if (is.null(meta_fit)) {
    return(
      tibble(
        亚组 = subgroup_name,
        亚组水平 = subgroup_level,
        纳入国家数 = nrow(meta_data),
        合并HR = NA_real_,
        合并CI下限 = NA_real_,
        合并CI上限 = NA_real_,
        合并P值 = NA_real_,
        Q统计量 = NA_real_,
        Q自由度 = NA_real_,
        异质性P值 = NA_real_,
        I2百分比 = NA_real_,
        Tau2 = NA_real_,
        预测区间下限 = NA_real_,
        预测区间上限 = NA_real_,
        Meta结果状态 = "无法进行Meta分析：模型拟合失败"
      )
    )
  }
  
  tibble(
    亚组 = subgroup_name,
    亚组水平 = subgroup_level,
    纳入国家数 = nrow(meta_data),
    合并HR = exp(meta_fit$TE.random),
    合并CI下限 = exp(meta_fit$lower.random),
    合并CI上限 = exp(meta_fit$upper.random),
    合并P值 = meta_fit$pval.random,
    Q统计量 = meta_fit$Q,
    Q自由度 = meta_fit$df.Q,
    异质性P值 = meta_fit$pval.Q,
    I2百分比 = meta_fit$I2 * 100,
    Tau2 = meta_fit$tau^2,
    预测区间下限 = exp(meta_fit$lower.predict),
    预测区间上限 = exp(meta_fit$upper.predict),
    Meta结果状态 = "Meta分析成功"
  )
}

subgroup_levels_for_meta <- subgroup_cox_results %>%
  distinct(亚组, 亚组水平)

subgroup_meta_prediction_results <- subgroup_levels_for_meta %>%
  rowwise() %>%
  do(
    run_meta_with_prediction_interval(
      data = subgroup_cox_results,
      subgroup_name = .$亚组,
      subgroup_level = .$亚组水平
    )
  ) %>%
  ungroup() %>%
  mutate(
    `合并HR（95%CI）` = format_hr_ci(
      合并HR,
      合并CI下限,
      合并CI上限
    ),
    
    `合并P值（格式化）` = format_p_value(合并P值),
    `异质性P值（格式化）` = format_p_value(异质性P值),
    
    `I²` = format_percent(I2百分比),
    
    `95%预测区间` = case_when(
      is.na(预测区间下限) | is.na(预测区间上限) ~ NA_character_,
      TRUE ~ sprintf(
        "%.3f–%.3f",
        预测区间下限,
        预测区间上限
      )
    ),
    
    异质性评价 = case_when(
      is.na(I2百分比) ~ "无法评估",
      I2百分比 < 25 ~ "低异质性",
      I2百分比 < 50 ~ "低至中度异质性",
      I2百分比 < 75 ~ "中度至较高异质性",
      TRUE ~ "高异质性"
    )
  ) %>%
  select(
    亚组,
    亚组水平,
    纳入国家数,
    合并HR,
    合并CI下限,
    合并CI上限,
    `合并HR（95%CI）`,
    合并P值,
    `合并P值（格式化）`,
    Q统计量,
    Q自由度,
    异质性P值,
    `异质性P值（格式化）`,
    I2百分比,
    `I²`,
    Tau2,
    预测区间下限,
    预测区间上限,
    `95%预测区间`,
    异质性评价,
    Meta结果状态
  )

# =====================================================================
# 23. 创建国家层面 Meta 回归协变量
# =====================================================================
country_meta_covariates <- cohort_characteristics %>%
  transmute(
    国家,
    样本量_国家 = 样本量,
    痴呆事件数_国家 = 痴呆事件数,
    痴呆事件率百分比,
    平均随访时间年,
    平均年龄近似值 = 年龄结构近似均值,
    
    `70岁及以上比例百分比` = `70岁及以上比例百分比`,
    
    高教育水平比例百分比,
    互联网使用率百分比,
    体力活动活跃率百分比,
    糖尿病无高血压比例百分比
  )

# =====================================================================
# 24. 探索性单变量 Meta 回归
# =====================================================================
meta_regression_variables <- c(
  "互联网使用率百分比",
  "体力活动活跃率百分比",
  "平均年龄近似值",
  "70岁及以上比例百分比",
  "高教育水平比例百分比",
  "痴呆事件率百分比",
  "糖尿病无高血压比例百分比",
  "平均随访时间年"
)

run_exploratory_meta_regression <- function(
    subgroup_effect_data,
    moderator_name
) {
  
  regression_data <- subgroup_effect_data %>%
    left_join(
      country_meta_covariates,
      by = c("国家" = "国家")
    ) %>%
    filter(
      !is.na(logHR),
      !is.na(SE_logHR),
      SE_logHR > 0,
      !is.na(.data[[moderator_name]])
    )
  
  n_countries <- nrow(regression_data)
  
  if (n_countries < 4) {
    return(
      tibble(
        协变量 = moderator_name,
        纳入国家数 = n_countries,
        回归系数_logHR = NA_real_,
        回归系数HR比值 = NA_real_,
        回归系数CI下限 = NA_real_,
        回归系数CI上限 = NA_real_,
        回归P值 = NA_real_,
        残余Tau2 = NA_real_,
        残余I2百分比 = NA_real_,
        QM统计量 = NA_real_,
        QM检验P值 = NA_real_,
        Meta回归状态 = "无法分析：有效国家少于4个"
      )
    )
  }
  
  moderator_values <- regression_data[[moderator_name]]
  
  if (length(unique(moderator_values)) < 2) {
    return(
      tibble(
        协变量 = moderator_name,
        纳入国家数 = n_countries,
        回归系数_logHR = NA_real_,
        回归系数HR比值 = NA_real_,
        回归系数CI下限 = NA_real_,
        回归系数CI上限 = NA_real_,
        回归P值 = NA_real_,
        残余Tau2 = NA_real_,
        残余I2百分比 = NA_real_,
        QM统计量 = NA_real_,
        QM检验P值 = NA_real_,
        Meta回归状态 = "无法分析：协变量无变异"
      )
    )
  }
  
  meta_reg_fit <- tryCatch(
    metafor::rma.uni(
      yi = regression_data$logHR,
      sei = regression_data$SE_logHR,
      mods = moderator_values,
      method = "REML"
    ),
    error = function(e) NULL
  )
  
  if (is.null(meta_reg_fit)) {
    return(
      tibble(
        协变量 = moderator_name,
        纳入国家数 = n_countries,
        回归系数_logHR = NA_real_,
        回归系数HR比值 = NA_real_,
        回归系数CI下限 = NA_real_,
        回归系数CI上限 = NA_real_,
        回归P值 = NA_real_,
        残余Tau2 = NA_real_,
        残余I2百分比 = NA_real_,
        QM统计量 = NA_real_,
        QM检验P值 = NA_real_,
        Meta回归状态 = "无法分析：Meta回归模型拟合失败"
      )
    )
  }
  
  coefficient_index <- 2L
  
  tibble(
    协变量 = moderator_name,
    纳入国家数 = n_countries,
    回归系数_logHR = meta_reg_fit$b[coefficient_index, 1],
    回归系数HR比值 = exp(meta_reg_fit$b[coefficient_index, 1]),
    回归系数CI下限 = exp(meta_reg_fit$ci.lb[coefficient_index]),
    回归系数CI上限 = exp(meta_reg_fit$ci.ub[coefficient_index]),
    回归P值 = meta_reg_fit$pval[coefficient_index],
    残余Tau2 = meta_reg_fit$tau2,
    残余I2百分比 = meta_reg_fit$I2,
    QM统计量 = meta_reg_fit$QM,
    QM检验P值 = meta_reg_fit$QMp,
    Meta回归状态 = "探索性分析完成"
  )
}

meta_regression_results <- subgroup_levels_for_meta %>%
  rowwise() %>%
  do({
    
    current_subgroup <- .$亚组
    current_level <- .$亚组水平
    
    current_effect_data <- subgroup_cox_results %>%
      filter(
        亚组 == current_subgroup,
        亚组水平 == current_level
      )
    
    bind_rows(
      lapply(
        meta_regression_variables,
        function(moderator_i) {
          
          run_exploratory_meta_regression(
            subgroup_effect_data = current_effect_data,
            moderator_name = moderator_i
          )
        }
      )
    ) %>%
      mutate(
        亚组 = current_subgroup,
        亚组水平 = current_level,
        .before = 1
      )
  }) %>%
  ungroup() %>%
  mutate(
    `回归系数HR比值（95%CI）` = format_hr_ci(
      回归系数HR比值,
      回归系数CI下限,
      回归系数CI上限
    ),
    
    `回归P值（格式化）` = format_p_value(回归P值),
    `QM检验P值（格式化）` = format_p_value(QM检验P值),
    `残余I²` = format_percent(残余I2百分比)
  ) %>%
  select(
    亚组,
    亚组水平,
    协变量,
    纳入国家数,
    回归系数_logHR,
    回归系数HR比值,
    回归系数CI下限,
    回归系数CI上限,
    `回归系数HR比值（95%CI）`,
    回归P值,
    `回归P值（格式化）`,
    残余Tau2,
    残余I2百分比,
    `残余I²`,
    QM统计量,
    QM检验P值,
    `QM检验P值（格式化）`,
    Meta回归状态
  )

# =====================================================================
# 25. CHARLS 队列重点结果表
# =====================================================================
charls_interpretation_table <- subgroup_precision_results %>%
  filter(国家 == "CHARLS") %>%
  left_join(
    subgroup_meta_prediction_results %>%
      select(
        亚组,
        亚组水平,
        `合并HR（95%CI）`,
        `I²`,
        Tau2,
        `95%预测区间`,
        异质性评价
      ),
    by = c("亚组", "亚组水平")
  ) %>%
  mutate(
    中国队列解释提示 = case_when(
      痴呆事件数 < 10 ~
        "事件数极少；估计可能不稳定，不宜进行实质性解释",
      
      样本量 < 100 ~
        "样本量较少；估计精度有限，需谨慎解释",
      
      CI宽度_logHR尺度 >= 5 ~
        "置信区间极宽；可能存在稀疏数据或近似完全分离",
      
      CI宽度_logHR尺度 >= 3 ~
        "置信区间较宽；估计不稳定，可能受样本量或事件数不足影响",
      
      TRUE ~
        "估计精度相对可接受，但仍需结合异质性指标解释"
    )
  ) %>%
  select(
    亚组,
    亚组水平,
    国家,
    样本量,
    痴呆事件数,
    `HR（95%CI）`,
    `P值（格式化）`,
    CI宽度_HR尺度,
    CI宽度_logHR尺度,
    估计精度评价,
    `合并HR（95%CI）`,
    `I²`,
    Tau2,
    `95%预测区间`,
    异质性评价,
    中国队列解释提示
  )

# =====================================================================
# 26. 导出辅助分析中文 CSV 文件
# =====================================================================
readr::write_excel_csv(
  cohort_characteristics,
  file = "糖尿病-表5_四国队列特征及暴露分布.csv"
)
readr::write_excel_csv(
  subgroup_precision_results,
  file = "糖尿病-表6_各国亚组Cox结果及置信区间宽度.csv"
)
readr::write_excel_csv(
  country_precision_summary,
  file = "糖尿病-表7_各国亚组估计精度汇总.csv"
)
readr::write_excel_csv(
  charls_unstable_subgroups,
  file = "糖尿病-表8_CHARLS队列估计不稳定亚组.csv"
)
readr::write_excel_csv(
  subgroup_meta_prediction_results,
  file = "糖尿病-表9_亚组随机效应Meta分析_含预测区间.csv"
)
readr::write_excel_csv(
  country_meta_covariates,
  file = "糖尿病-表10_Meta回归国家层面协变量.csv"
)
readr::write_excel_csv(
  meta_regression_results,
  file = "糖尿病-表11_探索性单变量Meta回归结果.csv"
)
readr::write_excel_csv(
  charls_interpretation_table,
  file = "糖尿病-表12_CHARLS队列及异质性解释辅助结果.csv"
)

# =====================================================================
# 27. 输出辅助分析关键结果
# =====================================================================
cat("\n====================================================\n")
cat("四国队列特征及暴露分布（排除基线高血压）\n")
cat("====================================================\n")
print(cohort_characteristics, n = Inf)

cat("\n====================================================\n")
cat("CHARLS 队列中估计不稳定的亚组\n")
cat("====================================================\n")
print(charls_unstable_subgroups, n = Inf)

cat("\n====================================================\n")
cat("亚组随机效应 Meta 分析：含 I²、Tau² 和 95%预测区间\n")
cat("====================================================\n")
print(subgroup_meta_prediction_results, n = Inf)

cat("\n====================================================\n")
cat("探索性单变量 Meta 回归结果\n")
cat("说明：仅4个国家队列，结果仅用于探索异质性来源。\n")
cat("====================================================\n")
print(meta_regression_results, n = Inf)

cat("\n====================================================\n")
cat("辅助分析文件导出完成：\n")
cat("1. 糖尿病-表5_四国队列特征及暴露分布.csv\n")
cat("2. 糖尿病-表6_各国亚组Cox结果及置信区间宽度.csv\n")
cat("3. 糖尿病-表7_各国亚组估计精度汇总.csv\n")
cat("4. 糖尿病-表8_CHARLS队列估计不稳定亚组.csv\n")
cat("5. 糖尿病-表9_亚组随机效应Meta分析_含预测区间.csv\n")
cat("6. 糖尿病-表10_Meta回归国家层面协变量.csv\n")
cat("7. 糖尿病-表11_探索性单变量Meta回归结果.csv\n")
cat("8. 糖尿病-表12_CHARLS队列及异质性解释辅助结果.csv\n")
cat("====================================================\n")
cat("\n全部分析完成。\n")
