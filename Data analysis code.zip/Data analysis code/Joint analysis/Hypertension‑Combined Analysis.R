# =====================================================================
# 高血压、体力活动及互联网使用联合分析
# Cox 回归 + Schoenfeld 残差比例风险假设检验 + 随机效应 Meta 分析
#
# 联合暴露：
# 高血压（无高血压/仅高血压） × 体力活动（活跃/不活跃） ×
# 互联网使用（使用/不使用）
#
# 参考组：
# 无高血压 + 活跃 + 使用互联网
#
# 本代码可独立运行：
# 1. 原始数据读取
# 2. 动态基线筛选
# 3. 结局和随访时间计算
# 4. 痴呆事件状态校正
# 5. 联合暴露 Cox 回归
# 6. 比例风险假设检验
# 7. 四国随机效应 Meta 分析
# 8. 中文 CSV 结果导出
# =====================================================================

# =====================================================================
# 0. 环境设置
# =====================================================================

setwd("E:/csl/CSL/database")

library(dplyr)
library(tidyr)
library(haven)
library(survival)
library(broom)
library(meta)
library(readr)
library(tibble)

select <- dplyr::select

# =====================================================================
# 1. 读取原始数据
# =====================================================================

total_data <- read_dta("onlyhyper_data_new.dta") %>%
  mutate(record_id = row_number())

# =====================================================================
# 2. 必要变量检查
# =====================================================================

required_basic_vars <- c(
  "ID", "data_source", "yearsold", "age", "raeduc_c", "ragender"
)

missing_basic_vars <- setdiff(required_basic_vars, names(total_data))

if (length(missing_basic_vars) > 0) {
  stop(
    "数据中缺少以下必要变量：",
    paste(missing_basic_vars, collapse = ", ")
  )
}

# =====================================================================
# 3. 死亡变量处理
# =====================================================================

death_vars <- c(
  "r1death", "r2death", "r3death",
  "r4death", "r5death", "r6death"
)

existing_death_vars <- intersect(death_vars, names(total_data))

if (length(existing_death_vars) > 0) {
  total_data <- total_data %>%
    mutate(
      across(
        all_of(existing_death_vars),
        ~ replace_na(as.numeric(.x), 0)
      )
    )
}

# =====================================================================
# 4. 安全读取变量值函数
# =====================================================================

safe_get_value <- function(data, row_idx, var_name) {
  
  if (!var_name %in% names(data)) {
    return(NA_real_)
  }
  
  value <- data[[var_name]][row_idx]
  
  if (length(value) == 0 || is.null(value) || is.na(value)) {
    return(NA_real_)
  }
  
  suppressWarnings(as.numeric(value))
}

# =====================================================================
# 5. 定义四国队列波次和调查年份
# =====================================================================

get_wave_info <- function(data_source) {
  
  data_source <- as.integer(data_source)
  
  switch(
    as.character(data_source),
    
    "1" = list(
      country = "CHARLS",
      max_wave = 5L,
      wave_years = c(2011, 2013, 2015, 2018, 2020)
    ),
    
    "2" = list(
      country = "HRS",
      max_wave = 6L,
      wave_years = c(2012, 2014, 2016, 2018, 2020, 2022)
    ),
    
    "3" = list(
      country = "SHARE",
      max_wave = 5L,
      wave_years = c(2013, 2015, 2017, 2020, 2022)
    ),
    
    "4" = list(
      country = "ELSA",
      max_wave = 5L,
      wave_years = c(2015, 2017, 2020, 2022, 2024)
    ),
    
    NULL
  )
}

# =====================================================================
# 6. 检查某波次的基线变量列是否存在
# =====================================================================

check_wave_columns <- function(data, wave) {
  
  required_wave_vars <- c(
    paste0("r", wave, "onlyhyper"),
    paste0("r", wave, "phyactivities"),
    paste0("r", wave, "netuse"),
    paste0("r", wave, "dementia"),
    paste0("r", wave, "mstat"),
    paste0("r", wave, "scocwk"),
    paste0("r", wave, "smoking"),
    paste0("r", wave, "Non_com_dis"),
    paste0("r", wave, "drink")
  )
  
  all(required_wave_vars %in% names(data))
}

# =====================================================================
# 7. 获取指定个体、指定波次的基线变量
# =====================================================================

get_baseline_variables <- function(data, i, wave) {
  
  list(
    onlyhyper = safe_get_value(data, i, paste0("r", wave, "onlyhyper")),
    phyactivities = safe_get_value(data, i, paste0("r", wave, "phyactivities")),
    netuse = safe_get_value(data, i, paste0("r", wave, "netuse")),
    dementia = safe_get_value(data, i, paste0("r", wave, "dementia")),
    mstat = safe_get_value(data, i, paste0("r", wave, "mstat")),
    scocwk = safe_get_value(data, i, paste0("r", wave, "scocwk")),
    smoking = safe_get_value(data, i, paste0("r", wave, "smoking")),
    Non_com_dis = safe_get_value(data, i, paste0("r", wave, "Non_com_dis")),
    drink = safe_get_value(data, i, paste0("r", wave, "drink"))
  )
}

# =====================================================================
# 8. 判断基线后是否至少有一次有效痴呆随访
# =====================================================================

has_followup_dementia_data <- function(data, i, enrollment_wave, max_wave) {
  
  if (is.na(enrollment_wave) || enrollment_wave >= max_wave) {
    return(FALSE)
  }
  
  future_waves <- seq.int(enrollment_wave + 1L, max_wave)
  
  future_dementia <- vapply(
    future_waves,
    function(wave) {
      safe_get_value(data, i, paste0("r", wave, "dementia"))
    },
    numeric(1)
  )
  
  any(!is.na(future_dementia))
}

# =====================================================================
# 9. 动态基线筛选
# =====================================================================

filter_data_by_conditions_modified <- function(data) {
  
  data <- data %>%
    mutate(
      enrollment_wave = NA_integer_,
      screening_status = NA_character_,
      country = case_when(
        data_source == 1 ~ "CHARLS",
        data_source == 2 ~ "HRS",
        data_source == 3 ~ "SHARE",
        data_source == 4 ~ "ELSA",
        TRUE ~ "Unknown"
      )
    )
  
  for (i in seq_len(nrow(data))) {
    
    source_i <- safe_get_value(data, i, "data_source")
    wave_info <- get_wave_info(source_i)
    
    if (is.null(wave_info)) {
      data$screening_status[i] <- "排除：未知数据来源"
      next
    }
    
    if (is.na(data$age[i]) || data$age[i] < 50) {
      data$screening_status[i] <- "排除：年龄<50岁或年龄缺失"
      next
    }
    
    max_wave_i <- wave_info$max_wave
    
    has_any_core_baseline <- FALSE
    has_non_dementia_baseline <- FALSE
    has_complete_covariate_baseline <- FALSE
    has_followup_data <- FALSE
    enrollment_found <- FALSE
    
    # 最后一波没有后续随访，故不可以作为基线
    for (wave in seq_len(max_wave_i - 1L)) {
      
      if (!check_wave_columns(data, wave)) {
        next
      }
      
      baseline_var <- get_baseline_variables(data, i, wave)
      
      core_exposure_vars <- c(
        baseline_var$onlyhyper,
        baseline_var$phyactivities,
        baseline_var$netuse
      )
      
      # 高血压、体力活动或互联网变量缺失
      if (any(is.na(core_exposure_vars))) {
        next
      }
      
      has_any_core_baseline <- TRUE
      
      # 基线存在痴呆者排除
      if (is.na(baseline_var$dementia) || baseline_var$dementia == 1) {
        next
      }
      
      has_non_dementia_baseline <- TRUE
      
      # 基线协变量完整性检查
      all_baseline_vars <- c(
        baseline_var$onlyhyper,
        baseline_var$phyactivities,
        baseline_var$netuse,
        baseline_var$dementia,
        baseline_var$mstat,
        baseline_var$scocwk,
        baseline_var$smoking,
        baseline_var$Non_com_dis,
        baseline_var$drink,
        data$yearsold[i],
        data$raeduc_c[i],
        data$ragender[i]
      )
      
      if (any(is.na(all_baseline_vars))) {
        next
      }
      
      has_complete_covariate_baseline <- TRUE
      
      # 基线后至少一次有效痴呆随访
      if (!has_followup_dementia_data(data, i, wave, max_wave_i)) {
        next
      }
      
      has_followup_data <- TRUE
      
      # 选择最早满足全部要求的波次作为动态基线
      data$enrollment_wave[i] <- wave
      data$screening_status[i] <- "纳入最终分析"
      enrollment_found <- TRUE
      
      break
    }
    
    if (!enrollment_found) {
      
      if (!has_any_core_baseline) {
        
        data$screening_status[i] <-
          "排除：基线高血压/体力活动/互联网使用信息缺失"
        
      } else if (!has_non_dementia_baseline) {
        
        data$screening_status[i] <-
          "排除：基线痴呆或阿尔茨海默病"
        
      } else if (!has_complete_covariate_baseline) {
        
        data$screening_status[i] <-
          "排除：基线痴呆或协变量数据缺失"
        
      } else if (!has_followup_data) {
        
        data$screening_status[i] <-
          "排除：Wave 1至Wave 5/6随访痴呆数据缺失"
        
      } else {
        
        data$screening_status[i] <- "排除：其他原因"
      }
    }
  }
  
  data
}

# =====================================================================
# 10. 执行动态基线筛选
# =====================================================================

screened_data <- filter_data_by_conditions_modified(total_data)

data_In <- screened_data %>%
  filter(screening_status == "纳入最终分析")

# =====================================================================
# 11. 提取动态基线变量、随访时间和初步痴呆结局
# =====================================================================

extract_baseline_covs_fixed <- function(data) {
  
  baseline_vars <- c(
    "baseline_onlyhyper",
    "baseline_dementia_status",
    "baseline_phyactivities",
    "baseline_netuse",
    "baseline_mstat",
    "baseline_scocwk",
    "baseline_smoking",
    "baseline_drink",
    "baseline_Non_com_dis",
    "baseline_year",
    "last_followup_year",
    "time_to_event",
    "event_status"
  )
  
  data[baseline_vars] <- NA_real_
  
  for (i in seq_len(nrow(data))) {
    
    source_i <- safe_get_value(data, i, "data_source")
    wave_i <- safe_get_value(data, i, "enrollment_wave")
    wave_info <- get_wave_info(source_i)
    
    if (is.null(wave_info) || is.na(wave_i)) {
      next
    }
    
    wave_i <- as.integer(wave_i)
    max_wave_i <- wave_info$max_wave
    wave_years_i <- wave_info$wave_years
    
    baseline_year_i <- wave_years_i[wave_i]
    
    data$baseline_onlyhyper[i] <-
      safe_get_value(data, i, paste0("r", wave_i, "onlyhyper"))
    
    data$baseline_dementia_status[i] <-
      safe_get_value(data, i, paste0("r", wave_i, "dementia"))
    
    data$baseline_phyactivities[i] <-
      safe_get_value(data, i, paste0("r", wave_i, "phyactivities"))
    
    data$baseline_netuse[i] <-
      safe_get_value(data, i, paste0("r", wave_i, "netuse"))
    
    data$baseline_mstat[i] <-
      safe_get_value(data, i, paste0("r", wave_i, "mstat"))
    
    data$baseline_scocwk[i] <-
      safe_get_value(data, i, paste0("r", wave_i, "scocwk"))
    
    data$baseline_smoking[i] <-
      safe_get_value(data, i, paste0("r", wave_i, "smoking"))
    
    data$baseline_drink[i] <-
      safe_get_value(data, i, paste0("r", wave_i, "drink"))
    
    data$baseline_Non_com_dis[i] <-
      safe_get_value(data, i, paste0("r", wave_i, "Non_com_dis"))
    
    data$baseline_year[i] <- baseline_year_i
    
    onset_year <- NA_real_
    last_followup_year_i <- baseline_year_i
    event_i <- 0L
    
    future_waves <- seq.int(wave_i + 1L, max_wave_i)
    
    for (future_wave in future_waves) {
      
      dementia_i <- safe_get_value(
        data,
        i,
        paste0("r", future_wave, "dementia")
      )
      
      current_year_i <- wave_years_i[future_wave]
      
      if (!is.na(dementia_i)) {
        
        last_followup_year_i <- current_year_i
        
        if (dementia_i == 1 && is.na(onset_year)) {
          onset_year <- current_year_i
          event_i <- 1L
          break
        }
      }
    }
    
    data$last_followup_year[i] <- last_followup_year_i
    data$event_status[i] <- event_i
    
    if (event_i == 1L) {
      data$time_to_event[i] <- onset_year - baseline_year_i
    } else {
      data$time_to_event[i] <- last_followup_year_i - baseline_year_i
    }
  }
  
  data %>%
    select(
      record_id,
      ID,
      country,
      data_source,
      enrollment_wave,
      baseline_year,
      last_followup_year,
      yearsold,
      age,
      raeduc_c,
      ragender,
      baseline_onlyhyper,
      baseline_dementia_status,
      baseline_phyactivities,
      baseline_netuse,
      baseline_mstat,
      baseline_scocwk,
      baseline_smoking,
      baseline_drink,
      baseline_Non_com_dis,
      time_to_event,
      event_status,
      any_of(death_vars)
    ) %>%
    filter(
      baseline_dementia_status == 0,
      !is.na(baseline_onlyhyper),
      !is.na(yearsold),
      !is.na(age),
      !is.na(raeduc_c),
      !is.na(ragender),
      !is.na(baseline_phyactivities),
      !is.na(baseline_netuse),
      !is.na(baseline_mstat),
      !is.na(baseline_scocwk),
      !is.na(baseline_smoking),
      !is.na(baseline_drink),
      !is.na(baseline_Non_com_dis),
      !is.na(time_to_event),
      time_to_event > 0
    ) %>%
    mutate(
      country = factor(
        country,
        levels = c("CHARLS", "HRS", "SHARE", "ELSA")
      ),
      
      raeduc_c = factor(
        raeduc_c,
        levels = c(1, 2, 3),
        labels = c("初中及以下", "高中", "大学及以上")
      ),
      
      yearsold = factor(
        yearsold,
        levels = c(1, 2, 3, 4),
        labels = c("60岁以下", "60-69岁", "70-79岁", "80岁及以上")
      ),
      
      ragender = factor(
        ragender,
        levels = c(1, 2),
        labels = c("男", "女")
      ),
      
      baseline_onlyhyper = factor(
        baseline_onlyhyper,
        levels = c(0, 1),
        labels = c("无高血压", "仅高血压")
      ),
      
      baseline_phyactivities = factor(
        baseline_phyactivities,
        levels = c(0, 1),
        labels = c("不活跃", "活跃")
      ),
      
      baseline_netuse = factor(
        baseline_netuse,
        levels = c(0, 1),
        labels = c("不使用", "使用")
      ),
      
      baseline_mstat = factor(
        baseline_mstat,
        levels = c(1, 2),
        labels = c("已婚/同居", "单身")
      ),
      
      baseline_scocwk = factor(
        baseline_scocwk,
        levels = c(0, 1),
        labels = c("不活跃", "活跃")
      ),
      
      baseline_smoking = factor(
        baseline_smoking,
        levels = c(0, 1, 2),
        labels = c("戒烟", "吸烟", "从未吸烟")
      ),
      
      baseline_drink = factor(
        baseline_drink,
        levels = c(0, 1),
        labels = c("从未饮酒", "饮过酒")
      ),
      
      baseline_Non_com_dis = factor(
        baseline_Non_com_dis,
        levels = c(0, 1),
        labels = c("无", "有")
      )
    )
}

# =====================================================================
# 12. 校正痴呆事件状态和随访时间
# =====================================================================
#
# 规则：
# 如果首次痴呆阳性后，下一次有效观测为痴呆阴性，
# 则该首次阳性不视为真实痴呆事件。
# 此时以最后一次有效痴呆观测时间作为删失时间。
# =====================================================================

correct_event_status <- function(data, origin_data) {
  
  dem_vars <- paste0("r", 1:6, "dementia")
  existing_dem_vars <- intersect(dem_vars, names(origin_data))
  
  origin_data_sub <- origin_data %>%
    select(record_id, any_of(existing_dem_vars))
  
  data_correct <- data %>%
    left_join(origin_data_sub, by = "record_id")
  
  for (i in seq_len(nrow(data_correct))) {
    
    wave_i <- safe_get_value(data_correct, i, "enrollment_wave")
    source_i <- safe_get_value(data_correct, i, "data_source")
    wave_info <- get_wave_info(source_i)
    
    if (is.null(wave_info) || is.na(wave_i)) {
      data_correct$event_status[i] <- 0L
      data_correct$time_to_event[i] <- NA_real_
      next
    }
    
    wave_i <- as.integer(wave_i)
    max_wave_i <- wave_info$max_wave
    wave_years_i <- wave_info$wave_years
    baseline_year_i <- wave_years_i[wave_i]
    
    if (wave_i >= max_wave_i) {
      data_correct$event_status[i] <- 0L
      data_correct$time_to_event[i] <- NA_real_
      next
    }
    
    future_waves <- seq.int(wave_i + 1L, max_wave_i)
    
    future_dem <- vapply(
      future_waves,
      function(wave) {
        safe_get_value(
          data_correct,
          i,
          paste0("r", wave, "dementia")
        )
      },
      numeric(1)
    )
    
    valid_index <- which(!is.na(future_dem))
    
    if (length(valid_index) == 0) {
      data_correct$event_status[i] <- 0L
      data_correct$time_to_event[i] <- NA_real_
      next
    }
    
    valid_dem <- future_dem[valid_index]
    valid_waves <- future_waves[valid_index]
    
    last_followup_wave <- tail(valid_waves, 1)
    last_followup_year_i <- wave_years_i[last_followup_wave]
    
    data_correct$last_followup_year[i] <- last_followup_year_i
    
    real_event <- 0L
    onset_year_i <- NA_real_
    
    first_positive_position <- which(valid_dem == 1)[1]
    
    if (!is.na(first_positive_position)) {
      
      first_positive_wave <- valid_waves[first_positive_position]
      first_positive_year <- wave_years_i[first_positive_wave]
      
      # 首次阳性不是最后一次有效随访时，检查紧接的下一次有效随访
      if (first_positive_position < length(valid_dem)) {
        
        next_valid_dementia <- valid_dem[first_positive_position + 1L]
        
        # 若下一个有效观测不是阴性，则判为真实事件
        if (next_valid_dementia != 0) {
          real_event <- 1L
          onset_year_i <- first_positive_year
        }
        
      } else {
        # 首次阳性为最后一次有效观测时，判定为痴呆事件
        real_event <- 1L
        onset_year_i <- first_positive_year
      }
    }
    
    data_correct$event_status[i] <- real_event
    
    if (real_event == 1L) {
      data_correct$time_to_event[i] <- onset_year_i - baseline_year_i
    } else {
      data_correct$time_to_event[i] <- last_followup_year_i - baseline_year_i
    }
  }
  
  data_correct %>%
    select(-any_of(existing_dem_vars)) %>%
    filter(
      !is.na(time_to_event),
      time_to_event > 0
    )
}

# =====================================================================
# 13. 构建最终联合分析数据
# =====================================================================

cox_data_clean <- extract_baseline_covs_fixed(data_In)

cox_data_final <- correct_event_status(
  data = cox_data_clean,
  origin_data = data_In
)

# =====================================================================
# 14. 输出与主分析一致性有关的样本量信息
# =====================================================================

n_all_participants <- nrow(total_data)
n_after_screening <- nrow(data_In)
n_final_analysis <- nrow(cox_data_final)

flow_order <- c(
  "纳入最终分析",
  "排除：年龄<50岁或年龄缺失",
  "排除：基线高血压/体力活动/互联网使用信息缺失",
  "排除：基线痴呆或阿尔茨海默病",
  "排除：基线痴呆或协变量数据缺失",
  "排除：Wave 1至Wave 5/6随访痴呆数据缺失",
  "排除：其他原因",
  "排除：未知数据来源"
)

flow_table <- screened_data %>%
  count(screening_status, name = "人数") %>%
  mutate(
    总体百分比 = round(人数 / n_all_participants * 100, 2),
    screening_status = factor(screening_status, levels = flow_order)
  ) %>%
  arrange(screening_status) %>%
  rename(筛选状态 = screening_status)

final_sample_by_country <- cox_data_final %>%
  group_by(country) %>%
  summarise(
    样本量 = n(),
    痴呆事件数 = sum(event_status == 1, na.rm = TRUE),
    非痴呆事件数 = sum(event_status == 0, na.rm = TRUE),
    平均随访时间_年 = mean(time_to_event, na.rm = TRUE),
    中位随访时间_年 = median(time_to_event, na.rm = TRUE),
    .groups = "drop"
  ) %>%
  rename(国家 = country)

final_sample_overall <- cox_data_final %>%
  summarise(
    国家 = "总体（四国合并）",
    样本量 = n(),
    痴呆事件数 = sum(event_status == 1, na.rm = TRUE),
    非痴呆事件数 = sum(event_status == 0, na.rm = TRUE),
    平均随访时间_年 = mean(time_to_event, na.rm = TRUE),
    中位随访时间_年 = median(time_to_event, na.rm = TRUE)
  )

final_sample_table <- bind_rows(
  final_sample_by_country,
  final_sample_overall
)

cat("\n====================================================\n")
cat("联合分析最终样本量\n")
cat("====================================================\n")
cat("原始总样本量：", n_all_participants, "\n")
cat("动态基线筛选后样本量：", n_after_screening, "\n")
cat("结局校正后最终样本量：", n_final_analysis, "\n")
print(final_sample_table)

# =====================================================================
# 15. 构建高血压 × 体力活动 × 互联网使用联合暴露
# =====================================================================
#
# 使用英文编码作为模型变量水平，以避免中文因子名称在模型结果中
# 可能引起识别困难；最终导出时转换为中文标签。
# =====================================================================

joint_level_map <- tibble(
  联合组编码 = c(
    "N_Active_Internet",
    "N_Active_NoInternet",
    "N_Inactive_Internet",
    "N_Inactive_NoInternet",
    "C_Active_Internet",
    "C_Active_NoInternet",
    "C_Inactive_Internet",
    "C_Inactive_NoInternet"
  ),
  
  高血压状态 = c(
    "无高血压", "无高血压", "无高血压", "无高血压",
    "仅高血压", "仅高血压", "仅高血压", "仅高血压"
  ),
  
  体力活动 = c(
    "活跃", "活跃", "不活跃", "不活跃",
    "活跃", "活跃", "不活跃", "不活跃"
  ),
  
  互联网使用 = c(
    "使用", "不使用", "使用", "不使用",
    "使用", "不使用", "使用", "不使用"
  ),
  
  联合暴露组 = c(
    "无高血压 + 活跃 + 使用互联网",
    "无高血压 + 活跃 + 不使用互联网",
    "无高血压 + 不活跃 + 使用互联网",
    "无高血压 + 不活跃 + 不使用互联网",
    "仅高血压 + 活跃 + 使用互联网",
    "仅高血压 + 活跃 + 不使用互联网",
    "仅高血压 + 不活跃 + 使用互联网",
    "仅高血压 + 不活跃 + 不使用互联网"
  ),
  
  是否参考组 = c(
    "是", "否", "否", "否",
    "否", "否", "否", "否"
  )
)

joint_levels <- joint_level_map$联合组编码

joint_cox_data <- cox_data_final %>%
  mutate(
    联合组编码 = case_when(
      
      baseline_onlyhyper == "无高血压" &
        baseline_phyactivities == "活跃" &
        baseline_netuse == "使用" ~ "N_Active_Internet",
      
      baseline_onlyhyper == "无高血压" &
        baseline_phyactivities == "活跃" &
        baseline_netuse == "不使用" ~ "N_Active_NoInternet",
      
      baseline_onlyhyper == "无高血压" &
        baseline_phyactivities == "不活跃" &
        baseline_netuse == "使用" ~ "N_Inactive_Internet",
      
      baseline_onlyhyper == "无高血压" &
        baseline_phyactivities == "不活跃" &
        baseline_netuse == "不使用" ~ "N_Inactive_NoInternet",
      
      baseline_onlyhyper == "仅高血压" &
        baseline_phyactivities == "活跃" &
        baseline_netuse == "使用" ~ "C_Active_Internet",
      
      baseline_onlyhyper == "仅高血压" &
        baseline_phyactivities == "活跃" &
        baseline_netuse == "不使用" ~ "C_Active_NoInternet",
      
      baseline_onlyhyper == "仅高血压" &
        baseline_phyactivities == "不活跃" &
        baseline_netuse == "使用" ~ "C_Inactive_Internet",
      
      baseline_onlyhyper == "仅高血压" &
        baseline_phyactivities == "不活跃" &
        baseline_netuse == "不使用" ~ "C_Inactive_NoInternet",
      
      TRUE ~ NA_character_
    ),
    
    联合组编码 = factor(
      联合组编码,
      levels = joint_levels
    )
  ) %>%
  left_join(
    joint_level_map %>%
      select(联合组编码, 联合暴露组, 是否参考组),
    by = "联合组编码"
  )

if (any(is.na(joint_cox_data$联合组编码))) {
  stop("存在无法归入八个联合暴露组的研究对象，请检查高血压、体力活动和互联网变量编码。")
}

# =====================================================================
# 16. 联合组样本量、事件数和随访时间
# =====================================================================

joint_sample_by_country <- joint_cox_data %>%
  mutate(国家 = as.character(country)) %>%
  group_by(国家, 联合组编码, 联合暴露组, 是否参考组) %>%
  summarise(
    样本量 = n(),
    痴呆事件数 = sum(event_status == 1, na.rm = TRUE),
    非事件数 = sum(event_status == 0, na.rm = TRUE),
    平均随访时间_年 = mean(time_to_event, na.rm = TRUE),
    中位随访时间_年 = median(time_to_event, na.rm = TRUE),
    .groups = "drop"
  ) %>%
  arrange(国家, 联合组编码)

joint_sample_overall <- joint_cox_data %>%
  group_by(联合组编码, 联合暴露组, 是否参考组) %>%
  summarise(
    样本量 = n(),
    痴呆事件数 = sum(event_status == 1, na.rm = TRUE),
    非事件数 = sum(event_status == 0, na.rm = TRUE),
    平均随访时间_年 = mean(time_to_event, na.rm = TRUE),
    中位随访时间_年 = median(time_to_event, na.rm = TRUE),
    .groups = "drop"
  ) %>%
  mutate(国家 = "总体（四国合并）") %>%
  select(
    国家, 联合组编码, 联合暴露组, 是否参考组,
    样本量, 痴呆事件数, 非事件数,
    平均随访时间_年, 中位随访时间_年
  )

joint_sample_table <- bind_rows(
  joint_sample_by_country,
  joint_sample_overall
)

# =====================================================================
# 17. 联合分析 Cox 回归模型
# =====================================================================
#
# 不纳入 baseline_onlyhyper、baseline_phyactivities、baseline_netuse，
# 因为它们已被“联合组编码”替代。
# =====================================================================

joint_cox_formula <- Surv(time_to_event, event_status) ~
  联合组编码 +
  yearsold +
  ragender +
  raeduc_c +
  baseline_mstat +
  baseline_scocwk +
  baseline_smoking +
  baseline_drink +
  baseline_Non_com_dis

# =====================================================================
# 18. 分国家联合 Cox 回归函数
# =====================================================================

empty_joint_cox_result <- function(country_name, group_code) {
  
  tibble(
    国家 = country_name,
    联合组编码 = group_code,
    HR = NA_real_,
    CI下限 = NA_real_,
    CI上限 = NA_real_,
    P值 = NA_real_,
    logHR = NA_real_,
    logHR标准误 = NA_real_,
    模型状态 = "无法估计"
  )
}

run_joint_cox_by_country <- function(dt, country_name) {
  
  all_groups <- tibble(
    联合组编码 = joint_levels
  )
  
  group_count <- dt %>%
    mutate(联合组编码 = as.character(联合组编码)) %>%
    group_by(联合组编码) %>%
    summarise(
      样本量 = n(),
      痴呆事件数 = sum(event_status == 1, na.rm = TRUE),
      .groups = "drop"
    )
  
  base_result <- all_groups %>%
    left_join(group_count, by = "联合组编码") %>%
    mutate(
      国家 = country_name,
      样本量 = replace_na(样本量, 0L),
      痴呆事件数 = replace_na(痴呆事件数, 0L)
    )
  
  n_total <- nrow(dt)
  n_events <- sum(dt$event_status == 1, na.rm = TRUE)
  
  if (n_total == 0 || n_events == 0) {
    
    return(
      base_result %>%
        mutate(
          HR = NA_real_,
          CI下限 = NA_real_,
          CI上限 = NA_real_,
          P值 = NA_real_,
          logHR = NA_real_,
          logHR标准误 = NA_real_,
          模型状态 = "无样本或无痴呆事件"
        )
    )
  }
  
  dt <- dt %>%
    mutate(
      联合组编码 = factor(
        联合组编码,
        levels = joint_levels
      )
    ) %>%
    droplevels()
  
  cox_model <- tryCatch(
    coxph(
      formula = joint_cox_formula,
      data = dt,
      x = TRUE
    ),
    error = function(e) NULL
  )
  
  if (is.null(cox_model)) {
    
    return(
      base_result %>%
        mutate(
          HR = NA_real_,
          CI下限 = NA_real_,
          CI上限 = NA_real_,
          P值 = NA_real_,
          logHR = NA_real_,
          logHR标准误 = NA_real_,
          模型状态 = "Cox模型拟合失败"
        )
    )
  }
  
  model_result <- broom::tidy(
    cox_model,
    conf.int = TRUE,
    exponentiate = TRUE
  ) %>%
    filter(grepl("^联合组编码", term)) %>%
    transmute(
      联合组编码 = sub("^联合组编码", "", term),
      HR = estimate,
      CI下限 = conf.low,
      CI上限 = conf.high,
      P值 = p.value,
      logHR = log(estimate),
      logHR标准误 = (
        log(conf.high) - log(conf.low)
      ) / (2 * qnorm(0.975)),
      模型状态 = "成功估计"
    )
  
  # 补充参考组
  reference_result <- tibble(
    联合组编码 = "N_Active_Internet",
    HR = 1,
    CI下限 = 1,
    CI上限 = 1,
    P值 = NA_real_,
    logHR = 0,
    logHR标准误 = NA_real_,
    模型状态 = "参考组"
  )
  
  model_result <- bind_rows(
    reference_result,
    model_result
  )
  
  base_result %>%
    left_join(model_result, by = "联合组编码") %>%
    mutate(
      模型状态 = case_when(
        联合组编码 == "N_Active_Internet" ~ "参考组",
        样本量 == 0 ~ "该联合组无样本",
        痴呆事件数 == 0 ~ "该联合组无痴呆事件或无法估计",
        is.na(HR) ~ "无法估计",
        TRUE ~ 模型状态
      )
    ) %>%
    select(
      国家, 联合组编码, 样本量, 痴呆事件数,
      HR, CI下限, CI上限, P值,
      logHR, logHR标准误, 模型状态
    )
}

# =====================================================================
# 19. 四国分别运行联合 Cox 回归
# =====================================================================

joint_cox_results <- bind_rows(
  run_joint_cox_by_country(
    joint_cox_data %>% filter(country == "CHARLS"),
    "CHARLS"
  ),
  
  run_joint_cox_by_country(
    joint_cox_data %>% filter(country == "HRS"),
    "HRS"
  ),
  
  run_joint_cox_by_country(
    joint_cox_data %>% filter(country == "SHARE"),
    "SHARE"
  ),
  
  run_joint_cox_by_country(
    joint_cox_data %>% filter(country == "ELSA"),
    "ELSA"
  )
) %>%
  left_join(joint_level_map, by = "联合组编码") %>%
  mutate(
    HR及95CI = case_when(
      是否参考组 == "是" ~ "Reference",
      is.na(HR) ~ NA_character_,
      TRUE ~ sprintf("%.3f (%.3f–%.3f)", HR, CI下限, CI上限)
    ),
    
    P值显示 = case_when(
      是否参考组 == "是" ~ NA_character_,
      is.na(P值) ~ NA_character_,
      P值 < 0.001 ~ "<0.001",
      TRUE ~ sprintf("%.3f", P值)
    )
  ) %>%
  select(
    国家,
    联合组编码,
    联合暴露组,
    高血压状态,
    体力活动,
    互联网使用,
    是否参考组,
    样本量,
    痴呆事件数,
    HR,
    CI下限,
    CI上限,
    HR及95CI,
    P值,
    P值显示,
    logHR,
    logHR标准误,
    模型状态
  ) %>%
  arrange(国家, 联合组编码)

cat("\n====================================================\n")
cat("四国联合暴露多变量 Cox 回归结果\n")
cat("参考组：无高血压 + 活跃 + 使用互联网\n")
cat("====================================================\n")
print(joint_cox_results, digits = 4)

# =====================================================================
# 20. 构建适合绘图/热图展示的宽格式 Cox 结果
# =====================================================================

joint_cox_results_wide <- joint_cox_results %>%
  select(
    国家,
    联合暴露组,
    HR及95CI
  ) %>%
  pivot_wider(
    names_from = 国家,
    values_from = HR及95CI
  )

# 调整展示顺序：四国结果按 CHARLS、HRS、SHARE、ELSA 排列
country_column_order <- c(
  "联合暴露组",
  "CHARLS",
  "HRS",
  "SHARE",
  "ELSA"
)

joint_cox_results_wide <- joint_cox_results_wide %>%
  select(any_of(country_column_order))

# =====================================================================
# 21. Schoenfeld 残差比例风险假设检验
# =====================================================================

empty_joint_ph_result <- function(country_name, message) {
  
  tibble(
    国家 = country_name,
    变量 = NA_character_,
    rho = NA_real_,
    卡方值 = NA_real_,
    P值 = NA_real_,
    PH假设结论 = message
  )
}

test_joint_ph_by_country <- function(dt, country_name) {
  
  n_total <- nrow(dt)
  n_events <- sum(dt$event_status == 1, na.rm = TRUE)
  
  if (n_total == 0 || n_events == 0) {
    return(
      empty_joint_ph_result(
        country_name,
        "无法检验：无样本或无痴呆事件"
      )
    )
  }
  
  dt <- dt %>%
    mutate(
      联合组编码 = factor(
        联合组编码,
        levels = joint_levels
      )
    ) %>%
    droplevels()
  
  cox_model <- tryCatch(
    coxph(
      formula = joint_cox_formula,
      data = dt,
      x = TRUE
    ),
    error = function(e) NULL
  )
  
  if (is.null(cox_model)) {
    return(
      empty_joint_ph_result(
        country_name,
        "无法检验：Cox模型拟合失败"
      )
    )
  }
  
  ph_test <- tryCatch(
    cox.zph(cox_model, transform = "km"),
    error = function(e) NULL
  )
  
  if (is.null(ph_test)) {
    return(
      empty_joint_ph_result(
        country_name,
        "无法检验：Schoenfeld残差计算失败"
      )
    )
  }
  
  ph_table <- as.data.frame(ph_test$table) %>%
    rownames_to_column(var = "变量")
  
  if (!"rho" %in% names(ph_table)) {
    ph_table$rho <- NA_real_
  }
  
  if (!"chisq" %in% names(ph_table)) {
    ph_table$chisq <- NA_real_
  }
  
  if (!"p" %in% names(ph_table)) {
    ph_table$p <- NA_real_
  }
  
  ph_table %>%
    transmute(
      国家 = country_name,
      变量 = 变量,
      rho = rho,
      卡方值 = chisq,
      P值 = p,
      PH假设结论 = case_when(
        is.na(P值) ~ "无法判断",
        变量 == "GLOBAL" & P值 >= 0.05 ~ "整体模型满足比例风险假设",
        变量 == "GLOBAL" & P值 < 0.05 ~ "整体模型可能违反比例风险假设",
        P值 >= 0.05 ~ "未发现违反比例风险假设的证据",
        P值 < 0.05 ~ "可能违反比例风险假设"
      )
    )
}

joint_ph_results <- bind_rows(
  test_joint_ph_by_country(
    joint_cox_data %>% filter(country == "CHARLS"),
    "CHARLS"
  ),
  
  test_joint_ph_by_country(
    joint_cox_data %>% filter(country == "HRS"),
    "HRS"
  ),
  
  test_joint_ph_by_country(
    joint_cox_data %>% filter(country == "SHARE"),
    "SHARE"
  ),
  
  test_joint_ph_by_country(
    joint_cox_data %>% filter(country == "ELSA"),
    "ELSA"
  )
) %>%
  mutate(
    P值显示 = case_when(
      is.na(P值) ~ NA_character_,
      P值 < 0.001 ~ "<0.001",
      TRUE ~ sprintf("%.3f", P值)
    )
  )

joint_ph_global_results <- joint_ph_results %>%
  filter(变量 == "GLOBAL")

cat("\n====================================================\n")
cat("联合 Cox 模型 Schoenfeld 残差比例风险假设检验\n")
cat("====================================================\n")
print(joint_ph_results, digits = 4)

# =====================================================================
# 22. 对每一个非参考联合组进行随机效应 Meta 分析
# =====================================================================
#
# 每一个联合组均以：
# 无高血压 + 活跃 + 使用互联网
# 为统一参考组。
# =====================================================================

run_meta_for_joint_group <- function(group_code, group_name) {
  
  meta_dat <- joint_cox_results %>%
    filter(
      联合组编码 == group_code,
      是否参考组 == "否",
      !is.na(logHR),
      !is.na(logHR标准误),
      is.finite(logHR),
      is.finite(logHR标准误),
      logHR标准误 > 0
    )
  
  # 少于两国有可估计效应量时，不进行 Meta 分析
  if (nrow(meta_dat) < 2) {
    
    return(
      tibble(
        联合组编码 = group_code,
        联合暴露组 = group_name,
        纳入Meta国家数 = nrow(meta_dat),
        合并HR = NA_real_,
        合并CI下限 = NA_real_,
        合并CI上限 = NA_real_,
        合并P值 = NA_real_,
        Q值 = NA_real_,
        Q自由度 = NA_real_,
        异质性P值 = NA_real_,
        I2 = NA_real_,
        I2百分比 = NA_real_,
        Tau = NA_real_,
        Tau2 = NA_real_,
        Meta分析状态 = "可用于Meta分析的国家少于2个"
      )
    )
  }
  
  meta_model <- tryCatch(
    metagen(
      TE = logHR,
      seTE = logHR标准误,
      studlab = 国家,
      data = meta_dat,
      sm = "HR",
      common = FALSE,
      random = TRUE,
      method.tau = "REML",
      hakn = FALSE,
      title = group_name
    ),
    error = function(e) NULL
  )
  
  if (is.null(meta_model)) {
    
    return(
      tibble(
        联合组编码 = group_code,
        联合暴露组 = group_name,
        纳入Meta国家数 = nrow(meta_dat),
        合并HR = NA_real_,
        合并CI下限 = NA_real_,
        合并CI上限 = NA_real_,
        合并P值 = NA_real_,
        Q值 = NA_real_,
        Q自由度 = NA_real_,
        异质性P值 = NA_real_,
        I2 = NA_real_,
        I2百分比 = NA_real_,
        Tau = NA_real_,
        Tau2 = NA_real_,
        Meta分析状态 = "随机效应Meta模型拟合失败"
      )
    )
  }
  
  tibble(
    联合组编码 = group_code,
    联合暴露组 = group_name,
    纳入Meta国家数 = nrow(meta_dat),
    
    合并HR = exp(meta_model$TE.random),
    合并CI下限 = exp(meta_model$lower.random),
    合并CI上限 = exp(meta_model$upper.random),
    合并P值 = meta_model$pval.random,
    
    Q值 = meta_model$Q,
    Q自由度 = meta_model$df.Q,
    异质性P值 = meta_model$pval.Q,
    
    I2 = meta_model$I2,
    I2百分比 = meta_model$I2 * 100,
    
    Tau = meta_model$tau,
    Tau2 = meta_model$tau^2,
    
    Meta分析状态 = "成功估计"
  )
}

meta_joint_results <- joint_level_map %>%
  filter(是否参考组 == "否") %>%
  rowwise() %>%
  do(
    run_meta_for_joint_group(
      group_code = .$联合组编码,
      group_name = .$联合暴露组
    )
  ) %>%
  ungroup() %>%
  mutate(
    合并HR及95CI = case_when(
      is.na(合并HR) ~ NA_character_,
      TRUE ~ sprintf("%.3f (%.3f–%.3f)", 合并HR, 合并CI下限, 合并CI上限)
    ),
    
    合并P值显示 = case_when(
      is.na(合并P值) ~ NA_character_,
      合并P值 < 0.001 ~ "<0.001",
      TRUE ~ sprintf("%.3f", 合并P值)
    ),
    
    异质性P值显示 = case_when(
      is.na(异质性P值) ~ NA_character_,
      异质性P值 < 0.001 ~ "<0.001",
      TRUE ~ sprintf("%.3f", 异质性P值)
    ),
    
    I2显示 = case_when(
      is.na(I2百分比) ~ NA_character_,
      TRUE ~ paste0(round(I2百分比, 1), "%")
    )
  ) %>%
  left_join(
    joint_level_map %>%
      select(联合组编码, 高血压状态, 体力活动, 互联网使用),
    by = "联合组编码"
  ) %>%
  select(
    联合组编码,
    联合暴露组,
    高血压状态,
    体力活动,
    互联网使用,
    纳入Meta国家数,
    合并HR,
    合并CI下限,
    合并CI上限,
    合并HR及95CI,
    合并P值,
    合并P值显示,
    Q值,
    Q自由度,
    异质性P值,
    异质性P值显示,
    I2,
    I2百分比,
    I2显示,
    Tau,
    Tau2,
    Meta分析状态
  )

cat("\n====================================================\n")
cat("高血压、体力活动及互联网使用联合分析：随机效应 Meta 结果\n")
cat("参考组：无高血压 + 活跃 + 使用互联网\n")
cat("====================================================\n")
print(meta_joint_results, digits = 4)

# =====================================================================
# 23. 合并四国 Cox + Meta 结果，生成图片类似的汇总表
# =====================================================================

joint_cox_with_meta <- joint_cox_results %>%
  select(
    国家,
    联合组编码,
    联合暴露组,
    HR及95CI
  ) %>%
  pivot_wider(
    names_from = 国家,
    values_from = HR及95CI
  ) %>%
  left_join(
    meta_joint_results %>%
      select(
        联合组编码,
        Meta分析_HR及95CI = 合并HR及95CI,
        Meta分析_P值 = 合并P值显示,
        Meta分析_I2 = I2显示
      ),
    by = "联合组编码"
  ) %>%
  left_join(
    joint_level_map %>%
      select(
        联合组编码,
        高血压状态,
        体力活动,
        互联网使用,
        是否参考组
      ),
    by = "联合组编码"
  ) %>%
  select(
    高血压状态,
    体力活动,
    互联网使用,
    是否参考组,
    CHARLS,
    HRS,
    SHARE,
    ELSA,
    Meta分析_HR及95CI,
    Meta分析_P值,
    Meta分析_I2
  )

# =====================================================================
# 24. 导出全部中文命名 CSV 文件
# =====================================================================

# 1. 总体流程图样本量
write_excel_csv(
  flow_table,
  "联合分析_表1_总体流程图样本量.csv"
)

# 2. 最终分析样本量、事件数和随访时间
write_excel_csv(
  final_sample_table,
  "联合分析_表2_各国最终样本量事件数及随访时间.csv"
)

# 3. 各国八个联合组的人数、事件数和随访时间
write_excel_csv(
  joint_sample_table,
  "联合分析_表3_各国联合暴露组样本量事件数及随访时间.csv"
)

# 4. 四国 Cox 回归详细结果（长格式）
write_excel_csv(
  joint_cox_results,
  "联合分析_表4_各国Cox回归详细结果_高血压体力活动互联网.csv"
)

# 5. 类似图片结构的各国 Cox 结果（宽格式）
write_excel_csv(
  joint_cox_results_wide,
  "联合分析_表5_各国Cox回归结果宽格式_高血压体力活动互联网.csv"
)

# 6. 联合 Cox 模型 Schoenfeld 残差 PH 检验（全部协变量）
write_excel_csv(
  joint_ph_results,
  "联合分析_表6_各国联合Cox模型比例风险假设检验_Schoenfeld残差.csv"
)

# 7. 仅导出 GLOBAL 整体比例风险假设检验
write_excel_csv(
  joint_ph_global_results,
  "联合分析_表7_各国联合Cox模型整体比例风险假设检验_GLOBAL.csv"
)

# 8. 各联合组的随机效应 Meta 分析结果
write_excel_csv(
  meta_joint_results,
  "联合分析_表8_各联合暴露组随机效应Meta分析结果.csv"
)

# 9. 各国 Cox 结果和 Meta 结果合并表，适合制作图片
write_excel_csv(
  joint_cox_with_meta,
  "联合分析_表9_各国Cox与Meta合并结果_高血压体力活动互联网.csv"
)

# 10. 最终联合分析数据
write_excel_csv(
  joint_cox_data,
  "联合分析_最终Cox分析数据_高血压体力活动互联网.csv"
)

# 11. 联合组定义和参考组说明
write_excel_csv(
  joint_level_map,
  "联合分析_联合暴露组定义及参考组.csv"
)

# =====================================================================
# 25. 控制台提示
# =====================================================================

cat("\n====================================================\n")
cat("联合分析全部完成，CSV 文件已导出。\n")
cat("参考组：无高血压 + 活跃 + 使用互联网\n")
cat("最终分析样本量：", nrow(joint_cox_data), "\n")
cat("输出目录：", getwd(), "\n")
cat("====================================================\n")