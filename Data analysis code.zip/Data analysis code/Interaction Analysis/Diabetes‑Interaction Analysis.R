# =====================================================================
#
# 敏感性分析：排除基线高血压患者
# 糖尿病与体力活动、互联网使用的交互作用分析
#
# 分析定义：
# 1. 动态基线时 rXonlydiabe == 1 且 rXhypertension == 0：
#    归为"糖尿病且无高血压"组；
# 2. 动态基线时 rXonlydiabe == 0 且 rXhypertension == 0：
#    归为"无糖尿病且无高血压"对照组；
# 3. 动态基线高血压为 1 者排除；
# 4. 动态基线高血压状态缺失者排除；
# 5. 其他动态基线筛选、痴呆事件判定、Cox 调整变量、
#    Schoenfeld 残差 PH 假设检验和随机效应 Meta 分析
#    均与主分析保持一致。
#
# 代码逻辑结构：
# 1. 加载包和读取数据
# 2. 定义安全取值、国家波次及变量检查函数
# 3. 按动态基线筛选无高血压分析样本
# 4. 提取动态基线协变量、随访时间和痴呆事件
# 5. 校正不稳定的痴呆事件状态
# 6. 汇总敏感性分析流程图和样本量
# 7. 糖尿病 × 体力活动交互作用分析
# 8. 糖尿病 × 互联网使用交互作用分析
# 9. 加性交互：RERI（95%CI；P值）
# 10. 乘性交互：交互项HR（95%CI；P值）
# 11. 四国随机效应 Meta 分析
# 12. Schoenfeld 残差比例风险假设检验
# 13. 导出全部结果
#
# =====================================================================

# =====================================================================
# 0. 环境设置与加载 R 包
# =====================================================================

setwd("E:/csl/CSL/database")

library(dplyr)
library(tidyr)
library(haven)
library(survival)
library(broom)
library(meta)
library(readr)
library(tibble)

select <- dplyr::select

# =====================================================================
# 1. 读取原始数据
# =====================================================================

total_data <- read_dta("onlydiabe_data_new.dta") %>%
  mutate(record_id = row_number())

# =====================================================================
# 2. 基础变量检查
# =====================================================================

required_basic_vars <- c(
  "ID",
  "data_source",
  "yearsold",
  "age",
  "raeduc_c",
  "ragender"
)

missing_basic_vars <- setdiff(required_basic_vars, names(total_data))

if (length(missing_basic_vars) > 0) {
  stop(
    "数据中缺少以下必要变量：",
    paste(missing_basic_vars, collapse = ", ")
  )
}

# =====================================================================
# 3. 安全读取变量的函数
# =====================================================================

safe_get_value <- function(data, row_idx, var_name) {

  if (!var_name %in% names(data)) {
    return(NA_real_)
  }

  value <- data[[var_name]][row_idx]

  if (length(value) == 0 || is.null(value) || is.na(value)) {
    return(NA_real_)
  }

  suppressWarnings(as.numeric(value))
}

# =====================================================================
# 4. 定义四国队列调查波次与年份
# =====================================================================

get_wave_info <- function(data_source) {

  data_source <- suppressWarnings(as.integer(data_source))

  switch(
    as.character(data_source),

    "1" = list(
      country = "CHARLS",
      max_wave = 5L,
      wave_years = c(2011, 2013, 2015, 2018, 2020)
    ),

    "2" = list(
      country = "HRS",
      max_wave = 6L,
      wave_years = c(2012, 2014, 2016, 2018, 2020, 2022)
    ),

    "3" = list(
      country = "SHARE",
      max_wave = 5L,
      wave_years = c(2013, 2015, 2017, 2020, 2022)
    ),

    "4" = list(
      country = "ELSA",
      max_wave = 5L,
      wave_years = c(2015, 2017, 2020, 2022, 2024)
    ),

    NULL
  )
}

# =====================================================================
# 5. 检查每一波次所需变量是否存在
# =====================================================================

check_wave_columns <- function(data, wave) {

  required_wave_vars <- c(
    paste0("r", wave, "onlydiabe"),
    paste0("r", wave, "hypertension"),
    paste0("r", wave, "phyactivities"),
    paste0("r", wave, "netuse"),
    paste0("r", wave, "dementia"),
    paste0("r", wave, "mstat"),
    paste0("r", wave, "scocwk"),
    paste0("r", wave, "smoking"),
    paste0("r", wave, "Non_com_dis"),
    paste0("r", wave, "drink")
  )

  all(required_wave_vars %in% names(data))
}

# =====================================================================
# 6. 获取研究对象指定波次的基线变量
# =====================================================================

get_baseline_variables <- function(data, i, wave) {

  list(
    onlydiabe = safe_get_value(data, i, paste0("r", wave, "onlydiabe")),
    hypertension = safe_get_value(data, i, paste0("r", wave, "hypertension")),
    phyactivities = safe_get_value(data, i, paste0("r", wave, "phyactivities")),
    netuse = safe_get_value(data, i, paste0("r", wave, "netuse")),
    dementia = safe_get_value(data, i, paste0("r", wave, "dementia")),
    mstat = safe_get_value(data, i, paste0("r", wave, "mstat")),
    scocwk = safe_get_value(data, i, paste0("r", wave, "scocwk")),
    smoking = safe_get_value(data, i, paste0("r", wave, "smoking")),
    Non_com_dis = safe_get_value(data, i, paste0("r", wave, "Non_com_dis")),
    drink = safe_get_value(data, i, paste0("r", wave, "drink"))
  )
}

# =====================================================================
# 7. 判断基线后是否有至少一次有效痴呆随访
# =====================================================================

has_followup_dementia_data <- function(data, i, enrollment_wave, max_wave) {

  if (is.na(enrollment_wave) || enrollment_wave >= max_wave) {
    return(FALSE)
  }

  future_waves <- seq.int(enrollment_wave + 1L, max_wave)

  future_dementia <- vapply(
    future_waves,
    function(wave) {
      safe_get_value(data, i, paste0("r", wave, "dementia"))
    },
    numeric(1)
  )

  any(!is.na(future_dementia))
}

# =====================================================================
# 8. 动态基线筛选
#
# 仅纳入：
# - 无高血压：rXhypertension == 0；
# - 糖尿病组：rXonlydiabe == 1；
# - 对照组：rXonlydiabe == 0。
# =====================================================================

filter_sensitivity_analysis_data <- function(data) {

  data <- data %>%
    mutate(
      enrollment_wave = NA_integer_,
      screening_status = NA_character_,
      country = case_when(
        data_source == 1 ~ "CHARLS",
        data_source == 2 ~ "HRS",
        data_source == 3 ~ "SHARE",
        data_source == 4 ~ "ELSA",
        TRUE ~ "Unknown"
      )
    )

  for (i in seq_len(nrow(data))) {

    source_i <- safe_get_value(data, i, "data_source")
    wave_info <- get_wave_info(source_i)

    if (is.null(wave_info)) {
      data$screening_status[i] <- "排除：未知数据来源"
      next
    }

    if (is.na(data$age[i]) || data$age[i] < 50) {
      data$screening_status[i] <- "排除：年龄<50岁或年龄缺失"
      next
    }

    max_wave_i <- wave_info$max_wave

    has_exposure_hypertension_data <- FALSE
    has_no_hypertension_baseline <- FALSE
    has_non_dementia_baseline <- FALSE
    has_complete_covariate_baseline <- FALSE
    has_followup_data <- FALSE
    enrollment_found <- FALSE

    for (wave in seq_len(max_wave_i - 1L)) {

      if (!check_wave_columns(data, wave)) {
        next
      }

      baseline_var <- get_baseline_variables(data, i, wave)

      if (is.na(baseline_var$onlydiabe) || is.na(baseline_var$hypertension)) {
        next
      }

      if (!baseline_var$onlydiabe %in% c(0, 1)) {
        next
      }

      if (!baseline_var$hypertension %in% c(0, 1)) {
        next
      }

      has_exposure_hypertension_data <- TRUE

      if (baseline_var$hypertension == 1) {
        next
      }

      has_no_hypertension_baseline <- TRUE

      if (is.na(baseline_var$phyactivities) || is.na(baseline_var$netuse)) {
        next
      }

      if (is.na(baseline_var$dementia) || baseline_var$dementia != 0) {
        next
      }

      has_non_dementia_baseline <- TRUE

      all_baseline_vars <- c(
        baseline_var$onlydiabe,
        baseline_var$hypertension,
        baseline_var$phyactivities,
        baseline_var$netuse,
        baseline_var$dementia,
        baseline_var$mstat,
        baseline_var$scocwk,
        baseline_var$smoking,
        baseline_var$Non_com_dis,
        baseline_var$drink,
        data$yearsold[i],
        data$raeduc_c[i],
        data$ragender[i]
      )

      if (any(is.na(all_baseline_vars))) {
        next
      }

      has_complete_covariate_baseline <- TRUE

      if (!has_followup_dementia_data(data, i, wave, max_wave_i)) {
        next
      }

      has_followup_data <- TRUE

      data$enrollment_wave[i] <- wave
      data$screening_status[i] <- "纳入最终分析"
      enrollment_found <- TRUE

      break
    }

    if (!enrollment_found) {

      if (!has_exposure_hypertension_data) {
        data$screening_status[i] <- "排除：基线糖尿病或高血压状态缺失"

      } else if (!has_no_hypertension_baseline) {
        data$screening_status[i] <- "排除：基线患高血压"

      } else if (!has_non_dementia_baseline) {
        data$screening_status[i] <- "排除：基线痴呆或基线暴露信息缺失"

      } else if (!has_complete_covariate_baseline) {
        data$screening_status[i] <- "排除：基线协变量数据缺失"

      } else if (!has_followup_data) {
        data$screening_status[i] <- "排除：基线后痴呆随访数据缺失"

      } else {
        data$screening_status[i] <- "排除：其他原因"
      }
    }
  }

  data
}

# =====================================================================
# 9. 运行动态基线筛选
# =====================================================================

screened_data <- filter_sensitivity_analysis_data(total_data)

data_in <- screened_data %>%
  filter(screening_status == "纳入最终分析")

# =====================================================================
# 10. 提取动态基线协变量、随访时间和初步痴呆事件
# =====================================================================

extract_baseline_covariates <- function(data) {

  new_vars <- c(
    "baseline_onlydiabe",
    "baseline_hypertension",
    "baseline_dementia_status",
    "baseline_phyactivities",
    "baseline_netuse",
    "baseline_mstat",
    "baseline_scocwk",
    "baseline_smoking",
    "baseline_drink",
    "baseline_Non_com_dis",
    "baseline_year",
    "last_followup_year",
    "time_to_event",
    "event_status"
  )

  data[new_vars] <- NA_real_

  for (i in seq_len(nrow(data))) {

    source_i <- safe_get_value(data, i, "data_source")
    wave_i <- safe_get_value(data, i, "enrollment_wave")
    wave_info <- get_wave_info(source_i)

    if (is.null(wave_info) || is.na(wave_i)) {
      next
    }

    wave_i <- as.integer(wave_i)
    max_wave_i <- wave_info$max_wave
    wave_years_i <- wave_info$wave_years
    baseline_year_i <- wave_years_i[wave_i]

    data$baseline_onlydiabe[i] <- safe_get_value(
      data, i, paste0("r", wave_i, "onlydiabe")
    )

    data$baseline_hypertension[i] <- safe_get_value(
      data, i, paste0("r", wave_i, "hypertension")
    )

    data$baseline_dementia_status[i] <- safe_get_value(
      data, i, paste0("r", wave_i, "dementia")
    )

    data$baseline_phyactivities[i] <- safe_get_value(
      data, i, paste0("r", wave_i, "phyactivities")
    )

    data$baseline_netuse[i] <- safe_get_value(
      data, i, paste0("r", wave_i, "netuse")
    )

    data$baseline_mstat[i] <- safe_get_value(
      data, i, paste0("r", wave_i, "mstat")
    )

    data$baseline_scocwk[i] <- safe_get_value(
      data, i, paste0("r", wave_i, "scocwk")
    )

    data$baseline_smoking[i] <- safe_get_value(
      data, i, paste0("r", wave_i, "smoking")
    )

    data$baseline_drink[i] <- safe_get_value(
      data, i, paste0("r", wave_i, "drink")
    )

    data$baseline_Non_com_dis[i] <- safe_get_value(
      data, i, paste0("r", wave_i, "Non_com_dis")
    )

    data$baseline_year[i] <- baseline_year_i

    onset_year_i <- NA_real_
    last_followup_year_i <- baseline_year_i
    event_i <- 0L

    future_waves <- seq.int(wave_i + 1L, max_wave_i)

    for (future_wave in future_waves) {

      dementia_i <- safe_get_value(
        data, i, paste0("r", future_wave, "dementia")
      )

      current_year_i <- wave_years_i[future_wave]

      if (!is.na(dementia_i)) {

        last_followup_year_i <- current_year_i

        if (dementia_i == 1 && is.na(onset_year_i)) {
          onset_year_i <- current_year_i
          event_i <- 1L
          break
        }
      }
    }

    data$last_followup_year[i] <- last_followup_year_i
    data$event_status[i] <- event_i

    if (event_i == 1L) {
      data$time_to_event[i] <- onset_year_i - baseline_year_i
    } else {
      data$time_to_event[i] <- last_followup_year_i - baseline_year_i
    }
  }

  data %>%
    select(
      record_id,
      ID,
      country,
      data_source,
      enrollment_wave,
      baseline_year,
      last_followup_year,
      yearsold,
      age,
      raeduc_c,
      ragender,
      baseline_onlydiabe,
      baseline_hypertension,
      baseline_dementia_status,
      baseline_phyactivities,
      baseline_netuse,
      baseline_mstat,
      baseline_scocwk,
      baseline_smoking,
      baseline_drink,
      baseline_Non_com_dis,
      time_to_event,
      event_status
    ) %>%
    filter(
      baseline_onlydiabe %in% c(0, 1),
      baseline_hypertension == 0,
      baseline_dementia_status == 0,
      !is.na(yearsold),
      !is.na(age),
      !is.na(raeduc_c),
      !is.na(ragender),
      !is.na(baseline_phyactivities),
      !is.na(baseline_netuse),
      !is.na(baseline_mstat),
      !is.na(baseline_scocwk),
      !is.na(baseline_smoking),
      !is.na(baseline_drink),
      !is.na(baseline_Non_com_dis),
      !is.na(time_to_event),
      time_to_event > 0
    ) %>%
    mutate(
      country = factor(
        country,
        levels = c("CHARLS", "HRS", "SHARE", "ELSA")
      ),

      baseline_onlydiabe = factor(
        baseline_onlydiabe,
        levels = c(0, 1),
        labels = c("无糖尿病且无高血压", "糖尿病且无高血压")
      ),

      yearsold = factor(
        yearsold,
        levels = c(1, 2, 3, 4),
        labels = c("60岁以下", "60-69岁", "70-79岁", "80岁及以上")
      ),

      ragender = factor(
        ragender,
        levels = c(1, 2),
        labels = c("男", "女")
      ),

      raeduc_c = factor(
        raeduc_c,
        levels = c(1, 2, 3),
        labels = c("初中及以下", "高中", "大学及以上")
      ),

      baseline_phyactivities = factor(
        baseline_phyactivities,
        levels = c(0, 1),
        labels = c("不活跃", "活跃")
      ),

      baseline_netuse = factor(
        baseline_netuse,
        levels = c(0, 1),
        labels = c("不使用", "使用")
      ),

      baseline_mstat = factor(
        baseline_mstat,
        levels = c(1, 2),
        labels = c("已婚/同居", "单身")
      ),

      baseline_scocwk = factor(
        baseline_scocwk,
        levels = c(0, 1),
        labels = c("不活跃", "活跃")
      ),

      baseline_smoking = factor(
        baseline_smoking,
        levels = c(0, 1, 2),
        labels = c("戒烟", "吸烟", "从未吸烟")
      ),

      baseline_drink = factor(
        baseline_drink,
        levels = c(0, 1),
        labels = c("从未饮酒", "饮过酒")
      ),

      baseline_Non_com_dis = factor(
        baseline_Non_com_dis,
        levels = c(0, 1),
        labels = c("无", "有")
      )
    )
}

# =====================================================================
# 11. 校正痴呆事件状态及随访时间
#
# 校正规则：
# 若首次痴呆阳性后，下一次有效痴呆随访为阴性，
# 则该首次阳性不被视为真实痴呆事件。
# =====================================================================

correct_event_status <- function(data, origin_data) {

  dementia_vars <- paste0("r", 1:6, "dementia")
  existing_dementia_vars <- intersect(dementia_vars, names(origin_data))

  origin_data_sub <- origin_data %>%
    select(record_id, any_of(existing_dementia_vars))

  if (anyDuplicated(origin_data_sub$record_id) > 0) {
    stop("原始数据中的 record_id 不唯一。")
  }

  if (anyDuplicated(data$record_id) > 0) {
    stop("分析数据中的 record_id 不唯一。")
  }

  data_correct <- data %>%
    left_join(origin_data_sub, by = "record_id")

  for (i in seq_len(nrow(data_correct))) {

    source_i <- safe_get_value(data_correct, i, "data_source")
    wave_i <- safe_get_value(data_correct, i, "enrollment_wave")
    wave_info <- get_wave_info(source_i)

    if (is.null(wave_info) || is.na(wave_i)) {
      data_correct$event_status[i] <- 0L
      data_correct$time_to_event[i] <- NA_real_
      next
    }

    wave_i <- as.integer(wave_i)
    max_wave_i <- wave_info$max_wave
    wave_years_i <- wave_info$wave_years
    baseline_year_i <- wave_years_i[wave_i]

    if (wave_i >= max_wave_i) {
      data_correct$event_status[i] <- 0L
      data_correct$time_to_event[i] <- NA_real_
      next
    }

    future_waves <- seq.int(wave_i + 1L, max_wave_i)

    future_dementia <- vapply(
      future_waves,
      function(wave) {
        safe_get_value(data_correct, i, paste0("r", wave, "dementia"))
      },
      numeric(1)
    )

    valid_index <- which(!is.na(future_dementia))

    if (length(valid_index) == 0) {
      data_correct$event_status[i] <- 0L
      data_correct$time_to_event[i] <- NA_real_
      next
    }

    valid_dementia <- future_dementia[valid_index]
    valid_waves <- future_waves[valid_index]

    last_followup_wave <- tail(valid_waves, 1)
    last_followup_year_i <- wave_years_i[last_followup_wave]

    data_correct$last_followup_year[i] <- last_followup_year_i

    event_i <- 0L
    onset_year_i <- NA_real_

    first_positive_position <- which(valid_dementia == 1)[1]

    if (!is.na(first_positive_position)) {

      first_positive_wave <- valid_waves[first_positive_position]
      first_positive_year <- wave_years_i[first_positive_wave]

      if (first_positive_position < length(valid_dementia)) {

        next_valid_dementia <- valid_dementia[first_positive_position + 1L]

        if (next_valid_dementia != 0) {
          event_i <- 1L
          onset_year_i <- first_positive_year
        }

      } else {
        event_i <- 1L
        onset_year_i <- first_positive_year
      }
    }

    data_correct$event_status[i] <- event_i

    if (event_i == 1L) {
      data_correct$time_to_event[i] <- onset_year_i - baseline_year_i
    } else {
      data_correct$time_to_event[i] <- last_followup_year_i - baseline_year_i
    }
  }

  data_correct %>%
    select(-any_of(existing_dementia_vars)) %>%
    filter(
      !is.na(time_to_event),
      time_to_event > 0
    )
}

# =====================================================================
# 12. 构建最终 Cox / 交互作用分析数据
# =====================================================================

cox_data_initial <- extract_baseline_covariates(data_in)

cox_data_final <- correct_event_status(
  data = cox_data_initial,
  origin_data = data_in
)

cox_data_final <- cox_data_final %>%
  mutate(event_status = as.integer(event_status))

# =====================================================================
# 13. 敏感性分析流程图及样本量统计
# =====================================================================

n_all_participants <- nrow(total_data)

flow_order <- c(
  "纳入最终分析",
  "排除：年龄<50岁或年龄缺失",
  "排除：基线糖尿病或高血压状态缺失",
  "排除：基线患高血压",
  "排除：基线痴呆或基线暴露信息缺失",
  "排除：基线协变量数据缺失",
  "排除：基线后痴呆随访数据缺失",
  "排除：其他原因",
  "排除：未知数据来源"
)

flow_table <- screened_data %>%
  count(screening_status, name = "N") %>%
  mutate(
    percent_of_total = round(N / n_all_participants * 100, 2),
    screening_status = factor(screening_status, levels = flow_order)
  ) %>%
  arrange(screening_status)

flow_by_country <- screened_data %>%
  mutate(screening_status = factor(screening_status, levels = flow_order)) %>%
  group_by(country, screening_status) %>%
  summarise(N = n(), .groups = "drop") %>%
  pivot_wider(
    names_from = screening_status,
    values_from = N,
    values_fill = 0
  )

n_after_screening <- nrow(data_in)
n_final_analysis <- nrow(cox_data_final)
n_removed_after_event_correction <- n_after_screening - n_final_analysis

analysis_sample_by_country <- cox_data_final %>%
  group_by(country) %>%
  summarise(
    N = n(),
    diabetes_no_hypertension = sum(
      baseline_onlydiabe == "糖尿病且无高血压",
      na.rm = TRUE
    ),
    control_no_diabetes_no_hypertension = sum(
      baseline_onlydiabe == "无糖尿病且无高血压",
      na.rm = TRUE
    ),
    dementia_events = sum(event_status == 1, na.rm = TRUE),
    non_events = sum(event_status == 0, na.rm = TRUE),
    mean_followup_years = mean(time_to_event, na.rm = TRUE),
    median_followup_years = median(time_to_event, na.rm = TRUE),
    .groups = "drop"
  ) %>%
  mutate(country = as.character(country))

overall_followup <- cox_data_final %>%
  summarise(
    country = "总体（四国合并）",
    N = n(),
    diabetes_no_hypertension = sum(
      baseline_onlydiabe == "糖尿病且无高血压",
      na.rm = TRUE
    ),
    control_no_diabetes_no_hypertension = sum(
      baseline_onlydiabe == "无糖尿病且无高血压",
      na.rm = TRUE
    ),
    dementia_events = sum(event_status == 1, na.rm = TRUE),
    non_events = sum(event_status == 0, na.rm = TRUE),
    mean_followup_years = mean(time_to_event, na.rm = TRUE),
    median_followup_years = median(time_to_event, na.rm = TRUE)
  )

analysis_sample_with_overall <- bind_rows(
  analysis_sample_by_country,
  overall_followup
)

cat("\n====================================================\n")
cat("敏感性分析（排除基线高血压）糖尿病交互作用分析流程图样本量\n")
cat("====================================================\n")
cat("\n原始总样本量：", n_all_participants, "\n")
print(flow_table)
cat("\n动态基线筛选后样本量：", n_after_screening, "\n")
cat("结局校正后最终分析样本量：", n_final_analysis, "\n")
cat("结局校正后移除人数：", n_removed_after_event_correction, "\n")
cat("\n====================================================\n")
cat("各国家敏感性分析筛选情况\n")
cat("====================================================\n")
print(flow_by_country)
cat("\n====================================================\n")
cat("最终分析样本量、事件数和随访时间\n")
cat("====================================================\n")
print(analysis_sample_with_overall)

# =====================================================================
# 14. 构建交互作用分析数据
#
# 仅修改参考水平，不进行任何删除或新增样本。
#
# 糖尿病参考组：无糖尿病且无高血压
# 体力活动参考组：不活跃
# 互联网使用参考组：不使用
# =====================================================================

interaction_data <- cox_data_final %>%
  mutate(
    baseline_onlydiabe = relevel(
      factor(baseline_onlydiabe),
      ref = "无糖尿病且无高血压"
    ),

    baseline_phyactivities = relevel(
      factor(baseline_phyactivities),
      ref = "不活跃"
    ),

    baseline_netuse = relevel(
      factor(baseline_netuse),
      ref = "不使用"
    )
  )

# =====================================================================
# 15. 与 Cox 最终分析人群一致性核验
# =====================================================================

if (nrow(interaction_data) != nrow(cox_data_final)) {
  stop(
    "错误：交互作用分析与主 Cox 分析最终样本量不一致。",
    "\n主 Cox 样本量：", nrow(cox_data_final),
    "\n交互作用分析样本量：", nrow(interaction_data)
  )
}

if (!setequal(
  interaction_data$record_id,
  cox_data_final$record_id
)) {
  stop("错误：交互作用分析和主 Cox 分析的 record_id 不一致。")
}

if (!identical(
  interaction_data %>% arrange(record_id) %>% pull(event_status),
  cox_data_final %>% arrange(record_id) %>% pull(event_status)
)) {
  stop("错误：交互作用分析和主 Cox 分析的 event_status 不一致。")
}

if (!isTRUE(all.equal(
  interaction_data %>% arrange(record_id) %>% pull(time_to_event),
  cox_data_final %>% arrange(record_id) %>% pull(time_to_event),
  check.attributes = FALSE
))) {
  stop("错误：交互作用分析和主 Cox 分析的 time_to_event 不一致。")
}

cat("\n====================================================\n")
cat("一致性核验通过。\n")
cat("交互作用分析最终人群与敏感性分析 Cox 分析完全一致。\n")
cat("最终样本量：", nrow(interaction_data), "\n")
cat("====================================================\n")

# =====================================================================
# 16. 定义交互作用 Cox 模型
# =====================================================================

formula_interaction_pa <- Surv(time_to_event, event_status) ~
  baseline_onlydiabe * baseline_phyactivities +
  yearsold +
  ragender +
  raeduc_c +
  baseline_netuse +
  baseline_mstat +
  baseline_scocwk +
  baseline_smoking +
  baseline_drink +
  baseline_Non_com_dis

formula_interaction_net <- Surv(time_to_event, event_status) ~
  baseline_onlydiabe * baseline_netuse +
  yearsold +
  ragender +
  raeduc_c +
  baseline_phyactivities +
  baseline_mstat +
  baseline_scocwk +
  baseline_smoking +
  baseline_drink +
  baseline_Non_com_dis

# =====================================================================
# 17. 工具函数：自动识别模型中的交互项名称
# =====================================================================

find_interaction_term <- function(coef_names, var1, var2) {

  matched_terms <- coef_names[
    grepl(var1, coef_names, fixed = TRUE) &
      grepl(var2, coef_names, fixed = TRUE) &
      grepl(":", coef_names, fixed = TRUE)
  ]

  if (length(matched_terms) == 1) {
    return(matched_terms)
  }

  return(NA_character_)
}

# =====================================================================
# 18. 工具函数：计算 RERI、95%CI、标准误和 P 值
#
# HR10 = exp(beta_A)
# HR01 = exp(beta_B)
# HR11 = exp(beta_A + beta_B + beta_AB)
#
# RERI = HR11 - HR10 - HR01 + 1
#
# 采用 Delta method 计算 RERI 标准误及 95%CI。
# =====================================================================

calculate_reri <- function(cox_model,
                           exposure_term,
                           modifier_term,
                           interaction_term) {

  empty_reri <- function(message) {
    tibble(
      RERI = NA_real_,
      RERI_CI_lower = NA_real_,
      RERI_CI_upper = NA_real_,
      RERI_se = NA_real_,
      RERI_p_value = NA_real_,
      RERI_status = message
    )
  }

  if (is.null(cox_model)) {
    return(empty_reri("Cox模型不存在"))
  }

  beta <- coef(cox_model)
  vcov_mat <- vcov(cox_model)

  needed_terms <- c(
    exposure_term,
    modifier_term,
    interaction_term
  )

  if (any(is.na(needed_terms)) ||
      !all(needed_terms %in% names(beta))) {
    return(empty_reri("缺少主效应或交互项，无法计算RERI"))
  }

  if (any(is.na(beta[needed_terms]))) {
    return(empty_reri("模型系数无法稳定估计"))
  }

  beta_a <- beta[exposure_term]
  beta_b <- beta[modifier_term]
  beta_ab <- beta[interaction_term]

  HR10 <- exp(beta_a)
  HR01 <- exp(beta_b)
  HR11 <- exp(beta_a + beta_b + beta_ab)

  RERI_value <- HR11 - HR10 - HR01 + 1

  gradient <- c(
    HR11 - HR10,
    HR11 - HR01,
    HR11
  )

  names(gradient) <- c(
    exposure_term,
    modifier_term,
    interaction_term
  )

  sub_vcov <- vcov_mat[
    names(gradient),
    names(gradient),
    drop = FALSE
  ]

  RERI_variance <- as.numeric(
    t(gradient) %*% sub_vcov %*% gradient
  )

  if (is.na(RERI_variance) || RERI_variance < 0) {
    return(
      tibble(
        RERI = RERI_value,
        RERI_CI_lower = NA_real_,
        RERI_CI_upper = NA_real_,
        RERI_se = NA_real_,
        RERI_p_value = NA_real_,
        RERI_status = "RERI方差无法计算"
      )
    )
  }

  RERI_se <- sqrt(RERI_variance)
  RERI_CI_lower <- RERI_value - 1.96 * RERI_se
  RERI_CI_upper <- RERI_value + 1.96 * RERI_se

  RERI_z <- RERI_value / RERI_se
  RERI_p_value <- 2 * pnorm(
    abs(RERI_z),
    lower.tail = FALSE
  )

  tibble(
    RERI = RERI_value,
    RERI_CI_lower = RERI_CI_lower,
    RERI_CI_upper = RERI_CI_upper,
    RERI_se = RERI_se,
    RERI_p_value = RERI_p_value,
    RERI_status = "成功估计"
  )
}

# =====================================================================
# 19. 单个国家交互作用分析函数
# =====================================================================

run_interaction_by_country <- function(
    dt,
    country_name,
    interaction_type = c("体力活动", "互联网使用")
) {

  interaction_type <- match.arg(interaction_type)

  n_total <- nrow(dt)
  n_events <- sum(dt$event_status == 1, na.rm = TRUE)

  empty_result <- function(message) {

    tibble(
      国家 = country_name,
      交互作用 = paste0("糖尿病 × ", interaction_type),
      样本量 = n_total,
      痴呆事件数 = n_events,

      RERI = NA_real_,
      RERI_CI_lower = NA_real_,
      RERI_CI_upper = NA_real_,
      RERI_se = NA_real_,
      RERI_p_value = NA_real_,
      RERI_status = message,

      interaction_HR = NA_real_,
      interaction_CI_lower = NA_real_,
      interaction_CI_upper = NA_real_,
      interaction_logHR = NA_real_,
      interaction_se_logHR = NA_real_,
      interaction_p_value = NA_real_,
      multiplicative_status = message
    )
  }

  if (n_total == 0 || n_events == 0) {
    return(empty_result("无样本或无痴呆事件，无法估计"))
  }

  dt <- droplevels(dt)

  if (interaction_type == "体力活动") {

    current_formula <- formula_interaction_pa
    exposure_term <- "baseline_onlydiabe糖尿病且无高血压"
    modifier_term <- "baseline_phyactivities活跃"
    var1 <- "baseline_onlydiabe"
    var2 <- "baseline_phyactivities"

  } else {

    current_formula <- formula_interaction_net
    exposure_term <- "baseline_onlydiabe糖尿病且无高血压"
    modifier_term <- "baseline_netuse使用"
    var1 <- "baseline_onlydiabe"
    var2 <- "baseline_netuse"
  }

  cox_model <- tryCatch(
    coxph(
      formula = current_formula,
      data = dt,
      x = TRUE,
      model = TRUE
    ),
    error = function(e) NULL
  )

  if (is.null(cox_model)) {
    return(empty_result("Cox模型拟合失败"))
  }

  beta_names <- names(coef(cox_model))

  interaction_term <- find_interaction_term(
    coef_names = beta_names,
    var1 = var1,
    var2 = var2
  )

  reri_result <- calculate_reri(
    cox_model = cox_model,
    exposure_term = exposure_term,
    modifier_term = modifier_term,
    interaction_term = interaction_term
  )

  if (is.na(interaction_term) ||
      !interaction_term %in% beta_names ||
      is.na(coef(cox_model)[interaction_term])) {

    multiplicative_result <- tibble(
      interaction_HR = NA_real_,
      interaction_CI_lower = NA_real_,
      interaction_CI_upper = NA_real_,
      interaction_logHR = NA_real_,
      interaction_se_logHR = NA_real_,
      interaction_p_value = NA_real_,
      multiplicative_status = "未识别到有效交互项"
    )

  } else {

    interaction_beta <- coef(cox_model)[interaction_term]

    interaction_se <- sqrt(
      diag(vcov(cox_model))
    )[interaction_term]

    interaction_HR <- exp(interaction_beta)

    interaction_CI_lower <- exp(
      interaction_beta - 1.96 * interaction_se
    )

    interaction_CI_upper <- exp(
      interaction_beta + 1.96 * interaction_se
    )

    interaction_p_value <- 2 * pnorm(
      abs(interaction_beta / interaction_se),
      lower.tail = FALSE
    )

    multiplicative_result <- tibble(
      interaction_HR = interaction_HR,
      interaction_CI_lower = interaction_CI_lower,
      interaction_CI_upper = interaction_CI_upper,
      interaction_logHR = interaction_beta,
      interaction_se_logHR = interaction_se,
      interaction_p_value = interaction_p_value,
      multiplicative_status = "成功估计"
    )
  }

  tibble(
    国家 = country_name,
    交互作用 = paste0("糖尿病 × ", interaction_type),
    样本量 = n_total,
    痴呆事件数 = n_events
  ) %>%
    bind_cols(reri_result) %>%
    bind_cols(multiplicative_result)
}

# =====================================================================
# 20. 四国分别进行交互作用分析
# =====================================================================

country_CHARLS <- interaction_data %>%
  filter(country == "CHARLS")
country_HRS <- interaction_data %>%
  filter(country == "HRS")
country_SHARE <- interaction_data %>%
  filter(country == "SHARE")
country_ELSA <- interaction_data %>%
  filter(country == "ELSA")

interaction_pa_results <- bind_rows(
  run_interaction_by_country(country_CHARLS, "CHARLS", "体力活动"),
  run_interaction_by_country(country_HRS, "HRS", "体力活动"),
  run_interaction_by_country(country_SHARE, "SHARE", "体力活动"),
  run_interaction_by_country(country_ELSA, "ELSA", "体力活动")
)

interaction_net_results <- bind_rows(
  run_interaction_by_country(country_CHARLS, "CHARLS", "互联网使用"),
  run_interaction_by_country(country_HRS, "HRS", "互联网使用"),
  run_interaction_by_country(country_SHARE, "SHARE", "互联网使用"),
  run_interaction_by_country(country_ELSA, "ELSA", "互联网使用")
)

interaction_country_results <- bind_rows(
  interaction_pa_results,
  interaction_net_results
) %>%
  mutate(
    RERI及95CI = case_when(
      is.na(RERI) ~ NA_character_,
      TRUE ~ sprintf(
        "%.3f (%.3f–%.3f)",
        RERI,
        RERI_CI_lower,
        RERI_CI_upper
      )
    ),

    RERI_P值显示 = case_when(
      is.na(RERI_p_value) ~ NA_character_,
      RERI_p_value < 0.001 ~ "<0.001",
      TRUE ~ sprintf("%.3f", RERI_p_value)
    ),

    乘性交互HR及95CI = case_when(
      is.na(interaction_HR) ~ NA_character_,
      TRUE ~ sprintf(
        "%.3f (%.3f–%.3f)",
        interaction_HR,
        interaction_CI_lower,
        interaction_CI_upper
      )
    ),

    乘性交互P值显示 = case_when(
      is.na(interaction_p_value) ~ NA_character_,
      interaction_p_value < 0.001 ~ "<0.001",
      TRUE ~ sprintf("%.3f", interaction_p_value)
    )
  ) %>%
  select(
    国家,
    交互作用,
    样本量,
    痴呆事件数,

    RERI,
    RERI_CI_lower,
    RERI_CI_upper,
    RERI及95CI,
    RERI_se,
    RERI_p_value,
    RERI_P值显示,
    RERI_status,

    interaction_HR,
    interaction_CI_lower,
    interaction_CI_upper,
    乘性交互HR及95CI,
    interaction_logHR,
    interaction_se_logHR,
    interaction_p_value,
    乘性交互P值显示,
    multiplicative_status
  )

cat("\n====================================================\n")
cat("敏感性分析：四国糖尿病交互作用分析结果（排除基线高血压）\n")
cat("====================================================\n")
print(interaction_country_results, digits = 4)

# =====================================================================
# 21. 交互作用 Cox 模型的 Schoenfeld 残差 PH 假设检验
# =====================================================================

test_interaction_ph <- function(
    dt,
    country_name,
    interaction_type = c("体力活动", "互联网使用")
) {

  interaction_type <- match.arg(interaction_type)

  n_total <- nrow(dt)
  n_events <- sum(dt$event_status == 1, na.rm = TRUE)

  empty_ph <- function(message) {
    tibble(
      国家 = country_name,
      交互作用模型 = paste0("糖尿病 × ", interaction_type),
      变量 = NA_character_,
      rho = NA_real_,
      卡方值 = NA_real_,
      P值 = NA_real_,
      PH假设结论 = message
    )
  }

  if (n_total == 0 || n_events == 0) {
    return(empty_ph("无法检验：无样本或无痴呆事件"))
  }

  dt <- droplevels(dt)

  if (interaction_type == "体力活动") {
    current_formula <- formula_interaction_pa
  } else {
    current_formula <- formula_interaction_net
  }

  cox_model <- tryCatch(
    coxph(
      formula = current_formula,
      data = dt,
      x = TRUE,
      model = TRUE
    ),
    error = function(e) NULL
  )

  if (is.null(cox_model)) {
    return(empty_ph("无法检验：Cox模型拟合失败"))
  }

  ph_test <- tryCatch(
    cox.zph(cox_model, transform = "km"),
    error = function(e) NULL
  )

  if (is.null(ph_test)) {
    return(empty_ph("无法检验：Schoenfeld残差计算失败"))
  }

  ph_table <- as.data.frame(ph_test$table) %>%
    rownames_to_column(var = "变量")

  if (!"rho" %in% names(ph_table)) {
    ph_table$rho <- NA_real_
  }

  if (!"chisq" %in% names(ph_table)) {
    ph_table$chisq <- NA_real_
  }

  if (!"p" %in% names(ph_table)) {
    ph_table$p <- NA_real_
  }

  ph_table %>%
    transmute(
      国家 = country_name,
      交互作用模型 = paste0("糖尿病 × ", interaction_type),
      变量 = 变量,
      rho = rho,
      卡方值 = chisq,
      P值 = p,
      PH假设结论 = case_when(
        is.na(P值) ~ "无法判断",
        变量 == "GLOBAL" & P值 >= 0.05 ~
          "整体模型满足比例风险假设",
        变量 == "GLOBAL" & P值 < 0.05 ~
          "整体模型可能违反比例风险假设",
        P值 >= 0.05 ~
          "未发现违反比例风险假设的证据",
        P值 < 0.05 ~
          "可能违反比例风险假设"
      )
    )
}

interaction_ph_results <- bind_rows(
  test_interaction_ph(country_CHARLS, "CHARLS", "体力活动"),
  test_interaction_ph(country_HRS, "HRS", "体力活动"),
  test_interaction_ph(country_SHARE, "SHARE", "体力活动"),
  test_interaction_ph(country_ELSA, "ELSA", "体力活动"),
  test_interaction_ph(country_CHARLS, "CHARLS", "互联网使用"),
  test_interaction_ph(country_HRS, "HRS", "互联网使用"),
  test_interaction_ph(country_SHARE, "SHARE", "互联网使用"),
  test_interaction_ph(country_ELSA, "ELSA", "互联网使用")
) %>%
  mutate(
    P值显示 = case_when(
      is.na(P值) ~ NA_character_,
      P值 < 0.001 ~ "<0.001",
      TRUE ~ sprintf("%.3f", P值)
    )
  )

interaction_ph_global_results <- interaction_ph_results %>%
  filter(变量 == "GLOBAL")

cat("\n====================================================\n")
cat("交互作用 Cox 模型比例风险假设检验结果（GLOBAL）\n")
cat("====================================================\n")
print(interaction_ph_global_results, digits = 4)

# =====================================================================
# 22. 随机效应 Meta 分析函数
#
# 对 RERI：
# 直接对 RERI 及其标准误进行随机效应 Meta。
#
# 对乘性交互：
# 对交互项 log(HR) 及标准误进行随机效应 Meta；
# 最后将合并 log(HR) 指数转换为 HR。
# =====================================================================

run_interaction_meta <- function(
    data,
    interaction_name,
    effect_type = c("加性交互_RERI", "乘性交互_HR")
) {

  effect_type <- match.arg(effect_type)

  data_sub <- data %>%
    filter(交互作用 == interaction_name)

  if (effect_type == "加性交互_RERI") {

    meta_dat <- data_sub %>%
      filter(
        !is.na(RERI),
        !is.na(RERI_se),
        is.finite(RERI),
        is.finite(RERI_se),
        RERI_se > 0
      ) %>%
      transmute(
        国家 = 国家,
        TE = RERI,
        seTE = RERI_se
      )

    summary_measure <- "RERI"

  } else {

    meta_dat <- data_sub %>%
      filter(
        !is.na(interaction_logHR),
        !is.na(interaction_se_logHR),
        is.finite(interaction_logHR),
        is.finite(interaction_se_logHR),
        interaction_se_logHR > 0
      ) %>%
      transmute(
        国家 = 国家,
        TE = interaction_logHR,
        seTE = interaction_se_logHR
      )

    summary_measure <- "HR"
  }

  if (nrow(meta_dat) < 2) {
    return(
      tibble(
        交互作用 = interaction_name,
        交互作用类型 = effect_type,
        纳入Meta国家数 = nrow(meta_dat),
        合并效应值 = NA_real_,
        合并CI下限 = NA_real_,
        合并CI上限 = NA_real_,
        合并P值 = NA_real_,
        Q值 = NA_real_,
        Q自由度 = NA_real_,
        异质性P值 = NA_real_,
        I2 = NA_real_,
        I2百分比 = NA_real_,
        Tau = NA_real_,
        Tau2 = NA_real_,
        Meta分析状态 = "可用于Meta分析的国家少于2个"
      )
    )
  }

  meta_model <- tryCatch(
    metagen(
      TE = TE,
      seTE = seTE,
      studlab = 国家,
      data = meta_dat,
      sm = summary_measure,
      common = FALSE,
      random = TRUE,
      method.tau = "REML",
      hakn = FALSE
    ),
    error = function(e) NULL
  )

  if (is.null(meta_model)) {
    return(
      tibble(
        交互作用 = interaction_name,
        交互作用类型 = effect_type,
        纳入Meta国家数 = nrow(meta_dat),
        合并效应值 = NA_real_,
        合并CI下限 = NA_real_,
        合并CI上限 = NA_real_,
        合并P值 = NA_real_,
        Q值 = NA_real_,
        Q自由度 = NA_real_,
        异质性P值 = NA_real_,
        I2 = NA_real_,
        I2百分比 = NA_real_,
        Tau = NA_real_,
        Tau2 = NA_real_,
        Meta分析状态 = "随机效应Meta模型拟合失败"
      )
    )
  }

  if (effect_type == "加性交互_RERI") {
    pooled_effect <- meta_model$TE.random
    pooled_lower <- meta_model$lower.random
    pooled_upper <- meta_model$upper.random
  } else {
    pooled_effect <- exp(meta_model$TE.random)
    pooled_lower <- exp(meta_model$lower.random)
    pooled_upper <- exp(meta_model$upper.random)
  }

  tibble(
    交互作用 = interaction_name,
    交互作用类型 = effect_type,
    纳入Meta国家数 = nrow(meta_dat),

    合并效应值 = pooled_effect,
    合并CI下限 = pooled_lower,
    合并CI上限 = pooled_upper,
    合并P值 = meta_model$pval.random,

    Q值 = meta_model$Q,
    Q自由度 = meta_model$df.Q,
    异质性P值 = meta_model$pval.Q,

    I2 = meta_model$I2,
    I2百分比 = meta_model$I2 * 100,

    Tau = meta_model$tau,
    Tau2 = meta_model$tau^2,

    Meta分析状态 = "成功估计"
  )
}

# =====================================================================
# 23. 四国随机效应 Meta 分析
# =====================================================================

interaction_meta_results <- bind_rows(
  run_interaction_meta(
    interaction_country_results,
    interaction_name = "糖尿病 × 体力活动",
    effect_type = "加性交互_RERI"
  ),
  run_interaction_meta(
    interaction_country_results,
    interaction_name = "糖尿病 × 体力活动",
    effect_type = "乘性交互_HR"
  ),
  run_interaction_meta(
    interaction_country_results,
    interaction_name = "糖尿病 × 互联网使用",
    effect_type = "加性交互_RERI"
  ),
  run_interaction_meta(
    interaction_country_results,
    interaction_name = "糖尿病 × 互联网使用",
    effect_type = "乘性交互_HR"
  )
) %>%
  mutate(
    合并效应值及95CI = case_when(
      is.na(合并效应值) ~ NA_character_,
      TRUE ~ sprintf(
        "%.3f (%.3f–%.3f)",
        合并效应值,
        合并CI下限,
        合并CI上限
      )
    ),

    合并P值显示 = case_when(
      is.na(合并P值) ~ NA_character_,
      合并P值 < 0.001 ~ "<0.001",
      TRUE ~ sprintf("%.3f", 合并P值)
    ),

    异质性P值显示 = case_when(
      is.na(异质性P值) ~ NA_character_,
      异质性P值 < 0.001 ~ "<0.001",
      TRUE ~ sprintf("%.3f", 异质性P值)
    ),

    I2显示 = case_when(
      is.na(I2百分比) ~ NA_character_,
      TRUE ~ paste0(round(I2百分比, 1), "%")
    )
  )

cat("\n====================================================\n")
cat("四国随机效应 Meta 分析结果（排除基线高血压）\n")
cat("====================================================\n")
print(interaction_meta_results, digits = 4)

# =====================================================================
# 24. 建立汇总表
# =====================================================================

table2_country <- interaction_country_results %>%
  transmute(
    交互作用 = 交互作用,
    国家 = 国家,

    加性交互_RERI_95CI_P值 = case_when(
      is.na(RERI及95CI) ~ NA_character_,
      TRUE ~ paste0(RERI及95CI, "; P=", RERI_P值显示)
    ),

    乘性交互_HR_95CI_P值 = case_when(
      is.na(乘性交互HR及95CI) ~ NA_character_,
      TRUE ~ paste0(乘性交互HR及95CI, "; P=", 乘性交互P值显示)
    ),

    I2 = NA_character_,
    异质性P值 = NA_character_
  )

table2_meta_reri <- interaction_meta_results %>%
  filter(交互作用类型 == "加性交互_RERI") %>%
  transmute(
    交互作用 = 交互作用,
    国家 = "随机效应模型",
    加性交互_RERI_95CI_P值 = paste0(
      合并效应值及95CI, "; P=", 合并P值显示
    ),
    I2_RERI = I2显示,
    异质性P值_RERI = 异质性P值显示
  )

table2_meta_hr <- interaction_meta_results %>%
  filter(交互作用类型 == "乘性交互_HR") %>%
  transmute(
    交互作用 = 交互作用,
    国家 = "随机效应模型",
    乘性交互_HR_95CI_P值 = paste0(
      合并效应值及95CI, "; P=", 合并P值显示
    ),
    I2_HR = I2显示,
    异质性P值_HR = 异质性P值显示
  )

table2_meta <- full_join(
  table2_meta_reri,
  table2_meta_hr,
  by = c("交互作用", "国家")
) %>%
  transmute(
    交互作用 = 交互作用,
    国家 = 国家,
    加性交互_RERI_95CI_P值 = 加性交互_RERI_95CI_P值,
    乘性交互_HR_95CI_P值 = 乘性交互_HR_95CI_P值,

    I2 = paste0(
      "RERI: ", replace_na(I2_RERI, "NA"),
      "; HR: ", replace_na(I2_HR, "NA")
    ),

    异质性P值 = paste0(
      "RERI: ", replace_na(异质性P值_RERI, "NA"),
      "; HR: ", replace_na(异质性P值_HR, "NA")
    )
  )

interaction_table2 <- bind_rows(
  table2_country,
  table2_meta
) %>%
  mutate(
    交互作用 = factor(
      交互作用,
      levels = c(
        "糖尿病 × 体力活动",
        "糖尿病 × 互联网使用"
      )
    ),

    国家 = factor(
      国家,
      levels = c(
        "CHARLS",
        "HRS",
        "SHARE",
        "ELSA",
        "随机效应模型"
      )
    )
  ) %>%
  arrange(交互作用, 国家)

cat("\n====================================================\n")
cat("交互作用汇总表（排除基线高血压）\n")
cat("====================================================\n")
print(interaction_table2)

# =====================================================================
# 25. 导出 CSV 文件
# =====================================================================

write_excel_csv(
  flow_table,
  "交互作用分析_表1_总体流程图样本量_糖尿病_排除高血压.csv"
)

write_excel_csv(
  flow_by_country,
  "交互作用分析_表2_各国流程图样本量_糖尿病_排除高血压.csv"
)

write_excel_csv(
  analysis_sample_with_overall,
  "交互作用分析_表3_最终样本量事件数随访时间_糖尿病_排除高血压.csv"
)

write_excel_csv(
  interaction_country_results,
  "交互作用分析_表4_四国糖尿病体力活动互联网交互作用完整结果_排除高血压.csv"
)

write_excel_csv(
  interaction_ph_results,
  "交互作用分析_表5_Schoenfeld残差PH检验_糖尿病_排除高血压.csv"
)

write_excel_csv(
  interaction_ph_global_results,
  "交互作用分析_表6_GLOBAL比例风险假设检验_糖尿病_排除高血压.csv"
)

write_excel_csv(
  interaction_meta_results,
  "交互作用分析_表7_糖尿病交互作用随机效应Meta分析结果_排除高血压.csv"
)

write_excel_csv(
  interaction_table2,
  "交互作用分析_表8_糖尿病体力活动互联网交互作用汇总表_排除高血压.csv"
)

write_excel_csv(
  interaction_data,
  "交互作用分析_最终分析数据_糖尿病_排除高血压.csv"
)

# =====================================================================
# 26. 完成提示
# =====================================================================

cat("\n====================================================\n")
cat("敏感性分析：糖尿病交互作用分析全部完成。\n")
cat("（已排除基线高血压患者）\n")
cat("Cox 最终样本量：", nrow(cox_data_final), "\n")
cat("交互作用最终样本量：", nrow(interaction_data), "\n")
cat("结果导出路径：", getwd(), "\n")
cat("====================================================\n")
